# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BR Nome Exame - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BR Nome Exame**

## ValueSet: BR Nome Exame 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/ValueSet/BRNomeExame | *Versão*:1.1.0 |
| Active as of 2026-03-09 | *Nome computável*:BRNomeExame |

 **References** 

Este conjunto de valores não é utilizado aqui; pode ser utilizado noutro local (por exemplo, especificações e/ou implementações que utilizem este conteúdo)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRNomeExame",
  "url" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRNomeExame",
  "version" : "1.1.0",
  "name" : "BRNomeExame",
  "title" : "BR Nome Exame",
  "status" : "active",
  "date" : "2026-03-09T15:10:29-03:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRNomeExameGAL",
      "concept" : [{
        "code" : "coronavirusnCoV",
        "display" : "Novo coronavírus (2019-nCoV)"
      },
      {
        "code" : "COVID",
        "display" : "COVID-19, Biologia Molecular"
      }]
    },
    {
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "94558-4",
        "display" : "SARS coronavirus 2 Ag"
      },
      {
        "code" : "94639-2",
        "display" : "SARS coronavirus 2 ORF1ab region"
      },
      {
        "code" : "96763-8",
        "display" : "SARS coronavirus 2 E gene"
      },
      {
        "code" : "94640-0",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "96764-6",
        "display" : "SARS coronavirus 2 E gene"
      },
      {
        "code" : "94641-8",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "96765-3",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "94642-6",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "96766-1",
        "display" : "GISAID sequence accession number"
      },
      {
        "code" : "94643-4",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "96797-6",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "94644-2",
        "display" : "SARS coronavirus 2 ORF1ab region"
      },
      {
        "code" : "96829-7",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "94645-9",
        "display" : "SARS coronavirus 2 RdRp gene"
      },
      {
        "code" : "96894-1",
        "display" : "SARS coronavirus 2 sequencing & identification panel"
      },
      {
        "code" : "94646-7",
        "display" : "SARS coronavirus 2 RdRp gene"
      },
      {
        "code" : "96895-8",
        "display" : "SARS coronavirus 2 lineage"
      },
      {
        "code" : "94647-5",
        "display" : "SARS-related coronavirus RNA"
      },
      {
        "code" : "96896-6",
        "display" : "SARS coronavirus 2 clade"
      },
      {
        "code" : "94660-8",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "96897-4",
        "display" : "SARS coronavirus 2 RNA panel"
      },
      {
        "code" : "94661-6",
        "display" : "SARS coronavirus 2 Ab"
      },
      {
        "code" : "96898-2",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94720-0",
        "display" : "SARS coronavirus 2 Ab.IgA"
      },
      {
        "code" : "96899-0",
        "display" : "SARS coronavirus 2 ORF1ab region"
      },
      {
        "code" : "94745-7",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "96900-6",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "94746-5",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "96957-6",
        "display" : "SARS coronavirus 2 M gene"
      },
      {
        "code" : "94756-4",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "96958-4",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94757-2",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "96986-5",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94758-0",
        "display" : "SARS-related coronavirus E gene"
      },
      {
        "code" : "97097-0",
        "display" : "SARS coronavirus 2 Ag"
      },
      {
        "code" : "94759-8",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "97098-8",
        "display" : "SARS coronavirus 2 Nsp2 gene"
      },
      {
        "code" : "94760-6",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "97099-6",
        "display" : "Influenza virus A & Influenza virus B & SARS coronavirus 2 Ag panel"
      },
      {
        "code" : "94761-4",
        "display" : "SARS coronavirus 2 Ab.IgG"
      },
      {
        "code" : "97104-4",
        "display" : "SARS coronavirus 2 ORF1ab region"
      },
      {
        "code" : "94762-2",
        "display" : "SARS coronavirus 2 Ab"
      },
      {
        "code" : "98062-3",
        "display" : "Sequencing study identifier"
      },
      {
        "code" : "94763-0",
        "display" : "SARS coronavirus 2"
      },
      {
        "code" : "98069-8",
        "display" : "SARS coronavirus 2 Ab"
      },
      {
        "code" : "94764-8",
        "display" : "SARS coronavirus 2 whole genome"
      },
      {
        "code" : "98080-5",
        "display" : "SARS coronavirus 2 & SARS-related coronavirus RNA panel"
      },
      {
        "code" : "94765-5",
        "display" : "SARS-related coronavirus E gene"
      },
      {
        "code" : "94766-3",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "98131-6",
        "display" : "SARS coronavirus 2 ORF1b region"
      },
      {
        "code" : "94767-1",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "98132-4",
        "display" : "SARS coronavirus 2 ORF1a region"
      },
      {
        "code" : "94768-9",
        "display" : "SARS coronavirus 2 Ab.IgA"
      },
      {
        "code" : "98493-0",
        "display" : "SARS coronavirus 2 ORF1b region"
      },
      {
        "code" : "94769-7",
        "display" : "SARS coronavirus 2 Ab"
      },
      {
        "code" : "98494-8",
        "display" : "SARS coronavirus 2 ORF1a region"
      },
      {
        "code" : "94819-0",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "98732-1",
        "display" : "SARS coronavirus 2 spike protein RBD Ab.neut"
      },
      {
        "code" : "94822-4",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "98733-9",
        "display" : "Percent neutralization by SARS coronavirus 2 spike protein RBD Ab.neut"
      },
      {
        "code" : "94845-5",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "98734-7",
        "display" : "SARS coronavirus 2 spike protein RBD Ab.neut"
      },
      {
        "code" : "95125-1",
        "display" : "SARS coronavirus 2 Ab.IgA+IgM"
      },
      {
        "code" : "98846-9",
        "display" : "SARS coronavirus 2 stimulated gamma interferon release by Helper (CD4+) T-cells^^corrected for background"
      },
      {
        "code" : "95209-3",
        "display" : "SARS coronavirus+SARS coronavirus 2 Ag"
      },
      {
        "code" : "98847-7",
        "display" : "SARS coronavirus 2 stimulated gamma interferon release by lymphocytes^^corrected for background"
      },
      {
        "code" : "95380-2",
        "display" : "Influenza virus A & Influenza virus B & SARS coronavirus 2 & SARS-related coronavirus RNA panel"
      },
      {
        "code" : "99314-7",
        "display" : "SARS coronavirus 2 RdRp gene mutation detected"
      },
      {
        "code" : "95406-5",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "99596-9",
        "display" : "SARS coronavirus 2 nucleocapsid protein Ab.IgG"
      },
      {
        "code" : "95409-9",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "99597-7",
        "display" : "SARS coronavirus 2 spike protein Ab.IgG"
      },
      {
        "code" : "99771-8",
        "display" : "SARS coronavirus 2 spike & nucleocapsid protein stimulated gamma interferon panel"
      },
      {
        "code" : "99772-6",
        "display" : "SARS coronavirus 2 stimulated gamma interferon"
      },
      {
        "code" : "99773-4",
        "display" : "SARS coronavirus 2 stimulated gamma interferon release by T-cells.Spike Ag spot count^^corrected for background"
      },
      {
        "code" : "99774-2",
        "display" : "SARS coronavirus 2 stimulated gamma interferon release by T-cells.Nucleocapsid Ag spot count^^corrected for background"
      },
      {
        "code" : "96755-4",
        "display" : "SARS coronavirus 2 variant interpretation"
      },
      {
        "code" : "96752-1",
        "display" : "SARS coronavirus 2 S gene mutation"
      },
      {
        "code" : "96751-3",
        "display" : "SARS coronavirus 2 S gene mutation detected"
      },
      {
        "code" : "96742-2",
        "display" : "SARS coronavirus 2 Ab.IgG"
      },
      {
        "code" : "96741-4",
        "display" : "SARS coronavirus 2 variant"
      },
      {
        "code" : "96603-6",
        "display" : "SARS coronavirus 2 spike protein RBD Ab.neut"
      },
      {
        "code" : "96448-6",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "96123-5",
        "display" : "SARS coronavirus 2 RdRp gene"
      },
      {
        "code" : "96122-7",
        "display" : "SARS-related coronavirus E gene"
      },
      {
        "code" : "96121-9",
        "display" : "SARS-related coronavirus E gene"
      },
      {
        "code" : "96120-1",
        "display" : "SARS coronavirus 2 RdRp gene"
      },
      {
        "code" : "96119-3",
        "display" : "SARS coronavirus 2 Ag"
      },
      {
        "code" : "96118-5",
        "display" : "SARS coronavirus 2 Ab panel"
      },
      {
        "code" : "96094-8",
        "display" : "SARS coronavirus 2 & SARS-related coronavirus RNA panel"
      },
      {
        "code" : "96091-4",
        "display" : "SARS coronavirus 2 RdRp gene"
      },
      {
        "code" : "95974-2",
        "display" : "SARS coronavirus 2 stimulated gamma interferon panel"
      },
      {
        "code" : "95973-4",
        "display" : "SARS coronavirus 2 stimulated gamma interferon release by T-cells"
      },
      {
        "code" : "95972-6",
        "display" : "SARS coronavirus 2 stimulated gamma interferon release by T-cells^^corrected for background"
      },
      {
        "code" : "95971-8",
        "display" : "SARS coronavirus 2 stimulated gamma interferon"
      },
      {
        "code" : "95970-0",
        "display" : "SARS coronavirus 2 specific TCRB gene rearrangements"
      },
      {
        "code" : "95942-9",
        "display" : "Influenza virus A & Influenza virus B & SARS coronavirus+SARS coronavirus 2 Ag panel"
      },
      {
        "code" : "95941-1",
        "display" : "Influenza virus A & Influenza virus B & SARS coronavirus 2 & Respiratory syncytial virus RNA panel"
      },
      {
        "code" : "95826-4",
        "display" : "SARS coronavirus 2 RNA panel"
      },
      {
        "code" : "95824-9",
        "display" : "SARS coronavirus 2 ORF1ab region"
      },
      {
        "code" : "95823-1",
        "display" : "SARS-related coronavirus E gene"
      },
      {
        "code" : "95609-4",
        "display" : "SARS coronavirus 2 S gene"
      },
      {
        "code" : "95608-6",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "95542-7",
        "display" : "SARS coronavirus 2 Ab"
      },
      {
        "code" : "95522-9",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "95521-1",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "95429-7",
        "display" : "SARS coronavirus 2 Ab.IgG"
      },
      {
        "code" : "95428-9",
        "display" : "SARS coronavirus 2 Ab.IgM"
      },
      {
        "code" : "95427-1",
        "display" : "SARS coronavirus 2 Ab.IgA"
      },
      {
        "code" : "95425-5",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "95424-8",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "95423-0",
        "display" : "Influenza virus A & Influenza virus B & SARS coronavirus 2 identified"
      },
      {
        "code" : "95422-2",
        "display" : "Influenza virus A & Influenza virus B & SARS coronavirus 2 RNA panel"
      },
      {
        "code" : "95416-4",
        "display" : "SARS coronavirus 2 Ab.IgM"
      },
      {
        "code" : "95411-5",
        "display" : "SARS coronavirus 2 Ab.neut"
      },
      {
        "code" : "95410-7",
        "display" : "SARS coronavirus 2 Ab.neut"
      },
      {
        "code" : "94565-9",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "94564-2",
        "display" : "SARS coronavirus 2 Ab.IgM"
      },
      {
        "code" : "94563-4",
        "display" : "SARS coronavirus 2 Ab.IgG"
      },
      {
        "code" : "94562-6",
        "display" : "SARS coronavirus 2 Ab.IgA"
      },
      {
        "code" : "94559-2",
        "display" : "SARS coronavirus 2 ORF1ab region"
      },
      {
        "code" : "94547-7",
        "display" : "SARS coronavirus 2 Ab.IgG+IgM"
      },
      {
        "code" : "94534-5",
        "display" : "SARS coronavirus 2 RdRp gene"
      },
      {
        "code" : "94533-7",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94532-9",
        "display" : "SARS-related coronavirus+MERS coronavirus RNA"
      },
      {
        "code" : "94531-1",
        "display" : "SARS coronavirus 2 RNA panel"
      },
      {
        "code" : "94511-3",
        "display" : "SARS coronavirus 2 ORF1ab region"
      },
      {
        "code" : "94510-5",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94509-7",
        "display" : "SARS-related coronavirus E gene"
      },
      {
        "code" : "94508-9",
        "display" : "SARS coronavirus 2 Ab.IgM"
      },
      {
        "code" : "94507-1",
        "display" : "SARS coronavirus 2 Ab.IgG"
      },
      {
        "code" : "94506-3",
        "display" : "SARS coronavirus 2 Ab.IgM"
      },
      {
        "code" : "94505-5",
        "display" : "SARS coronavirus 2 Ab.IgG"
      },
      {
        "code" : "94504-8",
        "display" : "SARS coronavirus 2 Ab panel"
      },
      {
        "code" : "94503-0",
        "display" : "SARS coronavirus 2 Ab panel"
      },
      {
        "code" : "94502-2",
        "display" : "SARS-related coronavirus RNA"
      },
      {
        "code" : "94500-6",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "94316-7",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94315-9",
        "display" : "SARS-related coronavirus E gene"
      },
      {
        "code" : "94314-2",
        "display" : "SARS coronavirus 2 RdRp gene"
      },
      {
        "code" : "94313-4",
        "display" : "SARS-related coronavirus N gene"
      },
      {
        "code" : "94312-6",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94311-8",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94310-0",
        "display" : "SARS-related coronavirus N gene"
      },
      {
        "code" : "94309-2",
        "display" : "SARS coronavirus 2 RNA"
      },
      {
        "code" : "94308-4",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94307-6",
        "display" : "SARS coronavirus 2 N gene"
      },
      {
        "code" : "94306-8",
        "display" : "SARS coronavirus 2 RNA panel"
      },
      {
        "code" : "41853-3",
        "display" : "Orthopoxvirus DNA"
      },
      {
        "code" : "100893-7",
        "display" : "Orthopoxvirus IgG & IgM Ab panel"
      },
      {
        "code" : "100892-9",
        "display" : "Orthopoxvirus Ab.IgM"
      },
      {
        "code" : "100891-1",
        "display" : "Orthopoxvirus Ab.IgG"
      },
      {
        "code" : "100889-5",
        "display" : "Monkeypox virus clade I DNA"
      },
      {
        "code" : "100888-7",
        "display" : "Monkeypox virus clade II DNA"
      },
      {
        "code" : "100887-9",
        "display" : "Pseudocowpox virus DNA"
      },
      {
        "code" : "100886-1",
        "display" : "Orf virus DNA"
      },
      {
        "code" : "100885-3",
        "display" : "Parapoxvirus DNA"
      },
      {
        "code" : "100434-0",
        "display" : "Orthopoxvirus.non-variola DNA"
      },
      {
        "code" : "100383-9",
        "display" : "Monkeypox virus DNA"
      }]
    }]
  }
}

```

# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BRCIAP2 - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BRCIAP2**

## CodeSystem: BRCIAP2 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/CodeSystem/BRCIAP2 | *Versão*:1.1.0 |
| Active as of 2026-03-09 | *Nome computável*:BRCIAP2 |

 This Code system is referenced in the content logical definition of the following value sets: 

* [BRCIAP 2](ValueSet-BRCIAP2.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRCIAP2",
  "meta" : {
    "lastUpdated" : "2025-07-14T22:07:09.769+00:00"
  },
  "url" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRCIAP2",
  "version" : "1.1.0",
  "name" : "BRCIAP2",
  "title" : "BRCIAP2",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-03-09T15:10:29-03:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 686,
  "concept" : [{
    "code" : "A93",
    "display" : "Recém nascido prematuro"
  },
  {
    "code" : "A99",
    "display" : "Outras doenças gerais NE"
  },
  {
    "code" : "P16",
    "display" : "Abuso agudo de álcool"
  },
  {
    "code" : "P15",
    "display" : "Abuso crônico de álcool"
  },
  {
    "code" : "P13",
    "display" : "Encoprese/outros problemas de incontinência fecal"
  },
  {
    "code" : "P12",
    "display" : "Molhar a cama/enurese"
  },
  {
    "code" : "P11",
    "display" : "Problemas de alimentação da criança"
  },
  {
    "code" : "P10",
    "display" : "Gaguejar/balbuciar/tiques"
  },
  {
    "code" : "P09",
    "display" : "Preocupação com a preferência sexual"
  },
  {
    "code" : "P08",
    "display" : "Diminuição da satisfação sexual"
  },
  {
    "code" : "P07",
    "display" : "Diminuição do desejo sexual"
  },
  {
    "code" : "Z29",
    "display" : "Problema social NE"
  },
  {
    "code" : "P06",
    "display" : "Perturbação do sono"
  },
  {
    "code" : "Z28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "P05",
    "display" : "Sensação/comportamento senil"
  },
  {
    "code" : "Z27",
    "display" : "Medo de problema social"
  },
  {
    "code" : "P04",
    "display" : "Sentir/comportar-se de forma irritável/zangada"
  },
  {
    "code" : "Z25",
    "display" : "Ato ou acontecimento violento"
  },
  {
    "code" : "P03",
    "display" : "Tristeza/ Sensação de depressão"
  },
  {
    "code" : "Z24",
    "display" : "Problema de relacionamento com amigos"
  },
  {
    "code" : "P02",
    "display" : "Reação aguda ao estresse"
  },
  {
    "code" : "Z23",
    "display" : "Perda/falecimento de familiar"
  },
  {
    "code" : "P01",
    "display" : "Sensação de ansiedade/nervosismo/tensão"
  },
  {
    "code" : "Z22",
    "display" : "Problema por doença familiar"
  },
  {
    "code" : "N99",
    "display" : "Outras doenças do sistema neurológico"
  },
  {
    "code" : "Z21",
    "display" : "Problema comportamental de familiar"
  },
  {
    "code" : "N95",
    "display" : "Cefaléia tensional"
  },
  {
    "code" : "Z20",
    "display" : "Problema de relacionamento com familiares"
  },
  {
    "code" : "N94",
    "display" : "Neurite/ Nevrite/neuropatia periférica"
  },
  {
    "code" : "Z19",
    "display" : "Perda ou falecimento de criança"
  },
  {
    "code" : "N93",
    "display" : "Síndrome do túnel do carpo/ Síndrome do canal cárpico"
  },
  {
    "code" : "Z18",
    "display" : "Problema com criança doente"
  },
  {
    "code" : "N92",
    "display" : "Nevralgia do trigémio"
  },
  {
    "code" : "Z16",
    "display" : "Problema de relacionamento com criança"
  },
  {
    "code" : "N91",
    "display" : "Paralisia facial/paralisia de Bell"
  },
  {
    "code" : "Z15",
    "display" : "Perda ou falecimento do parceiro/ companheiro"
  },
  {
    "code" : "N90",
    "display" : "Cefaléia de cluster"
  },
  {
    "code" : "Z14",
    "display" : "Problema por doença do parceiro/ companheiro"
  },
  {
    "code" : "N89",
    "display" : "Enxaqueca"
  },
  {
    "code" : "Z13",
    "display" : "Problema comportamental do parceiro/ companheiro"
  },
  {
    "code" : "N88",
    "display" : "Epilepsia"
  },
  {
    "code" : "Z12",
    "display" : "Problema de relacionamento com parceiro/ conjugal"
  },
  {
    "code" : "N87",
    "display" : "Parkinsonismo"
  },
  {
    "code" : "Z11",
    "display" : "Problema relacionado com estar doente"
  },
  {
    "code" : "N86",
    "display" : "Esclerose múltipla"
  },
  {
    "code" : "Z10",
    "display" : "Problema relacionado com sistema de saúde"
  },
  {
    "code" : "N85",
    "display" : "Malformações congênitas"
  },
  {
    "code" : "Z09",
    "display" : "Problema de ordem legal"
  },
  {
    "code" : "N81",
    "display" : "Outra lesão do sistema neurológico"
  },
  {
    "code" : "N80",
    "display" : "Outras lesões cranianas"
  },
  {
    "code" : "Z08",
    "display" : "Problema relacionado com sistema de segurança social"
  },
  {
    "code" : "N79",
    "display" : "Concussão"
  },
  {
    "code" : "Z07",
    "display" : "Problemas relacionados com educação"
  },
  {
    "code" : "N76",
    "display" : "Neoplasia do sistema neurológico de natureza incerta"
  },
  {
    "code" : "Z06",
    "display" : "Problemas de desemprego"
  },
  {
    "code" : "N75",
    "display" : "Neoplasia benigna do sistema neurológico"
  },
  {
    "code" : "Z05",
    "display" : "Problemas com condições de trabalho"
  },
  {
    "code" : "N74",
    "display" : "Neoplasia maligna do sistema neurológico"
  },
  {
    "code" : "Z04",
    "display" : "Problema socio-cultural"
  },
  {
    "code" : "N73",
    "display" : "Outra infecção neurológica"
  },
  {
    "code" : "Z03",
    "display" : "Problemas de habitação/vizinhança"
  },
  {
    "code" : "Z02",
    "display" : "Problemas relacionados a água/alimentação"
  },
  {
    "code" : "N72",
    "display" : "Tétano"
  },
  {
    "code" : "N71",
    "display" : "Meningite/encefalite"
  },
  {
    "code" : "Z01",
    "display" : "Pobreza/problemas econômicos"
  },
  {
    "code" : "N70",
    "display" : "Poliomielite"
  },
  {
    "code" : "Y99",
    "display" : "Doença genital masculina, outra"
  },
  {
    "code" : "N29",
    "display" : "Sinais/sintomas do sistema neurológico, outros"
  },
  {
    "code" : "Y86",
    "display" : "Hidrocele"
  },
  {
    "code" : "N28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "Y85",
    "display" : "Hipertrofia benigna da próstata/ hiperplasia prostática benigna"
  },
  {
    "code" : "N27",
    "display" : "Medo de outras doenças neurológicas"
  },
  {
    "code" : "Y84",
    "display" : "Malformação genital congénita masculina, outra"
  },
  {
    "code" : "N26",
    "display" : "Medo de câncer do sistema neurológico"
  },
  {
    "code" : "Y83",
    "display" : "Testículo não descido/ Criptorquidia/ Testículo ectópico"
  },
  {
    "code" : "N19",
    "display" : "Perturbações da fala"
  },
  {
    "code" : "Y82",
    "display" : "Hipospádias"
  },
  {
    "code" : "N18",
    "display" : "Paralisia/fraqueza"
  },
  {
    "code" : "Y81",
    "display" : "Fimose/prepúcio redundante"
  },
  {
    "code" : "N17",
    "display" : "Vertigens/tonturas"
  },
  {
    "code" : "Y80",
    "display" : "Traumatismo genital masculino, outro"
  },
  {
    "code" : "N16",
    "display" : "Alterações do olfato/gosto"
  },
  {
    "code" : "Y79",
    "display" : "Neoplasia benigna genital masculina NE"
  },
  {
    "code" : "N08",
    "display" : "Movimentos involuntários anormais"
  },
  {
    "code" : "Y78",
    "display" : "Neoplasia maligna genital masculina, outra"
  },
  {
    "code" : "N07",
    "display" : "Convulsões/ataques"
  },
  {
    "code" : "Y77",
    "display" : "Neoplasia maligna da próstata"
  },
  {
    "code" : "N06",
    "display" : "Outras alterações da sensibilidade"
  },
  {
    "code" : "Y76",
    "display" : "Condiloma acuminado"
  },
  {
    "code" : "N05",
    "display" : "Formigamento/ parestesia nos dedos das mãos/pés"
  },
  {
    "code" : "Y75",
    "display" : "Balanite/ Balanopostite"
  },
  {
    "code" : "N04",
    "display" : "Síndrome das pernas inquietas"
  },
  {
    "code" : "Y74",
    "display" : "Orquite/epididimite"
  },
  {
    "code" : "N03",
    "display" : "Dores da face"
  },
  {
    "code" : "Y73",
    "display" : "Prostatite/vesiculite seminal"
  },
  {
    "code" : "N01",
    "display" : "Cefaléia"
  },
  {
    "code" : "Y72",
    "display" : "Herpes genital"
  },
  {
    "code" : "L99",
    "display" : "Outra doença do aparelho músculo-esquelético"
  },
  {
    "code" : "Y71",
    "display" : "Gonorréia masculina"
  },
  {
    "code" : "L98",
    "display" : "Malformação adquirida de um membro"
  },
  {
    "code" : "Y70",
    "display" : "Sífilis masculina"
  },
  {
    "code" : "L97",
    "display" : "Neoplasia benigna/incertas"
  },
  {
    "code" : "Y29",
    "display" : "Sinais/sintomas, outros"
  },
  {
    "code" : "L96",
    "display" : "Lesão interna aguda do joelho"
  },
  {
    "code" : "Y28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "L95",
    "display" : "Osteoporose"
  },
  {
    "code" : "Y27",
    "display" : "Medo de doença genital masculina, outra"
  },
  {
    "code" : "L94",
    "display" : "Osteocondrose"
  },
  {
    "code" : "Y26",
    "display" : "Medo de câncer genital masculino"
  },
  {
    "code" : "L93",
    "display" : "Cotovelo de tenista"
  },
  {
    "code" : "Y25",
    "display" : "Medo de doença sexualmente transmissível"
  },
  {
    "code" : "L92",
    "display" : "Síndrome do ombro doloroso"
  },
  {
    "code" : "Y24",
    "display" : "Medo de disfunção sexual masculina"
  },
  {
    "code" : "L91",
    "display" : "Outras osteoartroses"
  },
  {
    "code" : "Y16",
    "display" : "Sinais/sintomas da mama masculina"
  },
  {
    "code" : "L90",
    "display" : "Osteoartrose do joelho"
  },
  {
    "code" : "Y14",
    "display" : "Planejamento familiar, outros"
  },
  {
    "code" : "L89",
    "display" : "Osteoartrose do quadril"
  },
  {
    "code" : "Y13",
    "display" : "Esterilização masculina"
  },
  {
    "code" : "L88",
    "display" : "Artrite reumatóide/seropositiva"
  },
  {
    "code" : "Y10",
    "display" : "Infertilidade/subfertildade masculina"
  },
  {
    "code" : "L87",
    "display" : "Bursite/tendinite/sinovite NE"
  },
  {
    "code" : "Y08",
    "display" : "Sinais/sintomas da função sexual masculina, outros"
  },
  {
    "code" : "L86",
    "display" : "Síndrome vertebral com irradiação dor"
  },
  {
    "code" : "Y07",
    "display" : "Impotência NE"
  },
  {
    "code" : "L85",
    "display" : "Deformação adquirida da coluna"
  },
  {
    "code" : "Y06",
    "display" : "Sinais/sintomas da próstata"
  },
  {
    "code" : "L84",
    "display" : "Doenças ou síndromes da coluna sem irradiação de dor"
  },
  {
    "code" : "Y05",
    "display" : "Sinais/sintomas do escroto/testículos, outros"
  },
  {
    "code" : "Y04",
    "display" : "Sinais/sintomas do pênis, outros"
  },
  {
    "code" : "L83",
    "display" : "Doenças ou síndromes da coluna cervical"
  },
  {
    "code" : "Y03",
    "display" : "Secreção uretral"
  },
  {
    "code" : "L82",
    "display" : "Malformações congênitas do aparelho músculo-esquelético"
  },
  {
    "code" : "Y02",
    "display" : "Dor no escroto/testículos"
  },
  {
    "code" : "L81",
    "display" : "Traumatismos do aparelho musculoesquelético NE"
  },
  {
    "code" : "Y01",
    "display" : "Dor no pênis"
  },
  {
    "code" : "L80",
    "display" : "Luxação/subluxação"
  },
  {
    "code" : "X99",
    "display" : "Doença genital feminina, outra"
  },
  {
    "code" : "L79",
    "display" : "Entorses e distensões das articulações NE"
  },
  {
    "code" : "X92",
    "display" : "Infecção por clamídia"
  },
  {
    "code" : "L78",
    "display" : "Entorses e distensões do joelho"
  },
  {
    "code" : "X91",
    "display" : "Condiloma acuminado feminino"
  },
  {
    "code" : "L77",
    "display" : "Entorses e distensões do tornozelo"
  },
  {
    "code" : "X90",
    "display" : "Herpes genital feminino"
  },
  {
    "code" : "L76",
    "display" : "Outras fraturas"
  },
  {
    "code" : "X89",
    "display" : "Síndrome da tensão pré-menstrual"
  },
  {
    "code" : "L75",
    "display" : "Fratura: fémur"
  },
  {
    "code" : "X88",
    "display" : "Doença fibrocística da mama"
  },
  {
    "code" : "L74",
    "display" : "Fratura: osso da mão/pé"
  },
  {
    "code" : "X87",
    "display" : "Prolapso utero-vaginal"
  },
  {
    "code" : "L73",
    "display" : "Fratura: tíbia/perônio/ fíbula"
  },
  {
    "code" : "X86",
    "display" : "Esfregaço de Papanicolau/colpocitologia oncótica anormal"
  },
  {
    "code" : "L72",
    "display" : "Fratura: rádio/cúbito"
  },
  {
    "code" : "X85",
    "display" : "Doença do colo NE"
  },
  {
    "code" : "L71",
    "display" : "Neoplasia maligna do aparelho músculo-esquelético"
  },
  {
    "code" : "X84",
    "display" : "Vaginite/vulvite NE"
  },
  {
    "code" : "L70",
    "display" : "Infecções do aparelho músculo-esquelético"
  },
  {
    "code" : "X83",
    "display" : "Malformações congênitas genitais"
  },
  {
    "code" : "L29",
    "display" : "Outros sinais/sintomas do aparelho músculo-esquelético"
  },
  {
    "code" : "X82",
    "display" : "Lesão traumática genital feminina"
  },
  {
    "code" : "L28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "X81",
    "display" : "Neoplasia genital feminina, outra/NE"
  },
  {
    "code" : "L27",
    "display" : "Medo de doença no aparelho músculo-esquelético, outro"
  },
  {
    "code" : "X80",
    "display" : "Neoplasia benigna genital"
  },
  {
    "code" : "L26",
    "display" : "Medo de câncer no aparelho músculo-esquelético"
  },
  {
    "code" : "X79",
    "display" : "Neoplasia benigna da mama feminina/ fibroadenoma"
  },
  {
    "code" : "L20",
    "display" : "Sinais/sintomas das articulações NE"
  },
  {
    "code" : "X78",
    "display" : "Fibromioma uterino"
  },
  {
    "code" : "L19",
    "display" : "Sinais/sintomas musculares NE"
  },
  {
    "code" : "X77",
    "display" : "Neoplasia maligna genital feminina, outra"
  },
  {
    "code" : "L18",
    "display" : "Dores musculares"
  },
  {
    "code" : "X76",
    "display" : "Neoplasia maligna da mama feminina"
  },
  {
    "code" : "L17",
    "display" : "Sinais/sintomas do pé/dedos pé"
  },
  {
    "code" : "X75",
    "display" : "Neoplasia maligna do colo"
  },
  {
    "code" : "L16",
    "display" : "Sinais/sintomas do tornozelo"
  },
  {
    "code" : "X74",
    "display" : "Doença inflamatória pélvica"
  },
  {
    "code" : "L15",
    "display" : "Sinais/sintomas do joelho"
  },
  {
    "code" : "X73",
    "display" : "Tricomoníase genital feminina"
  },
  {
    "code" : "L14",
    "display" : "Sinais/sintomas da coxa/perna"
  },
  {
    "code" : "X72",
    "display" : "Candidíase genital feminina"
  },
  {
    "code" : "L13",
    "display" : "Sinais/sintomas do quadril"
  },
  {
    "code" : "X71",
    "display" : "Gonorréia feminina"
  },
  {
    "code" : "L12",
    "display" : "Sinais/sintomas das mãos e dedos"
  },
  {
    "code" : "X70",
    "display" : "Sífilis feminina"
  },
  {
    "code" : "L11",
    "display" : "Sinais/sintomas dos punhos"
  },
  {
    "code" : "X29",
    "display" : "Sinais/sintomas do aparelho genital feminino, outra"
  },
  {
    "code" : "L10",
    "display" : "Sinais/sintomas dos cotovelos"
  },
  {
    "code" : "X28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "L09",
    "display" : "Sinais/sintomas dos braços"
  },
  {
    "code" : "X27",
    "display" : "Medo de outra doença genital/mama"
  },
  {
    "code" : "L08",
    "display" : "Sinais/sintomas dos ombros"
  },
  {
    "code" : "X26",
    "display" : "Medo de câncer na mama"
  },
  {
    "code" : "L07",
    "display" : "Sinais/sintomas da mandíbula"
  },
  {
    "code" : "X25",
    "display" : "Medo de câncer genital"
  },
  {
    "code" : "L05",
    "display" : "Sinais/sintomas da axila"
  },
  {
    "code" : "X24",
    "display" : "Medo de disfunção sexual"
  },
  {
    "code" : "L04",
    "display" : "Sinais/sintomas do tórax"
  },
  {
    "code" : "X23",
    "display" : "Medo de doença de transmissão sexual"
  },
  {
    "code" : "L03",
    "display" : "Sinais/sintomas da região lombar"
  },
  {
    "code" : "X22",
    "display" : "Preocupação com a aparência da mama feminina"
  },
  {
    "code" : "L02",
    "display" : "Sinais/sintomas da região dorsal"
  },
  {
    "code" : "X21",
    "display" : "Sinais/sintomas da mama feminina, outros"
  },
  {
    "code" : "L01",
    "display" : "Sinais/sintomas do pescoço"
  },
  {
    "code" : "X20",
    "display" : "Sinais/sintomas do mamilo da mulher"
  },
  {
    "code" : "K99",
    "display" : "Outras doenças do aparelho circulatório"
  },
  {
    "code" : "X19",
    "display" : "Tumor ou nódulo na mama feminina"
  },
  {
    "code" : "K96",
    "display" : "Hemorróidas"
  },
  {
    "code" : "X18",
    "display" : "Dor na mama feminina"
  },
  {
    "code" : "K95",
    "display" : "Veias varicosas da perna"
  },
  {
    "code" : "X17",
    "display" : "Sinais/sintomas da pélvis feminina"
  },
  {
    "code" : "K94",
    "display" : "Flebite/tromboflebite"
  },
  {
    "code" : "X16",
    "display" : "Sinais/sintomas da vulva"
  },
  {
    "code" : "K93",
    "display" : "Embolia pulmonar"
  },
  {
    "code" : "X15",
    "display" : "Sinais/sintomas da vagina"
  },
  {
    "code" : "K92",
    "display" : "Aterosclerose/doença vascular periférica"
  },
  {
    "code" : "X14",
    "display" : "Secreção vaginal"
  },
  {
    "code" : "K91",
    "display" : "Doença vascular cerebral"
  },
  {
    "code" : "X13",
    "display" : "Hemorragia pós-coital"
  },
  {
    "code" : "K90",
    "display" : "Trombose/acidente vascular cerebral"
  },
  {
    "code" : "X12",
    "display" : "Hemorragia pós-menopausa"
  },
  {
    "code" : "K89",
    "display" : "Isquêmia/ acidente cerebral transitória(o)"
  },
  {
    "code" : "X11",
    "display" : "Sinais/sintomas da menopausa/ climatério"
  },
  {
    "code" : "K88",
    "display" : "Hipotensão postural"
  },
  {
    "code" : "X10",
    "display" : "Desejo de alterar a data menstruação"
  },
  {
    "code" : "K87",
    "display" : "Hipertensão com complicações"
  },
  {
    "code" : "X09",
    "display" : "Sinais/sintomas pré-menstruais"
  },
  {
    "code" : "X08",
    "display" : "Hemorragia intermenstrual"
  },
  {
    "code" : "K86",
    "display" : "Hipertensão sem complicações"
  },
  {
    "code" : "X07",
    "display" : "Menstruação irregular/frequente"
  },
  {
    "code" : "K85",
    "display" : "Pressão arterial elevada"
  },
  {
    "code" : "X06",
    "display" : "Menstruação excessiva"
  },
  {
    "code" : "K84",
    "display" : "Outras doenças cardíacas"
  },
  {
    "code" : "X05",
    "display" : "Menstruação escassa/ausente"
  },
  {
    "code" : "K83",
    "display" : "Doença valvular cardíaca NE"
  },
  {
    "code" : "X04",
    "display" : "Relação sexual dolorosa na mulher"
  },
  {
    "code" : "K82",
    "display" : "Doença cardiopulmonar"
  },
  {
    "code" : "X03",
    "display" : "Dores intermenstruais"
  },
  {
    "code" : "K81",
    "display" : "Sopro cardíaco/arterial NE"
  },
  {
    "code" : "X02",
    "display" : "Dores menstruais"
  },
  {
    "code" : "K80",
    "display" : "Arritmia cardíaca NE"
  },
  {
    "code" : "X01",
    "display" : "Dor genital"
  },
  {
    "code" : "K79",
    "display" : "Taquicardia Paroxística"
  },
  {
    "code" : "W99",
    "display" : "Outros problemas da gravidez/parto"
  },
  {
    "code" : "K78",
    "display" : "Fibrilação/flutter auricular/ atrial"
  },
  {
    "code" : "W96",
    "display" : "Outras complicações do puerpério"
  },
  {
    "code" : "K77",
    "display" : "Insuficiência cardíaca"
  },
  {
    "code" : "W95",
    "display" : "Outros problemas da mama durante gravidez/puerpério"
  },
  {
    "code" : "K76",
    "display" : "Doença cardíaca isquémica sem angina"
  },
  {
    "code" : "W94",
    "display" : "Mastite puerperal"
  },
  {
    "code" : "K75",
    "display" : "Infarto ou Enfarte agudo miocárdio"
  },
  {
    "code" : "W93",
    "display" : "Parto com complicações de natimorto"
  },
  {
    "code" : "K74",
    "display" : "Doença cardíaca isquémica com angina"
  },
  {
    "code" : "W92",
    "display" : "Parto com complicações de nascido vivo"
  },
  {
    "code" : "K73",
    "display" : "Malformações congênitas do aparelho circulatório"
  },
  {
    "code" : "W91",
    "display" : "Parto sem complicações de natimorto"
  },
  {
    "code" : "K72",
    "display" : "Neoplasia do aparelho circulatório"
  },
  {
    "code" : "W90",
    "display" : "Parto sem complicações de nascido vivo"
  },
  {
    "code" : "K71",
    "display" : "Febre reumática/cardiopatia"
  },
  {
    "code" : "W85",
    "display" : "Diabetes gestacional"
  },
  {
    "code" : "K70",
    "display" : "Doença infecciosa do aparelho circulatório"
  },
  {
    "code" : "W84",
    "display" : "Gravidez de alto risco"
  },
  {
    "code" : "K29",
    "display" : "Outros sinais/sintomas cardiovasculares"
  },
  {
    "code" : "W83",
    "display" : "Aborto provocado"
  },
  {
    "code" : "K28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "W82",
    "display" : "Aborto espontâneo"
  },
  {
    "code" : "K27",
    "display" : "Medo de outra doença cardiovascular"
  },
  {
    "code" : "W81",
    "display" : "Toxemia gravídica/ DHEG"
  },
  {
    "code" : "K25",
    "display" : "Medo de hipertensão"
  },
  {
    "code" : "W80",
    "display" : "Gravidez ectópica"
  },
  {
    "code" : "K24",
    "display" : "Medo de doença cardíaca"
  },
  {
    "code" : "W79",
    "display" : "Gravidez não desejada"
  },
  {
    "code" : "W78",
    "display" : "Gravidez"
  },
  {
    "code" : "K22",
    "display" : "Fator de risco para doença cardiovascular"
  },
  {
    "code" : "W76",
    "display" : "Malformação congénita que complica a gravidez"
  },
  {
    "code" : "K07",
    "display" : "Tornozelos inchados/edema"
  },
  {
    "code" : "W75",
    "display" : "Lesões traumáticas que complicam a gravidez"
  },
  {
    "code" : "K06",
    "display" : "Veias proeminentes"
  },
  {
    "code" : "K05",
    "display" : "Outras irregularidades dos batimentos cardíacos"
  },
  {
    "code" : "W73",
    "display" : "Neoplasia benigna/incerta relacionada com a gravidez"
  },
  {
    "code" : "K04",
    "display" : "Palpitações/percepção dos batimentos cardíacos"
  },
  {
    "code" : "W72",
    "display" : "Neoplasia maligna relacionada com gravidez"
  },
  {
    "code" : "K03",
    "display" : "Dores atribuídas ao aparelho circulatório NE"
  },
  {
    "code" : "W71",
    "display" : "Infecções que complicam a gravidez"
  },
  {
    "code" : "K02",
    "display" : "Sensação de pressão/aperto atribuída ao coração"
  },
  {
    "code" : "W70",
    "display" : "Sepsis/infecção puerperal"
  },
  {
    "code" : "K01",
    "display" : "Dor atribuída ao coração"
  },
  {
    "code" : "W29",
    "display" : "Sinais/sintomas da gravidez, outros"
  },
  {
    "code" : "H99",
    "display" : "Outra doença do ouvido/mastóide"
  },
  {
    "code" : "W28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "H86",
    "display" : "Surdez"
  },
  {
    "code" : "W27",
    "display" : "Medo de complicações na gravidez"
  },
  {
    "code" : "H85",
    "display" : "Lesão acústica"
  },
  {
    "code" : "W21",
    "display" : "Preocupação com a imagem corporal na gravidez"
  },
  {
    "code" : "H84",
    "display" : "Presbiacusia"
  },
  {
    "code" : "W19",
    "display" : "Sinais/sintomas da mama/lactação"
  },
  {
    "code" : "W18",
    "display" : "Sinais/sintomas pós-parto"
  },
  {
    "code" : "H83",
    "display" : "Otoesclerose"
  },
  {
    "code" : "W17",
    "display" : "Hemorragia pós-parto"
  },
  {
    "code" : "H82",
    "display" : "Síndrome vertiginosa"
  },
  {
    "code" : "H81",
    "display" : "Cerúmen no ouvido em excesso"
  },
  {
    "code" : "W15",
    "display" : "Infertilidade/subfertildade"
  },
  {
    "code" : "H80",
    "display" : "Malformações congênitas do ouvido"
  },
  {
    "code" : "W14",
    "display" : "Contracepção/outros"
  },
  {
    "code" : "H79",
    "display" : "Outros traumatismos do ouvido"
  },
  {
    "code" : "W13",
    "display" : "Esterilização"
  },
  {
    "code" : "W12",
    "display" : "Contracepção intra-uterina/ Dispositivo Intrauterino/ DIU"
  },
  {
    "code" : "H78",
    "display" : "Traumatismo superficial do ouvido"
  },
  {
    "code" : "W11",
    "display" : "Contracepção oral"
  },
  {
    "code" : "H77",
    "display" : "Perfuração do tímpano"
  },
  {
    "code" : "H76",
    "display" : "Corpo estranho do ouvido"
  },
  {
    "code" : "W10",
    "display" : "Contracepção pós-coital"
  },
  {
    "code" : "W05",
    "display" : "Vómitos/náuseas durante a gravidez"
  },
  {
    "code" : "H75",
    "display" : "Neoplasia do ouvido"
  },
  {
    "code" : "W03",
    "display" : "Hemorragia antes do parto"
  },
  {
    "code" : "H74",
    "display" : "Otite media crónica"
  },
  {
    "code" : "W02",
    "display" : "Medo de estar grávida"
  },
  {
    "code" : "H73",
    "display" : "Infecção da Trompa de Eustáquio"
  },
  {
    "code" : "H72",
    "display" : "Otite média serosa"
  },
  {
    "code" : "W01",
    "display" : "Questão sobre gravidez"
  },
  {
    "code" : "U99",
    "display" : "Outras doenças urinárias"
  },
  {
    "code" : "H71",
    "display" : "Otite media aguda/miringite"
  },
  {
    "code" : "U98",
    "display" : "Análise de urina anormal NE"
  },
  {
    "code" : "H70",
    "display" : "Otite externa"
  },
  {
    "code" : "U95",
    "display" : "Cálculo urinário"
  },
  {
    "code" : "H29",
    "display" : "Outros sinais/sintomas ouvido"
  },
  {
    "code" : "U90",
    "display" : "Albuminúria/proteinúria ortostática"
  },
  {
    "code" : "H28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "U88",
    "display" : "Glomerulonefrite/ sindrome nefrótica"
  },
  {
    "code" : "H27",
    "display" : "Medo de doença do ouvido"
  },
  {
    "code" : "U85",
    "display" : "Malformação congénita do aparelho urinário"
  },
  {
    "code" : "H15",
    "display" : "Preocupação com a aparência das orelhas"
  },
  {
    "code" : "U80",
    "display" : "Lesões traumáticas do aparelho urinário"
  },
  {
    "code" : "H13",
    "display" : "Sensação de ouvido tapado"
  },
  {
    "code" : "U79",
    "display" : "Neoplasia do aparelho urinário NE"
  },
  {
    "code" : "H05",
    "display" : "Hemorragia no ouvido"
  },
  {
    "code" : "U78",
    "display" : "Neoplasia benigna do aparelho urinário"
  },
  {
    "code" : "H04",
    "display" : "Secreção no ouvido"
  },
  {
    "code" : "U77",
    "display" : "Neoplasia maligna do aparelho urinário, outra"
  },
  {
    "code" : "H03",
    "display" : "Acufeno, zumbidos, ruído, assobios"
  },
  {
    "code" : "U76",
    "display" : "Neoplasia benigna do rim"
  },
  {
    "code" : "H02",
    "display" : "Problemas de audição"
  },
  {
    "code" : "U75",
    "display" : "Neoplasia maligna do rim"
  },
  {
    "code" : "H01",
    "display" : "Dor de ouvidos"
  },
  {
    "code" : "U72",
    "display" : "Uretrite"
  },
  {
    "code" : "F99",
    "display" : "Outra doenças oculares/anexos"
  },
  {
    "code" : "U71",
    "display" : "Cistite/outra infecção urinária"
  },
  {
    "code" : "F95",
    "display" : "Estrabismo"
  },
  {
    "code" : "U70",
    "display" : "Pielonefrite"
  },
  {
    "code" : "F94",
    "display" : "Cegueira"
  },
  {
    "code" : "U29",
    "display" : "Sinais/sintomas aparelho urinário, outros"
  },
  {
    "code" : "F93",
    "display" : "Glaucoma"
  },
  {
    "code" : "U28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "F92",
    "display" : "Catarata"
  },
  {
    "code" : "U27",
    "display" : "Medo de outra doença urinária"
  },
  {
    "code" : "F91",
    "display" : "Erro de refração"
  },
  {
    "code" : "U26",
    "display" : "Medo de câncer no aparelho urinário"
  },
  {
    "code" : "F86",
    "display" : "Tracoma"
  },
  {
    "code" : "U14",
    "display" : "Sinais/sintomas dos rins"
  },
  {
    "code" : "U13",
    "display" : "Sinais/sintomas da bexiga, outros"
  },
  {
    "code" : "F85",
    "display" : "Ulcera da córnea"
  },
  {
    "code" : "F84",
    "display" : "Degeneração macular"
  },
  {
    "code" : "U08",
    "display" : "Retenção urinária"
  },
  {
    "code" : "U07",
    "display" : "Outros sinais/sintomas urinários"
  },
  {
    "code" : "F83",
    "display" : "Retinopatia"
  },
  {
    "code" : "U06",
    "display" : "Hematúria"
  },
  {
    "code" : "F82",
    "display" : "Descolamento da retina"
  },
  {
    "code" : "U05",
    "display" : "Outros problemas com a micção"
  },
  {
    "code" : "F81",
    "display" : "Outras malformações congênitas do olho"
  },
  {
    "code" : "U04",
    "display" : "Incontinência urinária"
  },
  {
    "code" : "F80",
    "display" : "Obstrução canal lacrimal da criança"
  },
  {
    "code" : "U02",
    "display" : "Micção frequente/urgência urinária/ polaciúria"
  },
  {
    "code" : "U01",
    "display" : "Disúria/micção dolorosa"
  },
  {
    "code" : "F79",
    "display" : "Outras lesões traumáticas oculares"
  },
  {
    "code" : "T99",
    "display" : "Outras doenças endocrinológica/metabólica/nutricionais"
  },
  {
    "code" : "F76",
    "display" : "Corpo estranho ocular"
  },
  {
    "code" : "T93",
    "display" : "Alteração no metabolismo dos lípidos"
  },
  {
    "code" : "F75",
    "display" : "Contusão/hemorragia ocular"
  },
  {
    "code" : "T92",
    "display" : "Gota"
  },
  {
    "code" : "F74",
    "display" : "Neoplasia do olho/anexos"
  },
  {
    "code" : "F73",
    "display" : "Outras infecções/inflamações oculares"
  },
  {
    "code" : "T91",
    "display" : "Deficiência vitamínica/nutricional"
  },
  {
    "code" : "F72",
    "display" : "Blefarite/hordéolo/calázio"
  },
  {
    "code" : "T90",
    "display" : "Diabetes não insulino-dependente"
  },
  {
    "code" : "F71",
    "display" : "Conjuntivite alérgica"
  },
  {
    "code" : "T89",
    "display" : "Diabetes insulino-dependente"
  },
  {
    "code" : "F70",
    "display" : "Conjuntivite infecciosa"
  },
  {
    "code" : "T87",
    "display" : "Hipoglicemia"
  },
  {
    "code" : "F29",
    "display" : "Outros sinais/sintomas oculares"
  },
  {
    "code" : "T86",
    "display" : "Hipotiroidismo/mixedema"
  },
  {
    "code" : "F28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "T85",
    "display" : "Hipertiroidismo/tireotoxicose"
  },
  {
    "code" : "F27",
    "display" : "Medo de doença ocular"
  },
  {
    "code" : "T83",
    "display" : "Excesso de peso"
  },
  {
    "code" : "F18",
    "display" : "Sinais/sintomas relacionados a lentes de contato"
  },
  {
    "code" : "T82",
    "display" : "Obesidade"
  },
  {
    "code" : "F17",
    "display" : "Sinais/sintomas relacionados a óculos"
  },
  {
    "code" : "T81",
    "display" : "Bócio"
  },
  {
    "code" : "F16",
    "display" : "Sinais/sintomas das pálpebras"
  },
  {
    "code" : "T80",
    "display" : "Malformação congénita endócrina/metabólica"
  },
  {
    "code" : "F15",
    "display" : "Aparência anormal nos olhos"
  },
  {
    "code" : "T78",
    "display" : "Cisto do canal tiroglosso"
  },
  {
    "code" : "F14",
    "display" : "Movimentos oculares anormais"
  },
  {
    "code" : "T73",
    "display" : "Outra neoplasia endócrina NE"
  },
  {
    "code" : "F13",
    "display" : "Sensações oculares anormais"
  },
  {
    "code" : "T72",
    "display" : "Neoplasia benigna da tiróide"
  },
  {
    "code" : "F05",
    "display" : "Outras perturbações visuais"
  },
  {
    "code" : "T71",
    "display" : "Neoplasia maligna da tiróide"
  },
  {
    "code" : "F04",
    "display" : "Moscas volantes/pontos luminosos/escotomas/ manchas"
  },
  {
    "code" : "T70",
    "display" : "Infecção endócrina"
  },
  {
    "code" : "F03",
    "display" : "Secreção ocular"
  },
  {
    "code" : "T29",
    "display" : "Sinais/sintomas endocrinológicos/metabolicos/nutricionais, outros"
  },
  {
    "code" : "F02",
    "display" : "Olho vermelho"
  },
  {
    "code" : "T28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "F01",
    "display" : "Dor no olho"
  },
  {
    "code" : "T27",
    "display" : "Medo de outra doença endócrina/metabólica"
  },
  {
    "code" : "D99",
    "display" : "Outra doença do aparelho digestivo"
  },
  {
    "code" : "T26",
    "display" : "Medo de câncer do sistema endócrino"
  },
  {
    "code" : "D98",
    "display" : "Colecistite, colelitiase"
  },
  {
    "code" : "T11",
    "display" : "Desidratação"
  },
  {
    "code" : "D97",
    "display" : "Doenças do fígado /NE"
  },
  {
    "code" : "T10",
    "display" : "Atraso do crescimento"
  },
  {
    "code" : "D96",
    "display" : "Lombrigas /outros parasitas"
  },
  {
    "code" : "T08",
    "display" : "Perda de peso"
  },
  {
    "code" : "D95",
    "display" : "Fissura anal / abcesso perianal"
  },
  {
    "code" : "T07",
    "display" : "Aumento de peso"
  },
  {
    "code" : "D94",
    "display" : "Enterite crónica/colite ulcerosa"
  },
  {
    "code" : "T05",
    "display" : "Problemas alimentares do adulto"
  },
  {
    "code" : "D93",
    "display" : "Síndrome do cólon irritável"
  },
  {
    "code" : "T04",
    "display" : "Problemas alimentares de lactente/criança"
  },
  {
    "code" : "D92",
    "display" : "Doença diverticular intestinal"
  },
  {
    "code" : "T03",
    "display" : "Perda de apetite"
  },
  {
    "code" : "D91",
    "display" : "Hérnia abdominal, outras"
  },
  {
    "code" : "T02",
    "display" : "Apetite excessivo"
  },
  {
    "code" : "D90",
    "display" : "Hérnia de hiato /diafragmática"
  },
  {
    "code" : "T01",
    "display" : "Sede excessiva"
  },
  {
    "code" : "D89",
    "display" : "Hérnia inguinal"
  },
  {
    "code" : "S99",
    "display" : "Outras doenças da pele"
  },
  {
    "code" : "D88",
    "display" : "Apendicite"
  },
  {
    "code" : "S98",
    "display" : "Urticária"
  },
  {
    "code" : "S97",
    "display" : "Úlcera crónica da pele"
  },
  {
    "code" : "D87",
    "display" : "Alterações funcionais estômago"
  },
  {
    "code" : "D86",
    "display" : "Úlcera péptica, outra"
  },
  {
    "code" : "S96",
    "display" : "Acne"
  },
  {
    "code" : "D85",
    "display" : "Úlcera do duodeno"
  },
  {
    "code" : "S95",
    "display" : "Molusco contagioso"
  },
  {
    "code" : "D84",
    "display" : "Doença do esôfago"
  },
  {
    "code" : "S94",
    "display" : "Unha encravada"
  },
  {
    "code" : "D83",
    "display" : "Doença da boca/língua/lábios"
  },
  {
    "code" : "S93",
    "display" : "Cisto sebáceo"
  },
  {
    "code" : "D82",
    "display" : "Doença dos dentes/gengivas"
  },
  {
    "code" : "S92",
    "display" : "Doença das glândulas sudoríparas"
  },
  {
    "code" : "D81",
    "display" : "Malformações congênitas do aparelho digestivo"
  },
  {
    "code" : "S91",
    "display" : "Psoríase"
  },
  {
    "code" : "S90",
    "display" : "Pitiríase rosada"
  },
  {
    "code" : "D80",
    "display" : "Outras lesões traumáticas"
  },
  {
    "code" : "S89",
    "display" : "Dermatite das fraldas"
  },
  {
    "code" : "D79",
    "display" : "Corpo estranho no aparelho digestivo"
  },
  {
    "code" : "S88",
    "display" : "Dermatite de contato/alérgica"
  },
  {
    "code" : "D78",
    "display" : "Neoplasia benigna do aparelho digestivo/incerta"
  },
  {
    "code" : "S87",
    "display" : "Dermatite/eczema atópico"
  },
  {
    "code" : "D77",
    "display" : "Neoplasia maligna do aparelho digestivo NE"
  },
  {
    "code" : "S86",
    "display" : "Dermatite seborreica"
  },
  {
    "code" : "D76",
    "display" : "Neoplasia maligna do pâncreas"
  },
  {
    "code" : "S85",
    "display" : "Cisto pilonidal/fistula"
  },
  {
    "code" : "D75",
    "display" : "Neoplasia maligna do cólon/reto"
  },
  {
    "code" : "S84",
    "display" : "Impetigo"
  },
  {
    "code" : "D74",
    "display" : "Neoplasia maligna do estômago"
  },
  {
    "code" : "S83",
    "display" : "Lesões da pele congênitas, outras"
  },
  {
    "code" : "D73",
    "display" : "Gastroenterite, presumível infecção"
  },
  {
    "code" : "S82",
    "display" : "Nevos/sinais da pele"
  },
  {
    "code" : "D72",
    "display" : "Hepatite viral"
  },
  {
    "code" : "S81",
    "display" : "Hemangioma/linfangioma"
  },
  {
    "code" : "D71",
    "display" : "Caxumba/parotidite epidêmica"
  },
  {
    "code" : "S80",
    "display" : "Ceratose/ Queratose solar/queimadura solar"
  },
  {
    "code" : "D70",
    "display" : "Infecção gastrointestinal"
  },
  {
    "code" : "S79",
    "display" : "Neoplasia cutânea benigna/incerta"
  },
  {
    "code" : "D29",
    "display" : "Outros sinais/sintomas digestivos"
  },
  {
    "code" : "S78",
    "display" : "Lipoma"
  },
  {
    "code" : "D28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "S77",
    "display" : "Neoplasias malignas da pele"
  },
  {
    "code" : "D27",
    "display" : "Medo de outras doenças aparelho digestivo"
  },
  {
    "code" : "S76",
    "display" : "Outras infecções da pele"
  },
  {
    "code" : "D26",
    "display" : "Medo de câncer no aparelho digestivo"
  },
  {
    "code" : "S75",
    "display" : "Monilíase oral/candidíase na pele"
  },
  {
    "code" : "D25",
    "display" : "Distensão abdominal"
  },
  {
    "code" : "S74",
    "display" : "Dermatofitose"
  },
  {
    "code" : "D24",
    "display" : "Massa abdominal NE"
  },
  {
    "code" : "S73",
    "display" : "Pediculose/outras infecções da pele"
  },
  {
    "code" : "D23",
    "display" : "Hepatomegalia"
  },
  {
    "code" : "S72",
    "display" : "Escabiose/outras acaríases"
  },
  {
    "code" : "D21",
    "display" : "Problemas de deglutição"
  },
  {
    "code" : "S71",
    "display" : "Herpes simples"
  },
  {
    "code" : "D20",
    "display" : "Sinais/sintomas da boca/língua/lábios"
  },
  {
    "code" : "S70",
    "display" : "Herpes zoster"
  },
  {
    "code" : "D19",
    "display" : "Sinais/sintomas dos dentes/gengivas"
  },
  {
    "code" : "S29",
    "display" : "Sinais/sintomas da pele, outros"
  },
  {
    "code" : "D18",
    "display" : "Alterações nas fezes/mov. intestinais"
  },
  {
    "code" : "S28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "D17",
    "display" : "Incontinência fecal"
  },
  {
    "code" : "S27",
    "display" : "Medo de outra doença da pele"
  },
  {
    "code" : "D16",
    "display" : "Hemorragia retal"
  },
  {
    "code" : "S26",
    "display" : "Medo de câncer de pele"
  },
  {
    "code" : "D15",
    "display" : "Melena"
  },
  {
    "code" : "D14",
    "display" : "Hematêmese/vómito sangue"
  },
  {
    "code" : "S24",
    "display" : "Sinais/sintomas do cabelo/couro cabeludo"
  },
  {
    "code" : "D13",
    "display" : "Icterícia"
  },
  {
    "code" : "S23",
    "display" : "Queda de cabelo/calvície"
  },
  {
    "code" : "D12",
    "display" : "Obstipação"
  },
  {
    "code" : "S22",
    "display" : "Sinais/sintomas das unhas"
  },
  {
    "code" : "S21",
    "display" : "Sinais/sintomas da textura da pele"
  },
  {
    "code" : "D11",
    "display" : "Diarreia"
  },
  {
    "code" : "S20",
    "display" : "Calos/calosidades"
  },
  {
    "code" : "D10",
    "display" : "Vomito"
  },
  {
    "code" : "S19",
    "display" : "Outra lesão cutânea"
  },
  {
    "code" : "D09",
    "display" : "Náusea"
  },
  {
    "code" : "S18",
    "display" : "Laceração/corte"
  },
  {
    "code" : "D08",
    "display" : "Flatulência /gases/eructações"
  },
  {
    "code" : "S17",
    "display" : "Abrasão/arranhão/bolhas"
  },
  {
    "code" : "D07",
    "display" : "Dispepsia/indigestão"
  },
  {
    "code" : "S16",
    "display" : "Traumatismo/contusão"
  },
  {
    "code" : "D06",
    "display" : "Outras dores abdominais localizadas"
  },
  {
    "code" : "S15",
    "display" : "Corpo estranho na pele"
  },
  {
    "code" : "D05",
    "display" : "Irritação perianal"
  },
  {
    "code" : "S14",
    "display" : "Queimadura/escaldão"
  },
  {
    "code" : "D04",
    "display" : "Dor anal/retal"
  },
  {
    "code" : "S13",
    "display" : "Mordedura animal/humana"
  },
  {
    "code" : "D03",
    "display" : "Azia/ Queimação"
  },
  {
    "code" : "S12",
    "display" : "Picada ou mordedura de inseto"
  },
  {
    "code" : "D02",
    "display" : "Dores abdominais, epigástricas"
  },
  {
    "code" : "S11",
    "display" : "Infecção pós-traumática da pele"
  },
  {
    "code" : "D01",
    "display" : "Dor abdominal generalizada/cólicas"
  },
  {
    "code" : "S10",
    "display" : "Furúnculo/carbúnculo"
  },
  {
    "code" : "B99",
    "display" : "Outra doença do sangue/linfáticos/baço"
  },
  {
    "code" : "S09",
    "display" : "Infecção dos dedos das mãos/pés"
  },
  {
    "code" : "B90",
    "display" : "Infecção por VIH/ HIV/SIDA/ AIDS"
  },
  {
    "code" : "S08",
    "display" : "Alterações da cor da pele"
  },
  {
    "code" : "B87",
    "display" : "Esplenomegalia"
  },
  {
    "code" : "S07",
    "display" : "Erupção cutânea generalizada"
  },
  {
    "code" : "B84",
    "display" : "Glóbulos brancos anormais"
  },
  {
    "code" : "S06",
    "display" : "Erupção cutânea localizada"
  },
  {
    "code" : "B83",
    "display" : "Púrpura/defeitos de coagulação"
  },
  {
    "code" : "S05",
    "display" : "Tumores/inchaços generalizados"
  },
  {
    "code" : "B82",
    "display" : "Outras anemias NE"
  },
  {
    "code" : "S04",
    "display" : "Tumor/inchaço localizado"
  },
  {
    "code" : "B81",
    "display" : "Anemia perniciosa/deficiência de folatos"
  },
  {
    "code" : "S03",
    "display" : "Verrugas"
  },
  {
    "code" : "B80",
    "display" : "Anemia por deficiência de ferro"
  },
  {
    "code" : "S02",
    "display" : "Prurido"
  },
  {
    "code" : "B79",
    "display" : "Outra malformação congênita do sangue/linfática"
  },
  {
    "code" : "S01",
    "display" : "Dor/sensibilidade dolorosa da pele"
  },
  {
    "code" : "B78",
    "display" : "Anemia hemolítica hereditária"
  },
  {
    "code" : "R99",
    "display" : "Outras doenças respiratórias"
  },
  {
    "code" : "R98",
    "display" : "Síndrome de hiperventilação"
  },
  {
    "code" : "B77",
    "display" : "Outras lesões traumáticas do sangue/linfa/baço"
  },
  {
    "code" : "R97",
    "display" : "Rinite alérgica"
  },
  {
    "code" : "B76",
    "display" : "Rotura traumática do baço"
  },
  {
    "code" : "R96",
    "display" : "Asma"
  },
  {
    "code" : "B75",
    "display" : "Neoplasia benigna NE"
  },
  {
    "code" : "R95",
    "display" : "Doença pulmonar obstrutiva crónica"
  },
  {
    "code" : "B74",
    "display" : "Outra neoplasia maligna no sangue"
  },
  {
    "code" : "R92",
    "display" : "Neoplasia respiratória NE"
  },
  {
    "code" : "B73",
    "display" : "Leucemia"
  },
  {
    "code" : "R90",
    "display" : "Hipertrofia das amígdalas/adenóides"
  },
  {
    "code" : "B72",
    "display" : "Doença de Hodgkin/linfomas"
  },
  {
    "code" : "R89",
    "display" : "Malformação congénita do aparelho respiratório"
  },
  {
    "code" : "B71",
    "display" : "Linfadenite crónica NE"
  },
  {
    "code" : "R88",
    "display" : "Outra lesão respiratória"
  },
  {
    "code" : "B70",
    "display" : "Linfadenite aguda"
  },
  {
    "code" : "R87",
    "display" : "Corpo estranho nariz/laringe/brônquios"
  },
  {
    "code" : "B29",
    "display" : "Outros sinais/ sintomas do sangue/ sistema linfático/ baço NE"
  },
  {
    "code" : "R86",
    "display" : "Neoplasia benigna respiratória"
  },
  {
    "code" : "B28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "R85",
    "display" : "Outra neoplasia respiratória maligna"
  },
  {
    "code" : "B27",
    "display" : "Medo de outras doenças do sangue /vasos linfáticos"
  },
  {
    "code" : "R84",
    "display" : "Neoplasia maligna dos brônquios/pulmão"
  },
  {
    "code" : "B26",
    "display" : "Medo de câncer no sangue/linfático"
  },
  {
    "code" : "R83",
    "display" : "Outra infecção respiratória"
  },
  {
    "code" : "R82",
    "display" : "Pleurite/derrame pleural"
  },
  {
    "code" : "B25",
    "display" : "Medo de VIH/ HIV/SIDA/ AIDS"
  },
  {
    "code" : "R81",
    "display" : "Pneumonia"
  },
  {
    "code" : "B04",
    "display" : "Sinais/sintomas sangue"
  },
  {
    "code" : "R80",
    "display" : "Gripe"
  },
  {
    "code" : "R79",
    "display" : "Bronquite crônica"
  },
  {
    "code" : "B02",
    "display" : "Gânglio linfático aumentado/doloroso"
  },
  {
    "code" : "R78",
    "display" : "Bronquite/bronquiolite aguda"
  },
  {
    "code" : "R77",
    "display" : "Laringite/traqueíte aguda"
  },
  {
    "code" : "R76",
    "display" : "Amigdalite aguda"
  },
  {
    "code" : "A98",
    "display" : "Medicina preventiva/manutenção da saúde"
  },
  {
    "code" : "R75",
    "display" : "Sinusite crónica/aguda"
  },
  {
    "code" : "A97",
    "display" : "Sem doença"
  },
  {
    "code" : "R74",
    "display" : "Infecção aguda do aparelho respiratório superior (IVAS)"
  },
  {
    "code" : "A96",
    "display" : "Morte"
  },
  {
    "code" : "R73",
    "display" : "Abcesso/furúnculo no nariz"
  },
  {
    "code" : "A95",
    "display" : "Mortalidade perinatal"
  },
  {
    "code" : "R72",
    "display" : "Infecção estreptocócica da orofaringe"
  },
  {
    "code" : "A94",
    "display" : "Morbidade perinatal, outra"
  },
  {
    "code" : "R71",
    "display" : "Tosse convulsa/ pertussis"
  },
  {
    "code" : "R29",
    "display" : "Sinais/sintomas do aparelho respiratório, outros"
  },
  {
    "code" : "A92",
    "display" : "Alergia/reação alérgica NE"
  },
  {
    "code" : "R28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "A91",
    "display" : "Investigação com resultado anormal NE"
  },
  {
    "code" : "R27",
    "display" : "Medo de outras doenças respiratórias"
  },
  {
    "code" : "A90",
    "display" : "Malformação congênita NE/múltiplas"
  },
  {
    "code" : "R26",
    "display" : "Medo de câncer do aparelho respiratório"
  },
  {
    "code" : "A89",
    "display" : "Efeito da prótese"
  },
  {
    "code" : "R25",
    "display" : "Expectoração/mucosidade anormal"
  },
  {
    "code" : "A88",
    "display" : "Efeito adverso de fator físico"
  },
  {
    "code" : "R24",
    "display" : "Hemoptise"
  },
  {
    "code" : "A87",
    "display" : "Complicações de tratamento médico"
  },
  {
    "code" : "R23",
    "display" : "Sinais/sintomas da voz"
  },
  {
    "code" : "A86",
    "display" : "Efeito tóxico de substância não medicinal"
  },
  {
    "code" : "R21",
    "display" : "Sinais/sintomas da garganta"
  },
  {
    "code" : "A85",
    "display" : "Efeito adverso de fármaco dose correta"
  },
  {
    "code" : "R09",
    "display" : "Sinais/sintomas dos seios paranasais"
  },
  {
    "code" : "A84",
    "display" : "Intoxicação por medicamento"
  },
  {
    "code" : "R08",
    "display" : "Outros sinais/sintomas nasais"
  },
  {
    "code" : "A82",
    "display" : "Efeito secundário de lesão traumática"
  },
  {
    "code" : "R07",
    "display" : "Espirro/congestão nasal"
  },
  {
    "code" : "A81",
    "display" : "Politraumatismos/ferimentos múltiplos"
  },
  {
    "code" : "R06",
    "display" : "Hemorragia nasal/epistaxe"
  },
  {
    "code" : "A80",
    "display" : "Lesão traumática/acidente NE"
  },
  {
    "code" : "R05",
    "display" : "Tosse"
  },
  {
    "code" : "A79",
    "display" : "Carcinomatose (localização primária desconhecida)"
  },
  {
    "code" : "R04",
    "display" : "Outros problemas respiratórios"
  },
  {
    "code" : "A78",
    "display" : "Hanseníase e outras doenças infecciosas NE"
  },
  {
    "code" : "R03",
    "display" : "Respiração ruidosa"
  },
  {
    "code" : "A77",
    "display" : "Dengue e outras doenças virais NE"
  },
  {
    "code" : "R02",
    "display" : "Dificuldade respiratória, dispneia"
  },
  {
    "code" : "A76",
    "display" : "Outro exantema viral"
  },
  {
    "code" : "R01",
    "display" : "Dor atribuída ao aparelho respiratório"
  },
  {
    "code" : "A75",
    "display" : "Mononucleose infecciosa"
  },
  {
    "code" : "P99",
    "display" : "Outras perturbações psicológicas"
  },
  {
    "code" : "A74",
    "display" : "Rubéola"
  },
  {
    "code" : "P98",
    "display" : "Outras psicoses NE"
  },
  {
    "code" : "A73",
    "display" : "Malária"
  },
  {
    "code" : "P86",
    "display" : "Anorexia nervosa, bulimia"
  },
  {
    "code" : "A72",
    "display" : "Varicela"
  },
  {
    "code" : "P85",
    "display" : "Retardo/ Atraso mental"
  },
  {
    "code" : "A71",
    "display" : "Sarampo"
  },
  {
    "code" : "P82",
    "display" : "Estresse pós traumático"
  },
  {
    "code" : "A70",
    "display" : "Tuberculose"
  },
  {
    "code" : "P81",
    "display" : "Perturbação hipercinética"
  },
  {
    "code" : "A29",
    "display" : "Outros sinais/sintomas gerais"
  },
  {
    "code" : "P80",
    "display" : "Perturbações de personalidade"
  },
  {
    "code" : "A28",
    "display" : "Limitação funcional/incapacidade NE"
  },
  {
    "code" : "P79",
    "display" : "Fobia/perturbação compulsiva"
  },
  {
    "code" : "A27",
    "display" : "Medo de outra doença NE"
  },
  {
    "code" : "P78",
    "display" : "Neurastenia"
  },
  {
    "code" : "A26",
    "display" : "Medo de câncer NE"
  },
  {
    "code" : "P77",
    "display" : "Suicídio/tentativa de suicídio"
  },
  {
    "code" : "A25",
    "display" : "Medo de morrer/medo da morte"
  },
  {
    "code" : "P76",
    "display" : "Perturbações depressivas"
  },
  {
    "code" : "A23",
    "display" : "Fator de risco NE"
  },
  {
    "code" : "P75",
    "display" : "Somatização"
  },
  {
    "code" : "A21",
    "display" : "Fator de risco de malignidade"
  },
  {
    "code" : "P74",
    "display" : "Distúrbio ansioso/estado de ansiedade"
  },
  {
    "code" : "A20",
    "display" : "Pedido/discussão eutanásia"
  },
  {
    "code" : "P73",
    "display" : "Psicose afetiva"
  },
  {
    "code" : "A18",
    "display" : "Preocupação com aparência"
  },
  {
    "code" : "P72",
    "display" : "Esquizofrenia"
  },
  {
    "code" : "A16",
    "display" : "Criança irritável"
  },
  {
    "code" : "P71",
    "display" : "Outras psicoses orgânicas NE"
  },
  {
    "code" : "A13",
    "display" : "Receio/Medo do tratamento"
  },
  {
    "code" : "P70",
    "display" : "Demência"
  },
  {
    "code" : "P29",
    "display" : "Sinais/sintomas psicológicos, outros"
  },
  {
    "code" : "A11",
    "display" : "Dores torácicas NE"
  },
  {
    "code" : "A10",
    "display" : "Sangramento/Hemorragia NE"
  },
  {
    "code" : "P28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "P27",
    "display" : "Medo de perturbações mentais"
  },
  {
    "code" : "A09",
    "display" : "Problemas de sudorese"
  },
  {
    "code" : "P25",
    "display" : "Problemas da fase de vida de adulto"
  },
  {
    "code" : "A08",
    "display" : "Inchaço"
  },
  {
    "code" : "P24",
    "display" : "Dificuldades especificas de aprendizagem"
  },
  {
    "code" : "A07",
    "display" : "Coma"
  },
  {
    "code" : "P23",
    "display" : "Sinais/sintomas relacionados ao comportamento do adolescente"
  },
  {
    "code" : "A06",
    "display" : "Desmaio/síncope"
  },
  {
    "code" : "P22",
    "display" : "Sinais/sintomas relacionados ao comportamento da criança"
  },
  {
    "code" : "A05",
    "display" : "Sentir-se doente"
  },
  {
    "code" : "P20",
    "display" : "Alterações da memória"
  },
  {
    "code" : "A04",
    "display" : "Debilidade/cansaço geral/fadiga"
  },
  {
    "code" : "A03",
    "display" : "Febre"
  },
  {
    "code" : "P19",
    "display" : "Abuso de drogas"
  },
  {
    "code" : "A02",
    "display" : "Arrepios/ calafrios"
  },
  {
    "code" : "P18",
    "display" : "Abuso de medicação"
  },
  {
    "code" : "A01",
    "display" : "Dor generalizada /múltipla"
  },
  {
    "code" : "P17",
    "display" : "Abuso do tabaco"
  }]
}

```

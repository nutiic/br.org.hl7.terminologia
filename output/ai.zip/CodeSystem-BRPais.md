# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BRPais - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BRPais**

## CodeSystem: BRPais 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/CodeSystem/BRPais | *Versão*:1.1.0 |
| Active as of 2026-03-09 | *Nome computável*:BRPais |

 This Code system is referenced in the content logical definition of the following value sets: 

* [BR Pais](ValueSet-BRPais.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRPais",
  "meta" : {
    "lastUpdated" : "2025-07-17T17:40:14.633+00:00"
  },
  "url" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRPais",
  "version" : "1.1.0",
  "name" : "BRPais",
  "title" : "BRPais",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-03-09T15:10:29-03:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 345,
  "concept" : [{
    "code" : "265",
    "display" : "MACAU"
  },
  {
    "code" : "108",
    "display" : "ILHAS COSMOLEDO (LOMORES)"
  },
  {
    "code" : "107",
    "display" : "ILHAS BALEARES"
  },
  {
    "code" : "10",
    "display" : "BRASIL"
  },
  {
    "code" : "272",
    "display" : "PALESTINA"
  },
  {
    "code" : "106",
    "display" : "HUNGRIA"
  },
  {
    "code" : "266",
    "display" : "MALASIA"
  },
  {
    "code" : "271",
    "display" : "OMAN"
  },
  {
    "code" : "101",
    "display" : "ILHAS FAROES"
  },
  {
    "code" : "100",
    "display" : "ESCOCIA"
  },
  {
    "code" : "273",
    "display" : "PAQUISTAO"
  },
  {
    "code" : "105",
    "display" : "HOLANDA"
  },
  {
    "code" : "268",
    "display" : "MASCATE"
  },
  {
    "code" : "27",
    "display" : "EQUADOR"
  },
  {
    "code" : "270",
    "display" : "NEPAL"
  },
  {
    "code" : "267",
    "display" : "MALDIVAS,IS"
  },
  {
    "code" : "269",
    "display" : "MONGOLIA"
  },
  {
    "code" : "102",
    "display" : "FINLANDIA"
  },
  {
    "code" : "104",
    "display" : "GRECIA"
  },
  {
    "code" : "103",
    "display" : "GIBRALTAR"
  },
  {
    "code" : "121",
    "display" : "PAIS DE GALES"
  },
  {
    "code" : "274",
    "display" : "RUIQUIU,IS"
  },
  {
    "code" : "282",
    "display" : "VIETNA DO NORTE"
  },
  {
    "code" : "275",
    "display" : "CINGAPURA"
  },
  {
    "code" : "276",
    "display" : "SEQUIN"
  },
  {
    "code" : "284",
    "display" : "MIANMA"
  },
  {
    "code" : "115",
    "display" : "LIECHTENSTEIN"
  },
  {
    "code" : "120",
    "display" : "REPUBLICA DE MALTA"
  },
  {
    "code" : "280",
    "display" : "TREGUA, ESTADO"
  },
  {
    "code" : "119",
    "display" : "NORUEGA"
  },
  {
    "code" : "116",
    "display" : "LUXEMBURGO"
  },
  {
    "code" : "109",
    "display" : "ILHAS DO CANAL"
  },
  {
    "code" : "117",
    "display" : "ILHAS DE MAN"
  },
  {
    "code" : "281",
    "display" : "TURQUIA"
  },
  {
    "code" : "118",
    "display" : "MONACO"
  },
  {
    "code" : "28",
    "display" : "ANTIGUA E. DEP. BARBUDA"
  },
  {
    "code" : "277",
    "display" : "SIRIA"
  },
  {
    "code" : "113",
    "display" : "ISLANDIA"
  },
  {
    "code" : "114",
    "display" : "IUGOSLAVIA"
  },
  {
    "code" : "278",
    "display" : "SRI-LANKA"
  },
  {
    "code" : "112",
    "display" : "IRLANDA"
  },
  {
    "code" : "110",
    "display" : "INGLATERRA"
  },
  {
    "code" : "279",
    "display" : "TAILANDIA"
  },
  {
    "code" : "111",
    "display" : "IRLANDA DO NORTE"
  },
  {
    "code" : "283",
    "display" : "VIETNA DO SUL"
  },
  {
    "code" : "285",
    "display" : "ARQUIPELAGO MANAHIKI"
  },
  {
    "code" : "294",
    "display" : "ILHAS CANTAO E ENDERBURG"
  },
  {
    "code" : "131",
    "display" : "SERVIA"
  },
  {
    "code" : "122",
    "display" : "PAISES BAIXOS"
  },
  {
    "code" : "293",
    "display" : "ILHAS BAKER"
  },
  {
    "code" : "286",
    "display" : "ARQUIPELAGO MIDWAY"
  },
  {
    "code" : "123",
    "display" : "POLONIA"
  },
  {
    "code" : "292",
    "display" : "GUAM"
  },
  {
    "code" : "127",
    "display" : "SVALBARD E JAN MAYER,IS"
  },
  {
    "code" : "129",
    "display" : "ESTADO DA CIDADE DO VATICANO"
  },
  {
    "code" : "287",
    "display" : "ASHMORE E CARTIER"
  },
  {
    "code" : "124",
    "display" : "ROMENIA"
  },
  {
    "code" : "29",
    "display" : "ANTILHAS HOLANDESAS"
  },
  {
    "code" : "125",
    "display" : "SAN MARINO"
  },
  {
    "code" : "288",
    "display" : "AUSTRALIA"
  },
  {
    "code" : "289",
    "display" : "ARQUIPELAGO DE BISMARK"
  },
  {
    "code" : "295",
    "display" : "ILHAS CAROLINAS"
  },
  {
    "code" : "128",
    "display" : "TCHECOSLOVAQUIA"
  },
  {
    "code" : "290",
    "display" : "ILHAS COOK"
  },
  {
    "code" : "126",
    "display" : "SUECIA"
  },
  {
    "code" : "296",
    "display" : "ILHAS DO PACIFICO"
  },
  {
    "code" : "132",
    "display" : "ESLOVENIA"
  },
  {
    "code" : "133",
    "display" : "REPUBLICA DA MACEDONIA"
  },
  {
    "code" : "130",
    "display" : "CROACIA"
  },
  {
    "code" : "291",
    "display" : "REPUBLICA DE FIJI"
  },
  {
    "code" : "134",
    "display" : "BOSNIA HERZEGOVINA"
  },
  {
    "code" : "297",
    "display" : "ILHAS CHRISTMAS"
  },
  {
    "code" : "146",
    "display" : "DAGESTA"
  },
  {
    "code" : "298",
    "display" : "ILHAS GILBERT"
  },
  {
    "code" : "304",
    "display" : "ILHAS MARSHALL"
  },
  {
    "code" : "305",
    "display" : "ILHAS MACDONAL E HEARD"
  },
  {
    "code" : "300",
    "display" : "ILHA JOHNSTON E SAND"
  },
  {
    "code" : "140",
    "display" : "REPUBLICA DA BIELORRUSSIA"
  },
  {
    "code" : "139",
    "display" : "BASHKISTA"
  },
  {
    "code" : "144",
    "display" : "CHECHEN INGUSTH"
  },
  {
    "code" : "136",
    "display" : "ESLOVAQUIA"
  },
  {
    "code" : "308",
    "display" : "ILHAS PALAU"
  },
  {
    "code" : "145",
    "display" : "CHUVASH"
  },
  {
    "code" : "301",
    "display" : "ILHAS KINGMAN REEF"
  },
  {
    "code" : "30",
    "display" : "ALEMANHA"
  },
  {
    "code" : "303",
    "display" : "ILHAS MARIANAS"
  },
  {
    "code" : "142",
    "display" : "CARELIA"
  },
  {
    "code" : "138",
    "display" : "AZERBAIJAO"
  },
  {
    "code" : "307",
    "display" : "ILHAS NORFOLK"
  },
  {
    "code" : "306",
    "display" : "ILHAS NIUE"
  },
  {
    "code" : "143",
    "display" : "CAZAQUISTAO"
  },
  {
    "code" : "302",
    "display" : "ILHAS MACQUAIRE"
  },
  {
    "code" : "141",
    "display" : "BURYAT"
  },
  {
    "code" : "299",
    "display" : "ILHAS HOWLAND E JARVIS"
  },
  {
    "code" : "137",
    "display" : "MONTENEGRO"
  },
  {
    "code" : "135",
    "display" : "REPUBLICA TCHECA"
  },
  {
    "code" : "309",
    "display" : "ILHAS SALOMAO"
  },
  {
    "code" : "33",
    "display" : "ARUBA"
  },
  {
    "code" : "163",
    "display" : "TURCOMENISTAO"
  },
  {
    "code" : "169",
    "display" : "YAKUT"
  },
  {
    "code" : "148",
    "display" : "GEORGIA"
  },
  {
    "code" : "328",
    "display" : "TERRITORIO DE COCOS"
  },
  {
    "code" : "322",
    "display" : "POLINESIA FRANCESA"
  },
  {
    "code" : "324",
    "display" : "SAMOA AMERICANA"
  },
  {
    "code" : "325",
    "display" : "SAMOA OCIDENTAL"
  },
  {
    "code" : "329",
    "display" : "TIMOR"
  },
  {
    "code" : "170",
    "display" : "ABISSINIA"
  },
  {
    "code" : "161",
    "display" : "TADJIQUISTAO"
  },
  {
    "code" : "312",
    "display" : "KALIMATAN"
  },
  {
    "code" : "162",
    "display" : "TARTARIA"
  },
  {
    "code" : "168",
    "display" : "UZBEQUISTAO"
  },
  {
    "code" : "159",
    "display" : "OSSETIA SETENTRIONAL"
  },
  {
    "code" : "320",
    "display" : "ILHAS PASCOA"
  },
  {
    "code" : "323",
    "display" : "SABAH"
  },
  {
    "code" : "154",
    "display" : "KOMI"
  },
  {
    "code" : "166",
    "display" : "UDMURT"
  },
  {
    "code" : "167",
    "display" : "UNIAO SOVIETICA"
  },
  {
    "code" : "165",
    "display" : "UCRANIA"
  },
  {
    "code" : "316",
    "display" : "NOVA GUINE"
  },
  {
    "code" : "317",
    "display" : "NOVA ZELANDIA"
  },
  {
    "code" : "153",
    "display" : "KHAKASS"
  },
  {
    "code" : "326",
    "display" : "ILHAS SANTA CRUZ"
  },
  {
    "code" : "319",
    "display" : "TERRITORIO DE PAPUA"
  },
  {
    "code" : "147",
    "display" : "ESTONIA"
  },
  {
    "code" : "311",
    "display" : "ILHAS WAKE"
  },
  {
    "code" : "164",
    "display" : "TUVIN"
  },
  {
    "code" : "313",
    "display" : "ILHAS LINHA"
  },
  {
    "code" : "149",
    "display" : "GORNO ALTAI"
  },
  {
    "code" : "151",
    "display" : "KALMIR"
  },
  {
    "code" : "160",
    "display" : "QUIRGUISTAO"
  },
  {
    "code" : "31",
    "display" : "BELGICA"
  },
  {
    "code" : "314",
    "display" : "NAURU"
  },
  {
    "code" : "318",
    "display" : "ILHAS NOVAS HEBRIDAS"
  },
  {
    "code" : "32",
    "display" : "GRA-BRETANHA"
  },
  {
    "code" : "157",
    "display" : "MARI"
  },
  {
    "code" : "315",
    "display" : "ILHAS NOVA CALEDONIA"
  },
  {
    "code" : "321",
    "display" : "ILHAS PITCAIRIN"
  },
  {
    "code" : "158",
    "display" : "MOLDAVIA"
  },
  {
    "code" : "152",
    "display" : "KARACHAEVOCHERKESS"
  },
  {
    "code" : "156",
    "display" : "LITUANIA"
  },
  {
    "code" : "171",
    "display" : "ACORES"
  },
  {
    "code" : "150",
    "display" : "KABARDINO BALKAR"
  },
  {
    "code" : "155",
    "display" : "LETONIA"
  },
  {
    "code" : "310",
    "display" : "ILHAS TOKELAU"
  },
  {
    "code" : "327",
    "display" : "SARAWAK"
  },
  {
    "code" : "172",
    "display" : "AFAR FRANCES"
  },
  {
    "code" : "330",
    "display" : "TONGA"
  },
  {
    "code" : "331",
    "display" : "TUVALU"
  },
  {
    "code" : "173",
    "display" : "REPUBLICA DA AFRICA DO SUL"
  },
  {
    "code" : "196",
    "display" : "GUINE EQUATORIAL"
  },
  {
    "code" : "174",
    "display" : "ALTA VOLTA"
  },
  {
    "code" : "35",
    "display" : "ESPANHA"
  },
  {
    "code" : "332",
    "display" : "ILHAS WALLIS E FUTUNA"
  },
  {
    "code" : "180",
    "display" : "BURUNDI"
  },
  {
    "code" : "350",
    "display" : "TANZANIA"
  },
  {
    "code" : "347",
    "display" : "ARMENIA"
  },
  {
    "code" : "195",
    "display" : "GUINE"
  },
  {
    "code" : "188",
    "display" : "DJIBUTI"
  },
  {
    "code" : "335",
    "display" : "TERR. ANTARTICO DA AUSTRALIA"
  },
  {
    "code" : "175",
    "display" : "ANGOLA"
  },
  {
    "code" : "342",
    "display" : "BANGLADESH"
  },
  {
    "code" : "193",
    "display" : "GANA"
  },
  {
    "code" : "345",
    "display" : "IEMEN DO SUL"
  },
  {
    "code" : "176",
    "display" : "ARGELIA"
  },
  {
    "code" : "183",
    "display" : "CHADE"
  },
  {
    "code" : "334",
    "display" : "ANTARTICA FRANCESA"
  },
  {
    "code" : "348",
    "display" : "RUSSIA"
  },
  {
    "code" : "191",
    "display" : "REPUBLICA DO GABAO"
  },
  {
    "code" : "349",
    "display" : "SENEGAL"
  },
  {
    "code" : "337",
    "display" : "ANTARTICO ARGENTINO"
  },
  {
    "code" : "192",
    "display" : "GAMBIA"
  },
  {
    "code" : "190",
    "display" : "ETIOPIA"
  },
  {
    "code" : "346",
    "display" : "KARA KALPAK"
  },
  {
    "code" : "189",
    "display" : "REPUBLICA ARABE DO EGITO"
  },
  {
    "code" : "341",
    "display" : "TERRAS AUSTRAIS"
  },
  {
    "code" : "194",
    "display" : "GAZA"
  },
  {
    "code" : "352",
    "display" : "REPÚBLICA DO SUDÃO DO SUL"
  },
  {
    "code" : "181",
    "display" : "CAMAROES"
  },
  {
    "code" : "340",
    "display" : "DEPENDENCIA DE ROSS"
  },
  {
    "code" : "177",
    "display" : "BECHUANALANDIA"
  },
  {
    "code" : "344",
    "display" : "GUINE BISSAU"
  },
  {
    "code" : "182",
    "display" : "CEUTA E MELILLA"
  },
  {
    "code" : "186",
    "display" : "COSTA DO MARFIM"
  },
  {
    "code" : "351",
    "display" : "MALAUI"
  },
  {
    "code" : "343",
    "display" : "CABO VERDE"
  },
  {
    "code" : "187",
    "display" : "DAOME"
  },
  {
    "code" : "34",
    "display" : "CANADA"
  },
  {
    "code" : "185",
    "display" : "CONGO"
  },
  {
    "code" : "178",
    "display" : "BENIN"
  },
  {
    "code" : "339",
    "display" : "APATRIDA"
  },
  {
    "code" : "179",
    "display" : "BOTSUANA"
  },
  {
    "code" : "184",
    "display" : "ILHAS COMORES"
  },
  {
    "code" : "338",
    "display" : "ANTARTICO NORUEGUES"
  },
  {
    "code" : "333",
    "display" : "ANTARTICO BRITANICO, TERRITORIO"
  },
  {
    "code" : "336",
    "display" : "ANTARTICO CHILENO"
  },
  {
    "code" : "197",
    "display" : "IFNI"
  },
  {
    "code" : "36",
    "display" : "ESTADOS UNIDOS DA AMERICA (EUA)"
  },
  {
    "code" : "49",
    "display" : "RESERVADO"
  },
  {
    "code" : "353",
    "display" : "ERITREIA"
  },
  {
    "code" : "198",
    "display" : "ASCENSAO E TRISTAO DA CUNHA,IS"
  },
  {
    "code" : "218",
    "display" : "REPUBLICA CENTRO AFRICANA"
  },
  {
    "code" : "46",
    "display" : "BELIZE"
  },
  {
    "code" : "355",
    "display" : "COREIA, REPUBLICA DA (COREIA DO SUL)"
  },
  {
    "code" : "359",
    "display" : "ILHAS DE GUERNSEY"
  },
  {
    "code" : "213",
    "display" : "NIGERIA"
  },
  {
    "code" : "45",
    "display" : "PORTUGAL"
  },
  {
    "code" : "210",
    "display" : "MOCAMBIQUE"
  },
  {
    "code" : "47",
    "display" : "ILHAS TURKS E CAICOS"
  },
  {
    "code" : "39",
    "display" : "ITALIA"
  },
  {
    "code" : "204",
    "display" : "MALAWI"
  },
  {
    "code" : "205",
    "display" : "MADAGASCAR"
  },
  {
    "code" : "212",
    "display" : "REPUBLICA DO NIGER"
  },
  {
    "code" : "43",
    "display" : "COREIA"
  },
  {
    "code" : "211",
    "display" : "NGUANE"
  },
  {
    "code" : "40",
    "display" : "COMUNIDADE DAS BAHAMAS"
  },
  {
    "code" : "203",
    "display" : "MADEIRA"
  },
  {
    "code" : "362",
    "display" : "MAYOTTE, ILHA"
  },
  {
    "code" : "209",
    "display" : "MAURITANIA"
  },
  {
    "code" : "21",
    "display" : "ARGENTINA"
  },
  {
    "code" : "207",
    "display" : "MARROCOS"
  },
  {
    "code" : "361",
    "display" : "ILHAS GEORGIA DO SUL E ILHAS SANDWICH DO SUL"
  },
  {
    "code" : "363",
    "display" : "QUIRIBATI"
  },
  {
    "code" : "199",
    "display" : "ILHAS CANARIAS"
  },
  {
    "code" : "354",
    "display" : "DOMINICA"
  },
  {
    "code" : "356",
    "display" : "CONGO, REPUBLICA DO (BRAZZAVILLE)"
  },
  {
    "code" : "214",
    "display" : "PAPUA NOVA GUINE"
  },
  {
    "code" : "215",
    "display" : "PRACAS NORTE AFRICANAS"
  },
  {
    "code" : "357",
    "display" : "ANGUILLA"
  },
  {
    "code" : "208",
    "display" : "MAURICIO"
  },
  {
    "code" : "206",
    "display" : "MALI"
  },
  {
    "code" : "20",
    "display" : "RESERVADO"
  },
  {
    "code" : "200",
    "display" : "LESOTO"
  },
  {
    "code" : "44",
    "display" : "BARBADOS"
  },
  {
    "code" : "48",
    "display" : "RESERVADO"
  },
  {
    "code" : "42",
    "display" : "CHINA"
  },
  {
    "code" : "202",
    "display" : "LIBIA"
  },
  {
    "code" : "37",
    "display" : "FRANCA"
  },
  {
    "code" : "217",
    "display" : "QUENIA"
  },
  {
    "code" : "216",
    "display" : "PROTETOR DO SUDOESTE AFRICANO"
  },
  {
    "code" : "360",
    "display" : "ILHAS DE JERSEY"
  },
  {
    "code" : "219",
    "display" : "REUNIAO"
  },
  {
    "code" : "41",
    "display" : "JAPAO"
  },
  {
    "code" : "38",
    "display" : "SUICA"
  },
  {
    "code" : "358",
    "display" : "ILHAS CAYMAN"
  },
  {
    "code" : "201",
    "display" : "LIBERIA"
  },
  {
    "code" : "50",
    "display" : "RESERVADO"
  },
  {
    "code" : "22",
    "display" : "BOLIVIA"
  },
  {
    "code" : "236",
    "display" : "ZAIRE"
  },
  {
    "code" : "51",
    "display" : "COSTA RICA"
  },
  {
    "code" : "52",
    "display" : "CUBA"
  },
  {
    "code" : "226",
    "display" : "SERRA LEOA"
  },
  {
    "code" : "58",
    "display" : "ILHAS FALKLANDS"
  },
  {
    "code" : "234",
    "display" : "TUNISIA"
  },
  {
    "code" : "231",
    "display" : "TERRIT. BRITANICO DO OCEANO INDICO"
  },
  {
    "code" : "221",
    "display" : "RUANDA"
  },
  {
    "code" : "62",
    "display" : "REPUBLICA DO HAITI"
  },
  {
    "code" : "59",
    "display" : "GRANADA"
  },
  {
    "code" : "57",
    "display" : "ESTADOS ASSOC. DAS ANTILHAS"
  },
  {
    "code" : "222",
    "display" : "SAARA ESPANHOL"
  },
  {
    "code" : "220",
    "display" : "RODESIA (ZIMBABWE)"
  },
  {
    "code" : "24",
    "display" : "PARAGUAI"
  },
  {
    "code" : "55",
    "display" : "REPUBLICA DOMINICANA"
  },
  {
    "code" : "64",
    "display" : "HONDURAS"
  },
  {
    "code" : "223",
    "display" : "SANTA HELENA"
  },
  {
    "code" : "227",
    "display" : "SOMALIA, REPUBLICA"
  },
  {
    "code" : "230",
    "display" : "TANGANICA"
  },
  {
    "code" : "228",
    "display" : "SUAZILANDIA"
  },
  {
    "code" : "53",
    "display" : "CURACAO"
  },
  {
    "code" : "60",
    "display" : "ILHAS GUADALUPE"
  },
  {
    "code" : "23",
    "display" : "CHILE"
  },
  {
    "code" : "56",
    "display" : "REPUBLICA DE EL SALVADOR"
  },
  {
    "code" : "225",
    "display" : "SEYCHELLES"
  },
  {
    "code" : "67",
    "display" : "ILHAS MALVINAS"
  },
  {
    "code" : "54",
    "display" : "COMUNIDADE DOMINICANA"
  },
  {
    "code" : "237",
    "display" : "ZAMBIA"
  },
  {
    "code" : "61",
    "display" : "GUATEMALA"
  },
  {
    "code" : "229",
    "display" : "SUDAO"
  },
  {
    "code" : "72",
    "display" : "PANAMA"
  },
  {
    "code" : "73",
    "display" : "PANAMA(ZONA DO CANAL)"
  },
  {
    "code" : "232",
    "display" : "TRANSKEI"
  },
  {
    "code" : "71",
    "display" : "NICARAGUA"
  },
  {
    "code" : "224",
    "display" : "SAO TOME E PRINCIPE"
  },
  {
    "code" : "241",
    "display" : "AFEGANISTAO"
  },
  {
    "code" : "65",
    "display" : "ILHAS SERRANAS"
  },
  {
    "code" : "76",
    "display" : "RONCADOR"
  },
  {
    "code" : "233",
    "display" : "TOGO"
  },
  {
    "code" : "69",
    "display" : "ILHA MILHOS"
  },
  {
    "code" : "243",
    "display" : "BAHREIN"
  },
  {
    "code" : "238",
    "display" : "BURKINA FASSO"
  },
  {
    "code" : "242",
    "display" : "ARABIA SAUDITA"
  },
  {
    "code" : "63",
    "display" : "HONDURAS BRITANICAS"
  },
  {
    "code" : "248",
    "display" : "CEILAO"
  },
  {
    "code" : "78",
    "display" : "SAO CRISTOVAO"
  },
  {
    "code" : "79",
    "display" : "SAO VICENTE"
  },
  {
    "code" : "239",
    "display" : "ZIMBABWE"
  },
  {
    "code" : "77",
    "display" : "SANTA LUCIA"
  },
  {
    "code" : "75",
    "display" : "QUITASUENO"
  },
  {
    "code" : "244",
    "display" : "BIRMANIA"
  },
  {
    "code" : "240",
    "display" : "NAMIBIA"
  },
  {
    "code" : "68",
    "display" : "MARTINICA"
  },
  {
    "code" : "74",
    "display" : "PORTO RICO"
  },
  {
    "code" : "80",
    "display" : "ILHAS TURCA"
  },
  {
    "code" : "245",
    "display" : "BRUNEI"
  },
  {
    "code" : "25",
    "display" : "URUGUAI"
  },
  {
    "code" : "247",
    "display" : "CATAR"
  },
  {
    "code" : "86",
    "display" : "ST. PIERRE ET MIQUELON"
  },
  {
    "code" : "249",
    "display" : "CHINA (TAIWAN)"
  },
  {
    "code" : "85",
    "display" : "MEXICO"
  },
  {
    "code" : "235",
    "display" : "UGANDA"
  },
  {
    "code" : "250",
    "display" : "COVEITE"
  },
  {
    "code" : "246",
    "display" : "BHUTAN"
  },
  {
    "code" : "87",
    "display" : "GUIANA FRANCESA"
  },
  {
    "code" : "83",
    "display" : "BERMUDAS"
  },
  {
    "code" : "251",
    "display" : "EMIRADOS ARABES UNIDOS"
  },
  {
    "code" : "84",
    "display" : "GROENLANDIA"
  },
  {
    "code" : "70",
    "display" : "MONTE SERRAT"
  },
  {
    "code" : "252",
    "display" : "FILIPINAS"
  },
  {
    "code" : "81",
    "display" : "ILHAS VIRGENS BRITANICAS"
  },
  {
    "code" : "82",
    "display" : "ILHAS VIRGENS AMERICANAS"
  },
  {
    "code" : "66",
    "display" : "JAMAICA"
  },
  {
    "code" : "88",
    "display" : "REPUBLICA GUIANA"
  },
  {
    "code" : "253",
    "display" : "HONG-KONG"
  },
  {
    "code" : "89",
    "display" : "PERU"
  },
  {
    "code" : "254",
    "display" : "IEMEN"
  },
  {
    "code" : "90",
    "display" : "SURINAME"
  },
  {
    "code" : "92",
    "display" : "VENEZUELA"
  },
  {
    "code" : "255",
    "display" : "INDIA"
  },
  {
    "code" : "91",
    "display" : "TRINIDAD E TOBAGO"
  },
  {
    "code" : "257",
    "display" : "IRA"
  },
  {
    "code" : "258",
    "display" : "IRAQUE"
  },
  {
    "code" : "26",
    "display" : "COLOMBIA"
  },
  {
    "code" : "93",
    "display" : "ALBANIA"
  },
  {
    "code" : "256",
    "display" : "INDONESIA"
  },
  {
    "code" : "94",
    "display" : "ANDORRA"
  },
  {
    "code" : "95",
    "display" : "AUSTRIA"
  },
  {
    "code" : "259",
    "display" : "ISRAEL"
  },
  {
    "code" : "98",
    "display" : "DINAMARCA"
  },
  {
    "code" : "97",
    "display" : "CHIPRE"
  },
  {
    "code" : "96",
    "display" : "BULGARIA"
  },
  {
    "code" : "99",
    "display" : "EIRE"
  },
  {
    "code" : "261",
    "display" : "KMER/CAMBOJA"
  },
  {
    "code" : "260",
    "display" : "JORDANIA"
  },
  {
    "code" : "262",
    "display" : "KUWAIT"
  },
  {
    "code" : "263",
    "display" : "LAOS"
  },
  {
    "code" : "264",
    "display" : "LIBANO"
  }]
}

```

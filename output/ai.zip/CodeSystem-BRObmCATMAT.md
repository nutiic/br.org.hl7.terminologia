# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BRObmCATMAT - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BRObmCATMAT**

## CodeSystem: BRObmCATMAT 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/CodeSystem/BRObmCATMAT | *Versão*:1.1.0 |
| Active as of 2026-03-09 | *Nome computável*:BRObmCATMAT |

 This Code system is referenced in the content logical definition of the following value sets: 

* [BR Terminologia Medicamento](ValueSet-BRTerminologiaMedicamento.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRObmCATMAT",
  "meta" : {
    "lastUpdated" : "2025-07-16T16:50:37.529+00:00"
  },
  "url" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRObmCATMAT",
  "version" : "1.1.0",
  "name" : "BRObmCATMAT",
  "title" : "BRObmCATMAT",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-03-09T15:10:29-03:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 1000,
  "concept" : [{
    "code" : "BR0282714",
    "display" : "Hidróxido de Magnésio 80 mg/mL suspensão oral"
  },
  {
    "code" : "BR0282580",
    "display" : "Oleato de Etanolamina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0282313",
    "display" : "Ciclobenzaprina 10 mg comprimido"
  },
  {
    "code" : "BR0282299",
    "display" : "Sulpirida 50 mg comprimido"
  },
  {
    "code" : "BR0282298",
    "display" : "Sulpirida 20 mg/mL solução oral"
  },
  {
    "code" : "BR0282237",
    "display" : "Carnitina 200 mg/mL xarope"
  },
  {
    "code" : "BR0282224-2",
    "display" : "Carbocisteína 50 mg/mL xarope"
  },
  {
    "code" : "BR0282224-1",
    "display" : "Carbocisteína 50 mg/mL xarope"
  },
  {
    "code" : "BR0282223",
    "display" : "Carbocisteína 50 mg/mL solução oral"
  },
  {
    "code" : "BR0282222-2",
    "display" : "Carbocisteína 20 mg/mL xarope"
  },
  {
    "code" : "BR0282222-1",
    "display" : "Carbocisteína 20 mg/mL xarope"
  },
  {
    "code" : "BR0282220",
    "display" : "Carbacol 0,2 mg/2 mL solução para injeção intraocular; frasco-ampola"
  },
  {
    "code" : "BR0282151",
    "display" : "Exemestano 25 mg comprimido"
  },
  {
    "code" : "BR0282149",
    "display" : "Betametasona 4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0282040",
    "display" : "Gefitinibe 250 mg comprimido"
  },
  {
    "code" : "BR0281470",
    "display" : "Candesartana 8 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0281135-3",
    "display" : "Amoxicilina 40 mg/mL + Ácido Clavulânico 5,7 mg/mL suspensão oral"
  },
  {
    "code" : "BR0281135-2",
    "display" : "Amoxicilina 50 mg/mL + Ácido Clavulânico 12,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0281135-1",
    "display" : "Amoxicilina 50 mg/mL + Ácido Clavulânico 12,5 mg/mL suspensão oral"
  },
  {
    "code" : "BR0280947",
    "display" : "Ofloxacino 200 mg comprimido"
  },
  {
    "code" : "BR0280883",
    "display" : "Glicosamina 1,5 g + Condroitina 1,2 g pó para solução oral"
  },
  {
    "code" : "BR0280881",
    "display" : "Propionato de Fluticasona 250 microgramas/dose + Salmeterol 25 microgramas/dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0280877",
    "display" : "Espironolactona 100 mg + Furosemida 20 mg comprimido"
  },
  {
    "code" : "BR0280876",
    "display" : "Espironolactona 50 mg + Hidroclorotiazida 50 mg comprimido"
  },
  {
    "code" : "BR0280873",
    "display" : "Candesartana 16 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0280627",
    "display" : "Levobupivacaína 0,25% solução para injeção 20 mL; ampola"
  },
  {
    "code" : "BR0280505",
    "display" : "Adefovir 10 mg comprimido"
  },
  {
    "code" : "BR0280205E",
    "display" : "Adefovir 10 mg comprimido"
  },
  {
    "code" : "BR0280201",
    "display" : "Bortezomibe 3,5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0280116E",
    "display" : "Bosentana 62,5 mg comprimido"
  },
  {
    "code" : "BR0280116",
    "display" : "Bosentana 62,5 mg comprimido"
  },
  {
    "code" : "BR0280115E",
    "display" : "Bosentana 125 mg comprimido"
  },
  {
    "code" : "BR0280115",
    "display" : "Bosentana 125 mg comprimido"
  },
  {
    "code" : "BR0279493-6",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-5",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-4",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-3",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-2",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279493-1",
    "display" : "Retinol 5.000 unidades internacionais/g + Colecalciferol 900 unidades internacionais/g + Óxido de Zinco 150 mg/g pomada"
  },
  {
    "code" : "BR0279432",
    "display" : "Loteprednol 5 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0279338-2",
    "display" : "Carbômer 2 mg/g (0,2%) gel oftálmico"
  },
  {
    "code" : "BR0279338-1",
    "display" : "Carbômer 2 mg/g (0,2%) gel oftálmico"
  },
  {
    "code" : "BR0279298",
    "display" : "Fenoterol 0,1 mg /dose + Brometo de Ipratrópio 0,04 mg/dose solução aerossol; inalador"
  },
  {
    "code" : "BR0279297-2",
    "display" : "Nistatina 100.000 unidades internacionais/g + Óxido de Zinco 200 mg/g creme"
  },
  {
    "code" : "BR0279297-1",
    "display" : "Nistatina 100.000 unidades internacionais/g + Óxido de Zinco 200 mg/g creme"
  },
  {
    "code" : "BR0279271",
    "display" : "Varfarina 1 mg comprimido"
  },
  {
    "code" : "BR0279270",
    "display" : "Varfarina 2,5 mg comprimido"
  },
  {
    "code" : "BR0279269",
    "display" : "Varfarina 5 mg comprimido"
  },
  {
    "code" : "BR0279118",
    "display" : "Ticarcilina 3 g + Clavulanato de Potássio 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278649",
    "display" : "Glibenclamida 5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0278648",
    "display" : "Glibenclamida 2,5 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0278647",
    "display" : "Glibenclamida 1,25 mg + Metformina 250 mg comprimido"
  },
  {
    "code" : "BR0278646",
    "display" : "Ácido Épsilon-Aminocaproico 1 g/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278589-2",
    "display" : "Polissulfato de Mucopolissacarídeo 3 mg/g gel"
  },
  {
    "code" : "BR0278589-1",
    "display" : "Polissulfato de Mucopolissacarídeo 3 mg/g gel"
  },
  {
    "code" : "BR0278588-1",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g pomada"
  },
  {
    "code" : "BR0278588",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g pomada"
  },
  {
    "code" : "BR0278587-2",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g gel"
  },
  {
    "code" : "BR0278587-1",
    "display" : "Polissulfato de Mucopolissacarídeo 5 mg/g gel"
  },
  {
    "code" : "BR0278490",
    "display" : "Ácido Fólico 0,4 mg/mL solução oral"
  },
  {
    "code" : "BR0278489",
    "display" : "Ácido Fólico 0,2 mg/mL solução oral"
  },
  {
    "code" : "BR0278482E",
    "display" : "Primidona 250 mg comprimido"
  },
  {
    "code" : "BR0278482",
    "display" : "Primidona 250 mg comprimido"
  },
  {
    "code" : "BR0278429-1",
    "display" : "Bupivacaína 50 mg/20 mL (0,25%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278393",
    "display" : "Tretinoína 10 mg cápsula"
  },
  {
    "code" : "BR0278378",
    "display" : "Tretinoína 0,25 mg/g gel"
  },
  {
    "code" : "BR0278357",
    "display" : "Azelastina 1 mg/mL solução aerossol"
  },
  {
    "code" : "BR0278356",
    "display" : "Azelastina 1 mg/mL solução spray"
  },
  {
    "code" : "BR0278348",
    "display" : "Anastrozol 1 mg comprimido"
  },
  {
    "code" : "BR0278338",
    "display" : "Ácido Tranexâmico 250 mg comprimido"
  },
  {
    "code" : "BR0278316",
    "display" : "Zolpidem 10 mg comprimido"
  },
  {
    "code" : "BR0278283E",
    "display" : "Acetazolamida 250 mg comprimido"
  },
  {
    "code" : "BR0278283",
    "display" : "Acetazolamida 250 mg comprimido"
  },
  {
    "code" : "BR0278281",
    "display" : "Adenosina 6 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0278268-1",
    "display" : "Trifluoperazina 2 mg comprimido"
  },
  {
    "code" : "BR0278268",
    "display" : "Trifluoperazina 5 mg comprimido"
  },
  {
    "code" : "BR0278265",
    "display" : "Hidroxiquinolina 0,04 mg/mL + Trolamina 140 mg/mL solução otológica"
  },
  {
    "code" : "BR0278261",
    "display" : "Tiopental 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278260",
    "display" : "Tiopental 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278259",
    "display" : "Tiocolchicosídeo 4 mg comprimido"
  },
  {
    "code" : "BR0278257",
    "display" : "Tinidazol 500 mg comprimido"
  },
  {
    "code" : "BR0277973",
    "display" : "Ergometrina 0,2 mg comprimido"
  },
  {
    "code" : "BR0277934-1",
    "display" : "Atropina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0277649",
    "display" : "Anagrelida 0,5 mg cápsula"
  },
  {
    "code" : "BR0277526-2",
    "display" : "Didanosina 400 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0277526-1",
    "display" : "Didanosina 400 mg comprimido"
  },
  {
    "code" : "BR0277525-2",
    "display" : "Didanosina 250 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0277519",
    "display" : "Ácido Ursodesoxicólico 50 mg comprimido"
  },
  {
    "code" : "BR0277513",
    "display" : "Fluoxetina 20 mg/mL solução oral"
  },
  {
    "code" : "BR0277438E",
    "display" : "Betainterferona 1b 9.600.000 unidades internacionais (300 microgramas) pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0277435E",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (22 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0277434E",
    "display" : "Betainterferona 1a 12.000.000 unidades internacionais (44 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0277433",
    "display" : "Betainterferona 1a 6.000.000 unidades internacionais (30 microgramas) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0277319-1",
    "display" : "Peróxido de Hidrogênio 3% solução"
  },
  {
    "code" : "BR0277319",
    "display" : "Peróxido de Hidrogênio 3% solução"
  },
  {
    "code" : "BR0277184",
    "display" : "Valganciclovir 450 mg comprimido"
  },
  {
    "code" : "BR0276966",
    "display" : "Telmisartana 80 mg comprimido"
  },
  {
    "code" : "BR0276965",
    "display" : "Telmisartana 40 mg comprimido"
  },
  {
    "code" : "BR0276961",
    "display" : "Tizanidina 2 mg comprimido"
  },
  {
    "code" : "BR0276959",
    "display" : "Alfatirotropina 1,1 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276948",
    "display" : "Trazodona 50 mg comprimido"
  },
  {
    "code" : "BR0276871-4",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276871-3",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276871-2",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276871-1",
    "display" : "Fluoruracila 50 mg/g creme"
  },
  {
    "code" : "BR0276867-1",
    "display" : "Secnidazol 1 g comprimido e Tioconazol 20 mg/g + Tinidazol 30 mg/g creme vaginal"
  },
  {
    "code" : "BR0276867",
    "display" : "Tioconazol 20 mg/g + Tinidazol 30 mg/g creme vaginal"
  },
  {
    "code" : "BR0276866",
    "display" : "Tioconazol 10 mg/mL loção"
  },
  {
    "code" : "BR0276862",
    "display" : "Tioconazol 65 mg/g creme vaginal"
  },
  {
    "code" : "BR0276856",
    "display" : "Acetato de Noretisterona 10 mg comprimido"
  },
  {
    "code" : "BR0276839-9",
    "display" : "Água para injeção 2 mL; ampola"
  },
  {
    "code" : "BR0276839-8",
    "display" : "Água para injeção 100 mL; frasco-ampola"
  },
  {
    "code" : "BR0276839-7",
    "display" : "Água para injeção 2 L; frasco-ampola"
  },
  {
    "code" : "BR0276839-6",
    "display" : "Água para injeção 1 L; bolsa"
  },
  {
    "code" : "BR0276839-5",
    "display" : "Água para injeção 250 mL; frasco-ampola"
  },
  {
    "code" : "BR0276839-4",
    "display" : "Água para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0276839-3",
    "display" : "Água para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0276839-2",
    "display" : "Água para injeção 20 mL; ampola"
  },
  {
    "code" : "BR0276839-10",
    "display" : "Água para injeção 4 mL; ampola"
  },
  {
    "code" : "BR0276839-1",
    "display" : "Água para injeção 5 mL; ampola"
  },
  {
    "code" : "BR0276823",
    "display" : "Anfotericina B Lipossomal 100 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276774",
    "display" : "Acetato de Sódio 20 mEq/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0276670",
    "display" : "Ioxitalamato de Meglumina 350 mg/mL solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "BR0276664",
    "display" : "Iobitridol 300 mg/1 mL solução para injeção 50 mL; frasco-ampola"
  },
  {
    "code" : "BR0276658",
    "display" : "Metoprolol 100 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276657",
    "display" : "Metoprolol 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276656",
    "display" : "Metoprolol 25 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276456",
    "display" : "Silimarina 70 mg + Metionina 100 mg comprimido"
  },
  {
    "code" : "BR0276393",
    "display" : "Cetorolaco 50 mg/mL (5%) solução oftálmica"
  },
  {
    "code" : "BR0276388E",
    "display" : "Galantamina 8 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276388",
    "display" : "Galantamina 8 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276384",
    "display" : "Budesonida 3 mg cápsula gastrorresistente"
  },
  {
    "code" : "BR0276378",
    "display" : "Cilostazol 100 mg comprimido"
  },
  {
    "code" : "BR0276377",
    "display" : "Cilostazol 50 mg comprimido"
  },
  {
    "code" : "BR0276375",
    "display" : "Diltiazem 300 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276374",
    "display" : "Diltiazem 240 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276336",
    "display" : "Amitriptilina 12,5 mg + Clordiazepóxido 5 mg cápsula"
  },
  {
    "code" : "BR0276333",
    "display" : "Amitriptilina 75 mg comprimido"
  },
  {
    "code" : "BR0276332",
    "display" : "Picossulfato de Sódio 0,334 mg/mL + Óleo Mineral 282,25 mg/mL + Ágar-Ágar 2,72 mg/mL emulsão oral"
  },
  {
    "code" : "BR0276283",
    "display" : "Deslanosídeo 0,4 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0276271",
    "display" : "Montelucaste 10 mg comprimido"
  },
  {
    "code" : "BR0276270",
    "display" : "Montelucaste 5 mg comprimido mastigável"
  },
  {
    "code" : "BR0276264",
    "display" : "Anlodipino 5 mg + Ramipril 5 mg cápsula"
  },
  {
    "code" : "BR0276263",
    "display" : "Anlodipino 2,5 mg + Ramipril 5 mg comprimido"
  },
  {
    "code" : "BR0276262",
    "display" : "Ramipril 5 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0276261",
    "display" : "Ramipril 5 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0276260",
    "display" : "Ramipril 2,5 mg comprimido"
  },
  {
    "code" : "BR0276259",
    "display" : "Ramipril 10 mg comprimido"
  },
  {
    "code" : "BR0276258",
    "display" : "Ramipril 5 mg comprimido"
  },
  {
    "code" : "BR0276235",
    "display" : "Insulina Lispro Bifásica (25/75) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0276234-2",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0276234-1",
    "display" : "Insulina Asparte 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0276233-2",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0276233-1",
    "display" : "Insulina Lispro 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0276097",
    "display" : "Bicarbonato de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0276095",
    "display" : "Levotiroxina Sódica 200 microgramas comprimido"
  },
  {
    "code" : "BR0275989-1",
    "display" : "Saccharomyces boulardii 200 mg cápsula"
  },
  {
    "code" : "BR0275989",
    "display" : "Saccharomyces boulardii 200 mg pó para solução oral"
  },
  {
    "code" : "BR0275964",
    "display" : "Finasterida 1 mg comprimido"
  },
  {
    "code" : "BR0275963",
    "display" : "Finasterida 5 mg comprimido"
  },
  {
    "code" : "BR0275944",
    "display" : "Rilmenidina 1 mg comprimido"
  },
  {
    "code" : "BR0275937",
    "display" : "Racecadotrila 100 mg comprimido"
  },
  {
    "code" : "BR0275888",
    "display" : "Colistina 150 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275884",
    "display" : "Colistimetato de Sódio 1.000.000 unidades internacionais pó para solução; frasco-ampola"
  },
  {
    "code" : "BR0275852-2",
    "display" : "Pimecrolimo 10 mg/g creme"
  },
  {
    "code" : "BR0275852-1",
    "display" : "Pimecrolimo 10 mg/g creme"
  },
  {
    "code" : "BR0275651",
    "display" : "Alfacoriogonadotropina 6.500 unidades internacionais (250 microgramas)/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0275478",
    "display" : "Periciazina 10 mg comprimido"
  },
  {
    "code" : "BR0275476",
    "display" : "Dipirona 750 mg/ 2 mL + Prometazina 25 mg/ 2 mL + Adifenina 25 mg/ 2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0275475-3",
    "display" : "Dipirona 500 mg + Prometazina 5 mg + Adifenina 10 mg comprimido"
  },
  {
    "code" : "BR0275475-2",
    "display" : "Dipirona 500 mg/1,5 mL + Prometazina 5 mg/1,5 mL + Adifenina 10 mg/1,5 mL solução oral"
  },
  {
    "code" : "BR0275475-1",
    "display" : "Dipirona 500 mg/1,5 mL + Prometazina 5 mg/1,5 mL + Adifenina 10 mg/1,5 mL solução oral"
  },
  {
    "code" : "BR0275475",
    "display" : "Dipirona 500 mg/1,5 mL + Prometazina 5 mg/1,5 mL + Adifenina 10 mg/1,5 mL solução oral"
  },
  {
    "code" : "BR0275440-3",
    "display" : "Triancinolona Acetonida 100 mg/5 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0275436",
    "display" : "Sucralfato 1g comprimido"
  },
  {
    "code" : "BR0275428-1",
    "display" : "Acetato de Clostebol 5 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "BR0275428",
    "display" : "Acetato de Clostebol 5 mg/g + Neomicina 5 mg/g creme"
  },
  {
    "code" : "BR0275423",
    "display" : "Alteplase 50 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275422",
    "display" : "Alteplase 400 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275402",
    "display" : "Lidocaína 200 mg/20 mL (1%) + Epinefrina 100 microgramas/20 mL (1:200.000) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275124",
    "display" : "Piracetam 800 mg comprimido"
  },
  {
    "code" : "BR0275123",
    "display" : "Piracetam 400 mg comprimido"
  },
  {
    "code" : "BR0275122",
    "display" : "Piracetam 60 mg/mL solução oral"
  },
  {
    "code" : "BR0275121",
    "display" : "Piracetam 1 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0275119",
    "display" : "Prednisolona 20 mg comprimido"
  },
  {
    "code" : "BR0275118",
    "display" : "Prednisolona 5 mg comprimido"
  },
  {
    "code" : "BR0275117",
    "display" : "Nitrendipino 20 mg comprimido"
  },
  {
    "code" : "BR0275116-1",
    "display" : "Nitrendipino 10 mg comprimido"
  },
  {
    "code" : "BR0274996-2",
    "display" : "Ferripolimaltose 10 mg/mL xarope"
  },
  {
    "code" : "BR0274996-1",
    "display" : "Ferripolimaltose 10 mg/mL xarope"
  },
  {
    "code" : "BR0274995-2",
    "display" : "Ferripolimaltose 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274995-1",
    "display" : "Ferripolimaltose 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274995",
    "display" : "Ferripolimaltose 100 mg comprimido mastigável"
  },
  {
    "code" : "BR0274989",
    "display" : "Hidróxido Férrico 100 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274936",
    "display" : "Triancinolona Acetonida 1 mg/g + Neomicina 2,5 mg/g + Gramicidina 0,25 mg/g + Nistatina 100.000 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0274922",
    "display" : "Mesilato de Codergocrina 1 mg cápsula"
  },
  {
    "code" : "BR0274921",
    "display" : "Pindolol 5 mg comprimido"
  },
  {
    "code" : "BR0274918-2",
    "display" : "Retinol 10.000 unidades internacionais/g + Aminoácidos 25 mg/g + Metionina 5 mg/g + Cloranfenicol 5 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0274918-1",
    "display" : "Retinol 10.000 unidades internacionais/g + Aminoácidos 25 mg/g + Metionina 5 mg/g + Cloranfenicol 5 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0274811",
    "display" : "Clonixinato de Lisina 125 mg comprimido"
  },
  {
    "code" : "BR0274808",
    "display" : "Clortalidona 12,5 mg comprimido"
  },
  {
    "code" : "BR0274807",
    "display" : "Betaistina 8 mg comprimido"
  },
  {
    "code" : "BR0274806",
    "display" : "Acetilcisteína 600 mg granulado"
  },
  {
    "code" : "BR0274704",
    "display" : "Imatinibe 400 mg comprimido"
  },
  {
    "code" : "BR0274647",
    "display" : "Sotalol 160 mg comprimido"
  },
  {
    "code" : "BR0274631-2",
    "display" : "Montelucaste 4 mg granulado"
  },
  {
    "code" : "BR0274631-1",
    "display" : "Montelucaste 4 mg comprimido mastigável"
  },
  {
    "code" : "BR0274576",
    "display" : "Di-hidroergocristina 6 mg cápsula"
  },
  {
    "code" : "BR0274575",
    "display" : "Bronfeniramina 12 mg + Fenilefrina 15 mg comprimido"
  },
  {
    "code" : "BR0274573",
    "display" : "Fenilefrina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0274561",
    "display" : "Tropicamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0274527",
    "display" : "Nitrofural 2mg/mL solução"
  },
  {
    "code" : "BR0274506",
    "display" : "Candesartana 8 mg comprimido"
  },
  {
    "code" : "BR0274502-1",
    "display" : "Cefaclor 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0274502",
    "display" : "Cefaclor 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0274497",
    "display" : "Clortalidona 25 mg comprimido"
  },
  {
    "code" : "BR0274482",
    "display" : "Isoxsuprina 10 mg comprimido"
  },
  {
    "code" : "BR0274467-2",
    "display" : "Hialuronato de Sódio 25 mg/2,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0274467-1",
    "display" : "Hialuronato de Sódio 20 mg/2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0274438",
    "display" : "Valsartana 80 mg comprimido"
  },
  {
    "code" : "BR0274393",
    "display" : "Brometo de Ipratrópio 20 microgramas/dose + Salbutamol 100 microgramas/dose suspensão aerossol"
  },
  {
    "code" : "BR0274227",
    "display" : "Sulfato de Glicosamina 500 mg + Sulfato de Condroitina 400 mg cápsula"
  },
  {
    "code" : "BR0274226",
    "display" : "Femprocumona 3 mg comprimido"
  },
  {
    "code" : "BR0274191-2",
    "display" : "Brimonidina 1,5 mg/mL (0,15%) solução oftálmica"
  },
  {
    "code" : "BR0274191-1",
    "display" : "Brimonidina 1,5 mg/mL (0,15%) solução oftálmica"
  },
  {
    "code" : "BR0274150",
    "display" : "Nifedipino 30 mg comprimido"
  },
  {
    "code" : "BR0274149",
    "display" : "Ertapeném 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0274115",
    "display" : "Gelatina 3,5% solução para injeção 500 mL; frasco"
  },
  {
    "code" : "BR0274105",
    "display" : "Penfluridol 20 mg comprimido"
  },
  {
    "code" : "BR0274049-2",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0274049-1",
    "display" : "Propionato de Fluticasona 50 microgramas/dose suspensão spray"
  },
  {
    "code" : "BR0274041",
    "display" : "Piroxicam 5 mg/g gel"
  },
  {
    "code" : "BR0274036-2",
    "display" : "Piroxicam 20 mg cápsula"
  },
  {
    "code" : "BR0274036-1",
    "display" : "Piroxicam 20 mg comprimido"
  },
  {
    "code" : "BR0273953",
    "display" : "Progesterona 100 mg cápsula"
  },
  {
    "code" : "BR0273952",
    "display" : "Progesterona 200 mg cápsula"
  },
  {
    "code" : "BR0273944",
    "display" : "Perindopril Erbumina 4 mg comprimido"
  },
  {
    "code" : "BR0273941",
    "display" : "Paroxetina 30 mg comprimido"
  },
  {
    "code" : "BR0273940",
    "display" : "Paroxetina 20 mg comprimido"
  },
  {
    "code" : "BR0273931",
    "display" : "Orlistate 120 mg cápsula"
  },
  {
    "code" : "BR0273893",
    "display" : "Budesonida 0,25 mg/mL suspensão para inalação 2 mL; frasco"
  },
  {
    "code" : "BR0273892-1",
    "display" : "Budesonida 0,5 mg/mL suspensão para inalação 5 mL; frasco"
  },
  {
    "code" : "BR0273839",
    "display" : "Sibutramina 15 mg comprimido"
  },
  {
    "code" : "BR0273838",
    "display" : "Sibutramina 10 mg comprimido"
  },
  {
    "code" : "BR0273836-2",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0273836-1",
    "display" : "Insulina Glargina 100 unidades/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0273830",
    "display" : "Citidina 2,5 mg + Uridina 1,5 mg + Hidroxocobalamina 1 mg cápsula"
  },
  {
    "code" : "BR0273824",
    "display" : "Ácido Fólico 2 mg comprimido"
  },
  {
    "code" : "BR0273821E",
    "display" : "Sildenafila 50 mg comprimido"
  },
  {
    "code" : "BR0273821",
    "display" : "Sildenafila 50 mg comprimido"
  },
  {
    "code" : "BR0273820E",
    "display" : "Sildenafila 25 mg comprimido"
  },
  {
    "code" : "BR0273820",
    "display" : "Sildenafila 25 mg comprimido"
  },
  {
    "code" : "BR0273818",
    "display" : "Diosmina 450 mg + Hesperidina 50 mg comprimido"
  },
  {
    "code" : "BR0273810",
    "display" : "Olanzapina 2,5 mg comprimido"
  },
  {
    "code" : "BR0273719",
    "display" : "Nitroprusseto de Sódio 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273712",
    "display" : "Nimesulida 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0273711",
    "display" : "Nimesulida 50 mg/mL solução oral"
  },
  {
    "code" : "BR0273710",
    "display" : "Nimesulida 100 mg comprimido"
  },
  {
    "code" : "BR0273706",
    "display" : "Naratriptana 2,5 mg comprimido"
  },
  {
    "code" : "BR0273704",
    "display" : "Naproxeno Sódico 275 mg comprimido"
  },
  {
    "code" : "BR0273703E",
    "display" : "Naproxeno 500 mg comprimido"
  },
  {
    "code" : "BR0273702E",
    "display" : "Naproxeno 250 mg comprimido"
  },
  {
    "code" : "BR0273700",
    "display" : "Tiamazol 5 mg comprimido"
  },
  {
    "code" : "BR0273694",
    "display" : "Metilcelulose 30 mg/1,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0273690",
    "display" : "Metilcelulose 2% solução oftálmica"
  },
  {
    "code" : "BR0273675-2",
    "display" : "Metaraminol 100 mg/ 10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273675-1",
    "display" : "Metaraminol 10 mg/ 1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273675",
    "display" : "Metaraminol 10 mg/ 1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273668",
    "display" : "Mesilato de Pralidoxima 200 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273664",
    "display" : "Mesna 400 mg/4 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273642",
    "display" : "Hidróxido de Alumínio 200 mg + Hidróxido de Magnésio 200 mg comprimido mastigável"
  },
  {
    "code" : "BR0273626",
    "display" : "Fenobarbital 50 mg comprimido"
  },
  {
    "code" : "BR0273621",
    "display" : "Sulfato Ferroso 60 mg comprimido"
  },
  {
    "code" : "BR0273619",
    "display" : "Teclozana 500 mg comprimido"
  },
  {
    "code" : "BR0273618",
    "display" : "Teclozana 10 mg/mL suspensão oral"
  },
  {
    "code" : "BR0273599",
    "display" : "Terbinafina 250 mg comprimido"
  },
  {
    "code" : "BR0273598",
    "display" : "Tioridazina 10 mg comprimido"
  },
  {
    "code" : "BR0273597",
    "display" : "Tioridazina 25 mg comprimido"
  },
  {
    "code" : "BR0273596",
    "display" : "Tioridazina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273589",
    "display" : "Propiltiouracila 100 mg comprimido"
  },
  {
    "code" : "BR0273579",
    "display" : "Cloridrato de Difenidramina 1,5 mg/mL + Paracetamol 12 mg/mL + Pseudoefedrina 1,5 mg/mL + Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "BR0273557",
    "display" : "Ocitocina 5 unidades internacionais/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273555",
    "display" : "Meloxicam 15 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273554",
    "display" : "Meloxicam 15 mg comprimido"
  },
  {
    "code" : "BR0273553",
    "display" : "Meloxicam 7,5 mg comprimido"
  },
  {
    "code" : "BR0273484",
    "display" : "Mometasona 1 mg/g (0,1%) creme"
  },
  {
    "code" : "BR0273483",
    "display" : "Mitotano 500 mg comprimido"
  },
  {
    "code" : "BR0273479",
    "display" : "Minoxidil 10 mg comprimido"
  },
  {
    "code" : "BR0273474",
    "display" : "Milrinona 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273473",
    "display" : "Lorazepam 2 mg comprimido"
  },
  {
    "code" : "BR0273472",
    "display" : "Lorazepam 1 mg comprimido"
  },
  {
    "code" : "BR0273471",
    "display" : "Loratadina 1 mg/mL + Pseudoefedrina 12 mg/mL xarope"
  },
  {
    "code" : "BR0273470",
    "display" : "Loratadina 5 mg + Pseudoefedrina 120 mg comprimido"
  },
  {
    "code" : "BR0273469",
    "display" : "Loratadina 10 mg + Pseudoefedrina 240 mg comprimido"
  },
  {
    "code" : "BR0273467-2",
    "display" : "Loratadina 1 mg/mL xarope"
  },
  {
    "code" : "BR0273467-1",
    "display" : "Loratadina 1 mg/mL xarope"
  },
  {
    "code" : "BR0273467",
    "display" : "Loratadina 1 mg/mL xarope"
  },
  {
    "code" : "BR0273466",
    "display" : "Loratadina 10 mg comprimido"
  },
  {
    "code" : "BR0273457",
    "display" : "Neostigmina 0,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273455",
    "display" : "Mupirocina 20 mg/g creme"
  },
  {
    "code" : "BR0273450",
    "display" : "Moxifloxacino 400 mg comprimido"
  },
  {
    "code" : "BR0273434",
    "display" : "Sorbitol 2,7% + Manitol 0,54% solução para irrigação 1 L; frasco-ampola"
  },
  {
    "code" : "BR0273413",
    "display" : "Linezolida 600 mg/300 mL solução para injeção; frasco"
  },
  {
    "code" : "BR0273412",
    "display" : "Linezolida 600 mg comprimido"
  },
  {
    "code" : "BR0273407",
    "display" : "Letrozol 2,5 mg cápsula"
  },
  {
    "code" : "BR0273404",
    "display" : "Mononitrato de Isossorbida 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273403",
    "display" : "Mononitrato de Isossorbida 50 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0273402",
    "display" : "Mononitrato de Isossorbida 5 mg comprimido sublingual"
  },
  {
    "code" : "BR0273401",
    "display" : "Mononitrato de Isossorbida 40 mg comprimido"
  },
  {
    "code" : "BR0273400",
    "display" : "Mononitrato de Isossorbida 20 mg comprimido"
  },
  {
    "code" : "BR0273396",
    "display" : "Dinitrato de Isossorbida 10 mg comprimido"
  },
  {
    "code" : "BR0273395",
    "display" : "Dinitrato de Isossorbida 5 mg comprimido sublingual"
  },
  {
    "code" : "BR0273390",
    "display" : "Irbesartana 300 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0273389",
    "display" : "Irbesartana 150 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0273388",
    "display" : "Irbesartana 300 mg comprimido"
  },
  {
    "code" : "BR0273387",
    "display" : "Irbesartana 150 mg comprimido"
  },
  {
    "code" : "BR0273328",
    "display" : "Ivermectina 6 mg comprimido"
  },
  {
    "code" : "BR0273320",
    "display" : "Indometacina 50 mg cápsula"
  },
  {
    "code" : "BR0273319",
    "display" : "Indometacina 25 mg cápsula"
  },
  {
    "code" : "BR0273317",
    "display" : "Imatinibe 100 mg comprimido"
  },
  {
    "code" : "BR0273314",
    "display" : "Cianocobalamina 5 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273311",
    "display" : "Hidroxizina 10 mg comprimido"
  },
  {
    "code" : "BR0273310",
    "display" : "Hidroxizina 25 mg comprimido"
  },
  {
    "code" : "BR0273266",
    "display" : "Naltrexona 50 mg comprimido"
  },
  {
    "code" : "BR0273264",
    "display" : "Loperamida 2 mg comprimido"
  },
  {
    "code" : "BR0273258E",
    "display" : "Pamidronato Dissódico 90 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273258",
    "display" : "Pamidronato Dissódico 90 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273257",
    "display" : "Oxcarbazepina 300 mg comprimido"
  },
  {
    "code" : "BR0273256",
    "display" : "Oxcarbazepina 600 mg comprimido"
  },
  {
    "code" : "BR0273255",
    "display" : "Oxcarbazepina 60 mg/mL suspensão oral"
  },
  {
    "code" : "BR0273221",
    "display" : "Memantina 10 mg comprimido"
  },
  {
    "code" : "BR0273195",
    "display" : "Temozolomida 100 mg cápsula"
  },
  {
    "code" : "BR0273194",
    "display" : "Temozolomida 20 mg cápsula"
  },
  {
    "code" : "BR0273193",
    "display" : "Temozolomida 5 mg cápsula"
  },
  {
    "code" : "BR0273192",
    "display" : "Temozolomida 250 mg cápsula"
  },
  {
    "code" : "BR0273167-4",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273167-3",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273167-2",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273167-1",
    "display" : "Neomicina 5 mg/g + Bacitracina 250 unidades internacionais/g pomada"
  },
  {
    "code" : "BR0273166",
    "display" : "Neomicina 3,5 mg/g pomada"
  },
  {
    "code" : "BR0273150",
    "display" : "Deflazacorte 30 mg comprimido"
  },
  {
    "code" : "BR0273149",
    "display" : "Deflazacorte 7,5 mg comprimido"
  },
  {
    "code" : "BR0273148",
    "display" : "Deflazacorte 6 mg comprimido"
  },
  {
    "code" : "BR0273140",
    "display" : "Verapamil 240 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273137",
    "display" : "Diclofenaco Sódico 75 mg comprimido"
  },
  {
    "code" : "BR0273132",
    "display" : "Cloridrato de Difenidramina 10 mg/mL + Calamina 80 mg/mL + Cânfora 1 mg/mL loção"
  },
  {
    "code" : "BR0273121",
    "display" : "Glimepirida 4 mg comprimido"
  },
  {
    "code" : "BR0273120",
    "display" : "Glimepirida 1 mg comprimido"
  },
  {
    "code" : "BR0273119",
    "display" : "Glimepirida 2 mg comprimido"
  },
  {
    "code" : "BR0273116",
    "display" : "Gliclazida 30 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273115",
    "display" : "Gliclazida 80 mg comprimido"
  },
  {
    "code" : "BR0273112",
    "display" : "Griseofulvina 500 mg comprimido"
  },
  {
    "code" : "BR0273011",
    "display" : "Flurazepam 30 mg comprimido"
  },
  {
    "code" : "BR0273009-2",
    "display" : "Fluoxetina 20 mg comprimido"
  },
  {
    "code" : "BR0273009-1",
    "display" : "Fluoxetina 20 mg cápsula"
  },
  {
    "code" : "BR0272996",
    "display" : "Famotidina 40 mg comprimido"
  },
  {
    "code" : "BR0272980",
    "display" : "Fenazopiridina 200 mg comprimido"
  },
  {
    "code" : "BR0272979",
    "display" : "Fenazopiridina 100 mg comprimido"
  },
  {
    "code" : "BR0272974",
    "display" : "Fenoximetilpenicilina Potássica 1.200.000 unidades internacionais solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272972",
    "display" : "Fenoximetilpenicilina Potássica 80.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0272971",
    "display" : "Fenoximetilpenicilina Potássica 500.000 unidades internacionais comprimido"
  },
  {
    "code" : "BR0272948",
    "display" : "Fluoresceína 10% solução para injeção 5 mL; frasco-ampola"
  },
  {
    "code" : "BR0272945",
    "display" : "Fluoresceína 2% solução oftálmica"
  },
  {
    "code" : "BR0272944",
    "display" : "Fluoresceína 1% solução oftálmica"
  },
  {
    "code" : "BR0272931",
    "display" : "Flunitrazepam 1 mg comprimido"
  },
  {
    "code" : "BR0272903",
    "display" : "Citalopram 20 mg comprimido"
  },
  {
    "code" : "BR0272902E",
    "display" : "Clobazam 20 mg comprimido"
  },
  {
    "code" : "BR0272902",
    "display" : "Clobazam 20 mg comprimido"
  },
  {
    "code" : "BR0272901E",
    "display" : "Clobazam 10 mg comprimido"
  },
  {
    "code" : "BR0272901",
    "display" : "Clobazam 10 mg comprimido"
  },
  {
    "code" : "BR0272896",
    "display" : "Dexclorfeniramina 0,4 mg/mL + Betametasona 0,05 mg/mL xarope"
  },
  {
    "code" : "BR0272853E",
    "display" : "Vigabatrina 500 mg comprimido"
  },
  {
    "code" : "BR0272853",
    "display" : "Vigabatrina 500 mg comprimido"
  },
  {
    "code" : "BR0272852E",
    "display" : "Triexifenidil 5 mg comprimido"
  },
  {
    "code" : "BR0272852",
    "display" : "Triexifenidil 5 mg comprimido"
  },
  {
    "code" : "BR0272851E",
    "display" : "Topiramato 100 mg comprimido"
  },
  {
    "code" : "BR0272851",
    "display" : "Topiramato 100 mg comprimido"
  },
  {
    "code" : "BR0272850E",
    "display" : "Topiramato 50 mg comprimido"
  },
  {
    "code" : "BR0272850",
    "display" : "Topiramato 50 mg comprimido"
  },
  {
    "code" : "BR0272849E",
    "display" : "Topiramato 25 mg comprimido"
  },
  {
    "code" : "BR0272849",
    "display" : "Topiramato 25 mg comprimido"
  },
  {
    "code" : "BR0272848",
    "display" : "Tolcapona 200 mg comprimido"
  },
  {
    "code" : "BR0272847E",
    "display" : "Tolcapona 100 mg comprimido"
  },
  {
    "code" : "BR0272846",
    "display" : "Talidomida 100 mg comprimido"
  },
  {
    "code" : "BR0272843",
    "display" : "Sinvastatina 5 mg comprimido"
  },
  {
    "code" : "BR0272839E",
    "display" : "Risperidona 1 mg comprimido"
  },
  {
    "code" : "BR0272839",
    "display" : "Risperidona 1 mg comprimido"
  },
  {
    "code" : "BR0272838E",
    "display" : "Riluzol 50 mg comprimido"
  },
  {
    "code" : "BR0272838",
    "display" : "Riluzol 50 mg comprimido"
  },
  {
    "code" : "BR0272837",
    "display" : "Rifampicina 300 mg cápsula"
  },
  {
    "code" : "BR0392113",
    "display" : "Risperidona 0,25 mg comprimido"
  },
  {
    "code" : "BR0272835E",
    "display" : "Ribavirina 250 mg cápsula"
  },
  {
    "code" : "BR0392111",
    "display" : "Pregabalina 150 mg cápsula"
  },
  {
    "code" : "BR0272835",
    "display" : "Ribavirina 250 mg cápsula"
  },
  {
    "code" : "BR0391938",
    "display" : "Colecalciferol 3.300 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0272834E",
    "display" : "Raloxifeno 60 mg comprimido"
  },
  {
    "code" : "BR0391336E",
    "display" : "Alfataliglicerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272834",
    "display" : "Raloxifeno 60 mg comprimido"
  },
  {
    "code" : "BR0391336",
    "display" : "Alfataliglicerase 200 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272833E",
    "display" : "Quetiapina 200 mg comprimido"
  },
  {
    "code" : "BR0391324",
    "display" : "Hidroquinona 40 mg/g + Tretinoína 0,5 mg/g + Fluocinolona Acetonida 0,1 mg/g creme"
  },
  {
    "code" : "BR0272833",
    "display" : "Quetiapina 200 mg comprimido"
  },
  {
    "code" : "BR0390643",
    "display" : "Tensirolimo 30 mg/1,2 mL solução e diluente para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272832E",
    "display" : "Quetiapina 100 mg comprimido"
  },
  {
    "code" : "BR0272832",
    "display" : "Quetiapina 100 mg comprimido"
  },
  {
    "code" : "BR0390598-3",
    "display" : "Fator VIII (Recombinante) 1.000 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390598-2",
    "display" : "Fator VIII (Recombinante) 500 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272831E",
    "display" : "Quetiapina 25 mg comprimido"
  },
  {
    "code" : "BR0390598-1",
    "display" : "Fator VIII (Recombinante) 250 unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272831",
    "display" : "Quetiapina 25 mg comprimido"
  },
  {
    "code" : "BR0272828",
    "display" : "Primaquina 15 mg comprimido"
  },
  {
    "code" : "BR0390441-2",
    "display" : "Carbômer 3 mg/g (0,3%) gel oftálmico"
  },
  {
    "code" : "BR0272827",
    "display" : "Primaquina 5 mg comprimido"
  },
  {
    "code" : "BR0390441-1",
    "display" : "Carbômer 3 mg/g (0,3%) gel oftálmico"
  },
  {
    "code" : "BR0272826E",
    "display" : "Pramipexol 1 mg comprimido"
  },
  {
    "code" : "BR0390440-2",
    "display" : "Exenatida 600 microgramas/2,4 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0272826",
    "display" : "Pramipexol 1 mg comprimido"
  },
  {
    "code" : "BR0390440-1",
    "display" : "Exenatida 300 microgramas/1,2 mL solução para injeção; dispositivo para injeção"
  },
  {
    "code" : "BR0272825E",
    "display" : "Pramipexol 0,25 mg comprimido"
  },
  {
    "code" : "BR0390354",
    "display" : "Fosamprenavir 50 mg/mL suspensão oral"
  },
  {
    "code" : "BR0272825",
    "display" : "Pramipexol 0,25 mg comprimido"
  },
  {
    "code" : "BR0390333",
    "display" : "Tipranavir 100 mg/mL solução oral"
  },
  {
    "code" : "BR0272824E",
    "display" : "Pramipexol 0,125 mg comprimido"
  },
  {
    "code" : "BR0390008-4",
    "display" : "Cetuximabe 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272824",
    "display" : "Pramipexol 0,125 mg comprimido"
  },
  {
    "code" : "BR0390008-2",
    "display" : "Cetuximabe 100 mg/20 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272822",
    "display" : "Pirazinamida 500 mg comprimido"
  },
  {
    "code" : "BR0390008-1",
    "display" : "Cetuximabe 50 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272817",
    "display" : "Midazolam 15 mg comprimido"
  },
  {
    "code" : "BR0390007",
    "display" : "Quetiapina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272815E",
    "display" : "Penicilamina 250 mg cápsula"
  },
  {
    "code" : "BR0390006E",
    "display" : "Quetiapina 300 mg comprimido"
  },
  {
    "code" : "BR0272815",
    "display" : "Penicilamina 250 mg cápsula"
  },
  {
    "code" : "BR0390006",
    "display" : "Quetiapina 300 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272809E",
    "display" : "Lamotrigina 100 mg comprimido"
  },
  {
    "code" : "BR0390005",
    "display" : "Quetiapina 50 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0272809",
    "display" : "Lamotrigina 100 mg comprimido"
  },
  {
    "code" : "BR0389957-2",
    "display" : "Dipirona 300 mg/mL + Escopolamina 6,5 microgramas/mL + Hiosciamina 104 microgramas/mL + Homatropina 1 mg/mL solução oral"
  },
  {
    "code" : "BR0272808E",
    "display" : "Isotretinoína 20 mg cápsula"
  },
  {
    "code" : "BR0389957-1",
    "display" : "Dipirona 300 mg + Escopolamina 6,5 microgramas + Hiosciamina 104 microgramas + Homatropina 1 mg comprimido"
  },
  {
    "code" : "BR0272808",
    "display" : "Isotretinoína 20 mg cápsula"
  },
  {
    "code" : "BR0389863-1",
    "display" : "Sugamadex 500 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272807E",
    "display" : "Isotretinoína 10 mg cápsula"
  },
  {
    "code" : "BR0389863",
    "display" : "Sugamadex 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272807",
    "display" : "Isotretinoína 10 mg cápsula"
  },
  {
    "code" : "BR0389802",
    "display" : "Gestodeno 0,06 mg + Etinilestradiol 0,015 mg comprimido"
  },
  {
    "code" : "BR0272796",
    "display" : "Heparina Sódica 25.000 unidades internacionais/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0389710",
    "display" : "Adapaleno 3 mg/g gel"
  },
  {
    "code" : "BR0272793E",
    "display" : "Fludrocortisona 0,1 mg comprimido"
  },
  {
    "code" : "BR0389637-2",
    "display" : "Fexofenadina 6 mg/mL suspensão oral"
  },
  {
    "code" : "BR0272793",
    "display" : "Fludrocortisona 0,1 mg comprimido"
  },
  {
    "code" : "BR0389637-1",
    "display" : "Fexofenadina 6 mg/mL solução oral"
  },
  {
    "code" : "BR0272792E",
    "display" : "Etossuximida 50 mg/mL xarope"
  },
  {
    "code" : "BR0389480",
    "display" : "Tobramicina 60 mg/mL solução para inalação 5 mL; ampola"
  },
  {
    "code" : "BR0272792",
    "display" : "Etossuximida 50 mg/mL solução oral"
  },
  {
    "code" : "BR0389398",
    "display" : "Trióxido de Arsênio 10 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272791",
    "display" : "Etossuximida 250 mg comprimido"
  },
  {
    "code" : "BR0388866",
    "display" : "Alentuzumabe 30 mg/ 1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272790",
    "display" : "Etionamida 250 mg comprimido"
  },
  {
    "code" : "BR0388797",
    "display" : "Metformina 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272789U0042",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "BR0388796",
    "display" : "Metformina 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272787E",
    "display" : "Alfadornase 1 mg/mL solução para inalação 2,5 mL; ampola"
  },
  {
    "code" : "BR0388712",
    "display" : "Pregabalina 75 mg cápsula"
  },
  {
    "code" : "BR0272787",
    "display" : "Alfadornase 1 mg/mL solução para inalação 2,5 mL; ampola"
  },
  {
    "code" : "BR0388569",
    "display" : "Ácido Ibandrônico 150 mg comprimido"
  },
  {
    "code" : "BR0272786E",
    "display" : "Donepezila 10 mg comprimido"
  },
  {
    "code" : "BR0388556",
    "display" : "Ornitina 3 g granulado"
  },
  {
    "code" : "BR0272786",
    "display" : "Donepezila 10 mg comprimido"
  },
  {
    "code" : "BR0388555",
    "display" : "Aspartato de Ornitina 5 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272785E",
    "display" : "Donepezila 5 mg comprimido"
  },
  {
    "code" : "BR0388403",
    "display" : "Glimepirida 3 mg comprimido"
  },
  {
    "code" : "BR0272785",
    "display" : "Donepezila 5 mg comprimido"
  },
  {
    "code" : "BR0388402",
    "display" : "Olmesartana Medoxomila 40 mg + Anlodipino 10 mg comprimido"
  },
  {
    "code" : "BR0272784E",
    "display" : "Codeína 3 mg/mL solução oral"
  },
  {
    "code" : "BR0388401",
    "display" : "Olmesartana Medoxomila 40 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0272784",
    "display" : "Codeína 3 mg/mL solução oral"
  },
  {
    "code" : "BR0388399",
    "display" : "Olmesartana Medoxomila 20 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0272782E",
    "display" : "Codeína 30 mg comprimido"
  },
  {
    "code" : "BR0388392",
    "display" : "Rosuvastatina 40 mg comprimido"
  },
  {
    "code" : "BR0272782",
    "display" : "Codeína 30 mg comprimido"
  },
  {
    "code" : "BR0388387",
    "display" : "Levodopa 50 + Carbidopa 12,5 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0272780E",
    "display" : "Cloroquina 150 mg comprimido"
  },
  {
    "code" : "BR0388383E",
    "display" : "Tocilizumabe 80 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272780",
    "display" : "Cloroquina 150 mg comprimido"
  },
  {
    "code" : "BR0272737",
    "display" : "Antimoniato de Meglumina 300 mg/mL solução para injeção 5 mL; ampola"
  },
  {
    "code" : "BR0388383-2",
    "display" : "Tocilizumabe 200 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272690",
    "display" : "Nandrolona 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0388383-1",
    "display" : "Tocilizumabe 80 mg/4 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272689",
    "display" : "Nandrolona 25 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0387985",
    "display" : "Zuclopentixol 25 mg comprimido"
  },
  {
    "code" : "BR0272653E",
    "display" : "Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0387983",
    "display" : "Risperidona 50 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272653",
    "display" : "Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0387982",
    "display" : "Risperidona 37,5 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272645",
    "display" : "Enoxaparina Sódica 40 mg/0,4 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0272644",
    "display" : "Enoxaparina Sódica 20 mg/0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0387981",
    "display" : "Risperidona 25 mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272636",
    "display" : "Enflurano líquido para inalação 100 mL"
  },
  {
    "code" : "BR0387628",
    "display" : "Arginina 250 mg comprimido"
  },
  {
    "code" : "BR0272603-1",
    "display" : "Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "BR0387438",
    "display" : "Cafeína 5 mg/mL xarope"
  },
  {
    "code" : "BR0272603",
    "display" : "Dropropizina 1,5 mg/mL xarope"
  },
  {
    "code" : "BR0387341E",
    "display" : "Formoterol 6 microgramas + Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0272602-3",
    "display" : "Dropropizina 3 mg/mL xarope"
  },
  {
    "code" : "BR0387341",
    "display" : "Formoterol 6 microgramas + Budesonida 200 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0272602",
    "display" : "Dropropizina 3 mg/mL xarope"
  },
  {
    "code" : "BR038719",
    "display" : "Acitretina 10 mg cápsula"
  },
  {
    "code" : "BR0272589",
    "display" : "Divalproato de sódio 500 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0386959",
    "display" : "Paracetamol 32 mg/mL suspensão oral"
  },
  {
    "code" : "BR0272588",
    "display" : "Divalproato de sódio 250 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0386846",
    "display" : "Policarbofila 500 mg comprimido"
  },
  {
    "code" : "BR0272587",
    "display" : "Dissulfiram 250 mg comprimido"
  },
  {
    "code" : "BR0386482",
    "display" : "Fosfato de Cálcio Tribásico 1.661 g (Cálcio 600 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "BR0272585",
    "display" : "Decanoato de Zuclopentixol 200 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0386396",
    "display" : "Amoxicilina 80 mg/mL + Ácido Clavulânico 11,4 mg/mL suspensão oral"
  },
  {
    "code" : "BR0272582U0106",
    "display" : "Timolol 2,5 mg/mL (0,25%) solução oftálmica"
  },
  {
    "code" : "BR0386041",
    "display" : "Hidroxicloroquina 200 mg comprimido"
  },
  {
    "code" : "BR0272581U0106",
    "display" : "Timolol 5 mg/mL (0,5%) solução oftálmica"
  },
  {
    "code" : "BR0386026",
    "display" : "Ácido Folínico 0,5 mg/mL solução oral"
  },
  {
    "code" : "BR0385450",
    "display" : "Hidroquinona 40 mg/g gel"
  },
  {
    "code" : "BR0272581",
    "display" : "Timolol 5 mg/mL (0,5%) solução oftálmica"
  },
  {
    "code" : "BR0385446",
    "display" : "Betametasona 0,5 mg/mL solução oral"
  },
  {
    "code" : "BR0272580E",
    "display" : "Dorzolamida 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0385436",
    "display" : "Betametasona 2 mg comprimido"
  },
  {
    "code" : "BR0272580",
    "display" : "Dorzolamida 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0385435",
    "display" : "Betametasona 0,5 mg comprimido"
  },
  {
    "code" : "BR0272579",
    "display" : "Dorzolamida 20 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0385153",
    "display" : "Trometamol Cetorolaco 10 mg comprimido sublingual"
  },
  {
    "code" : "BR0272573",
    "display" : "Buspirona 10 mg comprimido"
  },
  {
    "code" : "BR0384894",
    "display" : "Propafenona 150 mg comprimido"
  },
  {
    "code" : "BR0272572",
    "display" : "Buspirona 5 mg comprimido"
  },
  {
    "code" : "BR0384830",
    "display" : "Ácido Tranexâmico 500 mg comprimido"
  },
  {
    "code" : "BR0272568-2",
    "display" : "Retinol 50.000 unidades internacionais/mL + Colecalciferol 10.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0384537-2",
    "display" : "Peróxido de Benzoíla 25 mg/g gel"
  },
  {
    "code" : "BR0272568",
    "display" : "Retinol 50.000 unidades internacionais/mL + Colecalciferol 10.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0384537",
    "display" : "Peróxido de Benzoíla 25 mg/g gel"
  },
  {
    "code" : "BR0272567",
    "display" : "Retinol 5.500 unidades internacionais/mL + Colecalciferol 2.200 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0384467",
    "display" : "Nepafenaco 1 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0272565",
    "display" : "Retinol 150.000 unidades internacionais/mL solução oral"
  },
  {
    "code" : "BR0384298",
    "display" : "Hidrocortisona 10 mg comprimido"
  },
  {
    "code" : "BR0272525",
    "display" : "Dipiridamol 10 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0384297",
    "display" : "Mercaptamina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272490",
    "display" : "Dietilestilbestrol 1 mg comprimido"
  },
  {
    "code" : "BR0383791",
    "display" : "Ácido Alendrônico 70 mg + Colecalciferol 2.800 unidades internacionais comprimido"
  },
  {
    "code" : "BR0272489",
    "display" : "Citrato de Dietilcarbamazina 50 mg comprimido"
  },
  {
    "code" : "BR0383790",
    "display" : "Vinorelbina 30 mg cápsula"
  },
  {
    "code" : "BR0272488",
    "display" : "Didanosina 100 mg comprimido"
  },
  {
    "code" : "BR0383788",
    "display" : "Vinorelbina 20 mg cápsula"
  },
  {
    "code" : "BR0272487",
    "display" : "Didanosina 25 mg comprimido"
  },
  {
    "code" : "BR0383786-1",
    "display" : "Vinorelbina 50 mg/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272482",
    "display" : "Zuclopentixol 10 mg comprimido"
  },
  {
    "code" : "BR0383786",
    "display" : "Vinorelbina 10 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383688-1",
    "display" : "Insulina Asparte bifásica (30/70) 100 unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0272478",
    "display" : "Flunarizina 10 mg comprimido"
  },
  {
    "code" : "BR0272477",
    "display" : "Cetirizina 10 mg comprimido"
  },
  {
    "code" : "BR0383688",
    "display" : "Insulina Asparte bifásica (30/70) 100 unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0272476",
    "display" : "Dapsona 100 mg comprimido"
  },
  {
    "code" : "BR0383660",
    "display" : "Brometo de Tiotrópio 2,5 microgramas/dose solução para inalação; inalador"
  },
  {
    "code" : "BR0272475",
    "display" : "Dantroleno 20 mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383485",
    "display" : "Tenecteplase 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272473E",
    "display" : "Danazol 100 mg cápsula"
  },
  {
    "code" : "BR0383436",
    "display" : "Azacitidina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272473",
    "display" : "Danazol 100 mg comprimido"
  },
  {
    "code" : "BR0383417",
    "display" : "Ciclesonida 160 microgramas solução para inalação"
  },
  {
    "code" : "BR0272472E",
    "display" : "Danazol 200 mg cápsula"
  },
  {
    "code" : "BR0383409-3",
    "display" : "Carmelose Sódica 5 mg/mL (0,5%) + Glicerol 9 mg/mL (0,9%) solução oftálmica"
  },
  {
    "code" : "BR0272471E",
    "display" : "Danazol 50 mg cápsula"
  },
  {
    "code" : "BR0383409",
    "display" : "Carmelose Sódica 5 mg/mL (0,5%) + Glicerol 9 mg/mL (0,9%) solução oftálmica"
  },
  {
    "code" : "BR0272470",
    "display" : "Dalteparina Sódica 2.500 unidades internacionais /0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0383272E",
    "display" : "Imiglucerase 400 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272469",
    "display" : "Dalteparina Sódica 5.000 unidades internacionais /0,2 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0383272",
    "display" : "Imiglucerase 400 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272458",
    "display" : "Carbamazepina 200 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0382939",
    "display" : "Decitabina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272457",
    "display" : "Carbamazepina 400 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0382563",
    "display" : "Cloreto de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0272454-2",
    "display" : "Carbamazepina 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0382197",
    "display" : "Trimetazidina 35 mg comprimido"
  },
  {
    "code" : "BR0272454-1",
    "display" : "Carbamazepina 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0381881",
    "display" : "Omeprazol 40 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0381880",
    "display" : "Omeprazol 20 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0272445",
    "display" : "Ciclofenila 200 mg comprimido"
  },
  {
    "code" : "BR0272435",
    "display" : "Anlodipino 2,5 mg comprimido"
  },
  {
    "code" : "BR0381879",
    "display" : "Omeprazol 10 mg comprimido gastrorresistente"
  },
  {
    "code" : "BR0272434",
    "display" : "Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0381288",
    "display" : "Rifabutina 150 mg cápsula"
  },
  {
    "code" : "BR0272431E",
    "display" : "Clozapina 100 mg comprimido"
  },
  {
    "code" : "BR0381073",
    "display" : "Mercaptamina 150 mg comprimido"
  },
  {
    "code" : "BR0272431",
    "display" : "Clozapina 100 mg comprimido"
  },
  {
    "code" : "BR0381066",
    "display" : "Anlodipino 5 mg + Ramipril 10 mg cápsula"
  },
  {
    "code" : "BR0272429E",
    "display" : "Clozapina 25 mg comprimido"
  },
  {
    "code" : "BR0381063",
    "display" : "Sitagliptina 50 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0272429",
    "display" : "Clozapina 25 mg comprimido"
  },
  {
    "code" : "BR0380865",
    "display" : "Polimixina B 10.000 unidades internacionais/mL + Neomicina 3,5 mg/mL + Fluocinolona 0,25 mg/mL + Lidocaína 20 mg/mL solução otológica"
  },
  {
    "code" : "BR0272423-3",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0380855",
    "display" : "Diclofenaco Dietilamônio 11,6 mg/g solução aerossol"
  },
  {
    "code" : "BR0272423-2",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0380823",
    "display" : "Paliperidona 6 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272423-1",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0380545",
    "display" : "Lopinavir 100 mg + Ritonavir 25 mg comprimido"
  },
  {
    "code" : "BR0272423",
    "display" : "Clotrimazol 10 mg/g (1%) creme"
  },
  {
    "code" : "BR0380419",
    "display" : "Bimatoprosta 0,3 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272420",
    "display" : "Clortalidona 50 mg comprimido"
  },
  {
    "code" : "BR0380017",
    "display" : "Insulina Glulisina 100 unidades internacionais/mL solução para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0272417",
    "display" : "Cloroquina 250 mg comprimido"
  },
  {
    "code" : "BR0379962",
    "display" : "Oseltamivir 45 mg cápsula"
  },
  {
    "code" : "BR0272412",
    "display" : "Propafenona 300 mg comprimido"
  },
  {
    "code" : "BR0379902",
    "display" : "Oseltamivir 30 mg cápsula"
  },
  {
    "code" : "BR0272411",
    "display" : "Nafazolina 0,5 mg/mL + Zinco 1 mg/mL + Berberina 0,025 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0379469-2",
    "display" : "Hidrato de Cloral 100 mg/mL (10%) solução oral"
  },
  {
    "code" : "BR0272410",
    "display" : "Fluocinolona 0,25 mg/mL + Nafazolina 0,5 mg/mL + Zinco 4 mg/mL + Neomicina 7 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0379469-1",
    "display" : "Hidrato de Cloral 100 mg/mL (10%) solução oral"
  },
  {
    "code" : "BR0272406",
    "display" : "Nafazolina 0,25 mg/mL + Feniramina 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0379002",
    "display" : "Anidulafungina 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272402",
    "display" : "Nafazolina 0,5 mg/mL + Cloreto de Benzalcônio 0,1 mg/mL solução nasal"
  },
  {
    "code" : "BR0378055",
    "display" : "Fosfomicina 3 g granulado"
  },
  {
    "code" : "BR0272400-1",
    "display" : "Nafazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "BR0377899",
    "display" : "Valeriana officinalis 50 mg cápsula"
  },
  {
    "code" : "BR0272400",
    "display" : "Nafazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "BR0377422",
    "display" : "Ácido Fusídico 20 mg/g + Valerato de Betametasona 1 mg/g creme"
  },
  {
    "code" : "BR0272383",
    "display" : "Venlafaxina 50 mg comprimido"
  },
  {
    "code" : "BR0377008",
    "display" : "Zanamivir 5 mg/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0272382",
    "display" : "Venlafaxina 75 mg comprimido"
  },
  {
    "code" : "BR0376695",
    "display" : "Piridoxina 50 mg comprimido"
  },
  {
    "code" : "BR0272381",
    "display" : "Venlafaxina 37,5 mg comprimido"
  },
  {
    "code" : "BR0376502-1",
    "display" : "Ranelato de Estrôncio 2 g granulado"
  },
  {
    "code" : "BR0272380",
    "display" : "Venlafaxina 150 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0376502",
    "display" : "Ranelato de Estrôncio 2 g granulado"
  },
  {
    "code" : "BR0272379",
    "display" : "Venlafaxina 75 mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0376357",
    "display" : "Valsartana 40 mg comprimido"
  },
  {
    "code" : "BR0272369",
    "display" : "Valaciclovir 500 mg comprimido"
  },
  {
    "code" : "BR0376107",
    "display" : "Nicotina 21 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0272367",
    "display" : "Tioridazina 100 mg comprimido"
  },
  {
    "code" : "BR0376106",
    "display" : "Nicotina 14 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0272366",
    "display" : "Tioridazina 50 mg comprimido"
  },
  {
    "code" : "BR0376105",
    "display" : "Nicotina 7 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0272365",
    "display" : "Sertralina 50 mg comprimido"
  },
  {
    "code" : "BR0375474-3",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução nasal"
  },
  {
    "code" : "BR0272364-1",
    "display" : "Sertralina 75 mg comprimido"
  },
  {
    "code" : "BR0375474-2",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução nasal"
  },
  {
    "code" : "BR0272364",
    "display" : "Sertralina 25 mg comprimido"
  },
  {
    "code" : "BR0375474-1",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução nasal"
  },
  {
    "code" : "BR0272363",
    "display" : "Sertralina 100 mg comprimido"
  },
  {
    "code" : "BR0272362",
    "display" : "Protamina 50 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0375387-3",
    "display" : "Polietilenoglicol (400) 3 mg/mL + Propilenoglicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272343",
    "display" : "Tiamina 100 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0375387-2",
    "display" : "Polietilenoglicol (400) 3 mg/mL + Propilenoglicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0375387-1",
    "display" : "Polietilenoglicol (400) 3 mg/mL + Propilenoglicol 4 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272341",
    "display" : "Tiamina 300 mg comprimido"
  },
  {
    "code" : "BR0374967",
    "display" : "Nilotinibe 200 mg cápsula"
  },
  {
    "code" : "BR0272340",
    "display" : "Tiamina 100 mg cápsula"
  },
  {
    "code" : "BR0272338",
    "display" : "Piridoxina 300 mg comprimido"
  },
  {
    "code" : "BR0374816",
    "display" : "Cipionato de Testosterona 200 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272337",
    "display" : "Piridoxina 100 mg comprimido"
  },
  {
    "code" : "BR0374313",
    "display" : "Ácido Paraminossalicílico 4 g granulado"
  },
  {
    "code" : "BR0272336",
    "display" : "Dimenidrinato 30 mg/10 mL + Piridoxina 50 mg/10 mL + Glicose 1 g/10 mL + Frutose 1 g/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0374155",
    "display" : "Rifampicina 150 mg + Isoniazida 75 mg comprimido"
  },
  {
    "code" : "BR0272335",
    "display" : "Dimenidrinato 25 mg/mL + Piridoxina 5 mg/mL solução oral"
  },
  {
    "code" : "BR0373949",
    "display" : "Pindolol 10 mg comprimido"
  },
  {
    "code" : "BR0272334-2",
    "display" : "Dimenidrinato 500 mg/10 mL + Piridoxina 500 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0373910-3",
    "display" : "Hipromelose 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0272334-1",
    "display" : "Dimenidrinato 50 mg/1 mL + Piridoxina 50 mg/1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0373910-2",
    "display" : "Hipromelose 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0272333",
    "display" : "Dimenidrinato 50 mg + Piridoxina 10 mg comprimido"
  },
  {
    "code" : "BR0373910-1",
    "display" : "Hipromelose 2 mg/mL (0,2%) solução oftálmica"
  },
  {
    "code" : "BR0272331",
    "display" : "Dimenidrinato 100 mg comprimido"
  },
  {
    "code" : "BR0373909-4",
    "display" : "Hipromelose 0,2 mg/mL (0,02%) solução oftálmica"
  },
  {
    "code" : "BR0272330",
    "display" : "Piperidolato 100 mg + Hesperidina 50 mg + Ácido Ascórbico 50 mg comprimido"
  },
  {
    "code" : "BR0373909-3",
    "display" : "Hipromelose 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272329",
    "display" : "Petidina 100 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0373909-2",
    "display" : "Hipromelose 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272328",
    "display" : "Oxibutinina 1 mg/mL xarope"
  },
  {
    "code" : "BR0373909-1",
    "display" : "Hipromelose 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272327",
    "display" : "Oxibutinina 5 mg comprimido"
  },
  {
    "code" : "BR0373792",
    "display" : "Ibuprofeno 400 mg + Arginina 370 mg granulado"
  },
  {
    "code" : "BR0272326",
    "display" : "Naloxona 0,4 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0373415",
    "display" : "Daptomicina 500 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272320",
    "display" : "Metilfenidato 10 mg comprimido"
  },
  {
    "code" : "BR0373165",
    "display" : "Capreomicina 1 g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272234",
    "display" : "Levobunolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0372372",
    "display" : "Gentamicina 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0272229",
    "display" : "Lercanidipino 10 mg comprimido"
  },
  {
    "code" : "BR0372335",
    "display" : "Metronidazol 100 mg/g gel vaginal"
  },
  {
    "code" : "BR0272220",
    "display" : "Femproporex 25 mg comprimido"
  },
  {
    "code" : "BR0372204",
    "display" : "Dutasterida 0,5 mg comprimido"
  },
  {
    "code" : "BR0272217",
    "display" : "Difenidramina 50 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0371273-2",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução"
  },
  {
    "code" : "BR0272201",
    "display" : "Etilefrina 7,5 mg/mL solução oral"
  },
  {
    "code" : "BR0371273-1",
    "display" : "Cloreto de Sódio 9 mg/mL (0,9%) solução"
  },
  {
    "code" : "BR0272198",
    "display" : "Etilefrina 10 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0370560",
    "display" : "Alfa1antitripsina 1 g /50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272194",
    "display" : "Esmolol 100 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0370525",
    "display" : "Valsartana 160 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0272178",
    "display" : "Clobutinol 4 mg/mL xarope"
  },
  {
    "code" : "BR0370120-2",
    "display" : "Artesunato 100 mg + Mefloquina 220 mg comprimido"
  },
  {
    "code" : "BR0272174",
    "display" : "Benzidamina 30 mg/mL solução oral"
  },
  {
    "code" : "BR0370120-1",
    "display" : "Artesunato 100 mg + Mefloquina 220 mg comprimido"
  },
  {
    "code" : "BR0272166",
    "display" : "Ciclobenzaprina 5 mg comprimido"
  },
  {
    "code" : "BR0370120",
    "display" : "Artesunato 100 mg + Mefloquina 220 mg comprimido"
  },
  {
    "code" : "BR0272134",
    "display" : "Ciclopentolato 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0370119-2",
    "display" : "Artesunato 25 mg + Mefloquina 55 mg comprimido"
  },
  {
    "code" : "BR0272131",
    "display" : "Sulfato de Quinina 500 mg comprimido"
  },
  {
    "code" : "BR0370119-1",
    "display" : "Artesunato 25 mg + Mefloquina 55 mg comprimido"
  },
  {
    "code" : "BR0272094",
    "display" : "Lamivudina 150 mg + Zidovudina 300 mg comprimido"
  },
  {
    "code" : "BR0370119",
    "display" : "Artesunato 25 mg + Mefloquina 55 mg comprimido"
  },
  {
    "code" : "BR0272089-8",
    "display" : "Sulfadiazina de Prata 10 mg/g creme vaginal"
  },
  {
    "code" : "BR0370117",
    "display" : "Etexilato de Dabigatrana 110 mg cápsula"
  },
  {
    "code" : "BR0272089-7",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0369179E",
    "display" : "Everolimo 1 mg comprimido"
  },
  {
    "code" : "BR0272089-6",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0369179",
    "display" : "Everolimo 1 mg comprimido"
  },
  {
    "code" : "BR0272089-5",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0369178E",
    "display" : "Everolimo 0,75 mg comprimido"
  },
  {
    "code" : "BR0272089-4",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0369178",
    "display" : "Everolimo 0,75 mg comprimido"
  },
  {
    "code" : "BR0272089-3",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0369176E",
    "display" : "Everolimo 0,5 mg comprimido"
  },
  {
    "code" : "BR0272089-2",
    "display" : "Sulfadiazina de Prata 1% pasta"
  },
  {
    "code" : "BR0369176",
    "display" : "Everolimo 0,5 mg comprimido"
  },
  {
    "code" : "BR0272089-1",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0369175E",
    "display" : "Mesalazina 10 mg/mL suspensão retal"
  },
  {
    "code" : "BR0272089",
    "display" : "Sulfadiazina de Prata 10 mg/g creme"
  },
  {
    "code" : "BR0369106",
    "display" : "Vimpocetina 5 mg comprimido"
  },
  {
    "code" : "BR0272088-4",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0368922-2",
    "display" : "Ácido Acético 2%"
  },
  {
    "code" : "BR0272088-3",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0368922-1",
    "display" : "Ácido Acético 2%"
  },
  {
    "code" : "BR0272088-2",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0272088-1",
    "display" : "Sulfadiazina de Prata 10 mg/g (1%) + Nitrato de Cério 4 mg/g (0,4%) creme"
  },
  {
    "code" : "BR0368922",
    "display" : "Ácido Acético 2%"
  },
  {
    "code" : "BR0272083E",
    "display" : "Cloridrato de Sevelâmer 800 mg comprimido"
  },
  {
    "code" : "BR0368921-3",
    "display" : "Ácido Acético 3%"
  },
  {
    "code" : "BR0272083",
    "display" : "Cloridrato de Sevelâmer 800 mg comprimido"
  },
  {
    "code" : "BR0368921",
    "display" : "Ácido Acético 3%"
  },
  {
    "code" : "BR0272082",
    "display" : "Cloridrato de Sevelâmer 400 mg comprimido"
  },
  {
    "code" : "BR0368919-4",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0272050",
    "display" : "Clordiazepóxido 10 mg comprimido"
  },
  {
    "code" : "BR0368919-3",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0272049",
    "display" : "Clordiazepóxido 25 mg comprimido"
  },
  {
    "code" : "BR0368919-2",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0272045E",
    "display" : "Clopidogrel 75 mg comprimido"
  },
  {
    "code" : "BR0368919-1",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0272045",
    "display" : "Clopidogrel 75 mg comprimido"
  },
  {
    "code" : "BR0368919",
    "display" : "Ácido Acético 5%"
  },
  {
    "code" : "BR0272044",
    "display" : "Clonidina 0,15 mg comprimido"
  },
  {
    "code" : "BR0368903",
    "display" : "Bisacodil 5 mg + Docusato de Sódio 60 mg comprimido"
  },
  {
    "code" : "BR0272043",
    "display" : "Clonidina 0,1 mg comprimido"
  },
  {
    "code" : "BR0368899",
    "display" : "Clindamicina 10 mg/mL (1%) + Peróxido de Benzoíla 50 mg/mL (5%) gel"
  },
  {
    "code" : "BR0272042",
    "display" : "Clonidina 0,2 mg comprimido"
  },
  {
    "code" : "BR0368799",
    "display" : "Ubidecarenona 50 mg comprimido"
  },
  {
    "code" : "BR0272041",
    "display" : "Clomipramina 75 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0368694",
    "display" : "Eculizumabe 300 mg/30 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272028",
    "display" : "Bamifilina 300 mg comprimido"
  },
  {
    "code" : "BR0368654",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0272027",
    "display" : "Bamifilina 600 mg comprimido"
  },
  {
    "code" : "BR0368640",
    "display" : "Nitazoxanida 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0272023",
    "display" : "Tamoxifeno 20 mg comprimido"
  },
  {
    "code" : "BR0368612",
    "display" : "Nitazoxanida 500 mg comprimido"
  },
  {
    "code" : "BR0272022",
    "display" : "Tamoxifeno 10 mg comprimido"
  },
  {
    "code" : "BR0368168",
    "display" : "Fosfato Dissódico de Dexametasona 2 mg/1 mL + Acetato de Dexametasona 8 mg/1 mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0272005",
    "display" : "Citicolina 500 mg comprimido"
  },
  {
    "code" : "BR0367897",
    "display" : "Imunoglobulina humana 500 mg/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271992",
    "display" : "Celecoxibe 100 mg cápsula"
  },
  {
    "code" : "BR0367765",
    "display" : "Gelatina 3,5% solução para injeção 500 mL; bisnaga"
  },
  {
    "code" : "BR0271990",
    "display" : "Cefuroxima 125 mg comprimido"
  },
  {
    "code" : "BR0271989",
    "display" : "Cefuroxima 500 mg comprimido"
  },
  {
    "code" : "BR0367725",
    "display" : "Policresuleno 50 mg/g + Cinchocaína 10 mg/g pomada"
  },
  {
    "code" : "BR0367724",
    "display" : "Levodopa 150 + Carbidopa 37,5 mg + Entacapona 200 mg comprimido"
  },
  {
    "code" : "BR0271988",
    "display" : "Cefuroxima 250 mg comprimido"
  },
  {
    "code" : "BR0271987",
    "display" : "Cefuroxima 750 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0367699",
    "display" : "Hidroxiapatita 800 mg comprimido"
  },
  {
    "code" : "BR0271986",
    "display" : "Cefuroxima 25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0367693E",
    "display" : "Ácido Nicotínico 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271982",
    "display" : "Cefadroxila 500 mg cápsula"
  },
  {
    "code" : "BR0367693",
    "display" : "Ácido Nicotínico 750 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271980",
    "display" : "Cefadroxila 50 mg/mL solução oral"
  },
  {
    "code" : "BR0367692E",
    "display" : "Ácido Nicotínico 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271953-1",
    "display" : "Droperidol 2,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0367692",
    "display" : "Ácido Nicotínico 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271950-3",
    "display" : "Fentanila 0,5 mg/10 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0367664",
    "display" : "Natalizumabe 300 mg/15 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271950-2",
    "display" : "Fentanila 0,25 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0367514",
    "display" : "Hidróxido de Alumínio 230 mg comprimido"
  },
  {
    "code" : "BR0271950-1",
    "display" : "Fentanila 0,1 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0367512",
    "display" : "Pirimetamina 5 mg/mL solução oral"
  },
  {
    "code" : "BR0271949",
    "display" : "Fentanila 50 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0366914",
    "display" : "Nafazolina 0,12 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271948",
    "display" : "Fentanila 100 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0366913",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0271946",
    "display" : "Fentanila 25 microgramas/hora adesivo transdérmico"
  },
  {
    "code" : "BR0366884",
    "display" : "Alisquireno 300 mg comprimido"
  },
  {
    "code" : "BR0271913",
    "display" : "Retinol 50.000 unidades internacionais comprimido"
  },
  {
    "code" : "BR0366883",
    "display" : "Alisquireno 150 mg comprimido"
  },
  {
    "code" : "BR0271876",
    "display" : "Ringer solução para injeção 500 mL; frasco-ampola"
  },
  {
    "code" : "BR0366861-3",
    "display" : "Peróxido de Benzoíla 50 mg/g gel"
  },
  {
    "code" : "BR0271866E",
    "display" : "Brinzolamida 10 mg/mL suspensão oftálmica"
  },
  {
    "code" : "BR0366861 -2",
    "display" : "Peróxido de Benzoíla 50 mg/g gel"
  },
  {
    "code" : "BR0271866-2",
    "display" : "Brinzolamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0366861",
    "display" : "Peróxido de Benzoíla 50 mg/g gel"
  },
  {
    "code" : "BR0271866-1",
    "display" : "Brinzolamida 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0365454",
    "display" : "Sorbitol 714 mg/g + Laurilsulfato de Sódio 7,7 mg/g supositório"
  },
  {
    "code" : "BR0271848E",
    "display" : "Bimatoprosta 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0365451E",
    "display" : "Abatacepte 250 mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271848-2",
    "display" : "Bimatoprosta 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0365451",
    "display" : "Abatacepte 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271848-1",
    "display" : "Bimatoprosta 0,3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0365441",
    "display" : "Oxibutinina 10 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271790-3",
    "display" : "Fenilefrina 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "BR0365048",
    "display" : "Lenalidomida 10 mg comprimido"
  },
  {
    "code" : "BR0271790-2",
    "display" : "Fenilefrina 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "BR0365047",
    "display" : "Lenalidomida 5 mg cápsula"
  },
  {
    "code" : "BR0271790-1",
    "display" : "Fenilefrina 100 mg/mL (10%) solução oftálmica"
  },
  {
    "code" : "BR0364917",
    "display" : "Anlodipino 5 mg + Benazepril 20 mg cápsula"
  },
  {
    "code" : "BR0271774",
    "display" : "Bromazepam 6 mg comprimido"
  },
  {
    "code" : "BR0364816",
    "display" : "Lenalidomida 25 mg comprimido"
  },
  {
    "code" : "BR0271773",
    "display" : "Bromazepam 3 mg comprimido"
  },
  {
    "code" : "BR0364789",
    "display" : "Isotretinoína 0,5 mg/g gel"
  },
  {
    "code" : "BR0271764E",
    "display" : "Brometo de Piridostigmina 60 mg comprimido"
  },
  {
    "code" : "BR0364781",
    "display" : "Aripiprazol 20 mg comprimido"
  },
  {
    "code" : "BR0271764",
    "display" : "Brometo de Piridostigmina 60 mg comprimido"
  },
  {
    "code" : "BR0364780",
    "display" : "Aripiprazol 10 mg comprimido"
  },
  {
    "code" : "BR0271761",
    "display" : "Bicalutamida 50 mg comprimido"
  },
  {
    "code" : "BR0364324",
    "display" : "Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0271758",
    "display" : "Betanecol 10 mg cápsula"
  },
  {
    "code" : "BR0364037",
    "display" : "Rifampicina 150 mg + Isoniazida 75 mg + Pirazinamida 400 mg + Etambutol 275 mg comprimido"
  },
  {
    "code" : "BR0271748",
    "display" : "Benciclano 200 mg comprimido"
  },
  {
    "code" : "BR0363934",
    "display" : "Maraviroque 300 mg comprimido"
  },
  {
    "code" : "BR0271747",
    "display" : "Benciclano 100 mg comprimido"
  },
  {
    "code" : "BR0363933",
    "display" : "Maraviroque 150 mg comprimido"
  },
  {
    "code" : "BR0271746",
    "display" : "Baclofeno 10 mg comprimido"
  },
  {
    "code" : "BR0363843",
    "display" : "Atazanavir 300 mg cápsula"
  },
  {
    "code" : "BR0271727E",
    "display" : "Pravastatina 40 mg comprimido"
  },
  {
    "code" : "BR0363778",
    "display" : "Flunitrazepam 2 mg comprimido"
  },
  {
    "code" : "BR0271727",
    "display" : "Pravastatina 40 mg comprimido"
  },
  {
    "code" : "BR0363597-2",
    "display" : "Permetrina 50 mg/mL loção"
  },
  {
    "code" : "BR0271725",
    "display" : "Piperacilina 4 g + Tazobactam 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0363597-1",
    "display" : "Permetrina 50 mg/mL loção"
  },
  {
    "code" : "BR0271724",
    "display" : "Piperacilina 2 g + Tazobactam 250 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0363561",
    "display" : "Hidroxocobalamina 5 mg/1 mL solução para injeção; ampola e Dipirona 500 mg/1 mL + Dexametasona 1,5 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271710",
    "display" : "Amiodarona 150 mg/3 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0363560",
    "display" : "Diclofenaco Sódico 50 mg + Tiamina 50 mg + Piridoxina 50 mg + Cianocobalamina 1 mg comprimido"
  },
  {
    "code" : "BR0271709",
    "display" : "Amiodarona 100 mg comprimido"
  },
  {
    "code" : "BR0363379",
    "display" : "Cloridrato de Quinina 100 mg + Papaverina 40 mg comprimido"
  },
  {
    "code" : "BR0271691",
    "display" : "Ácido Ascórbico 500 mg comprimido"
  },
  {
    "code" : "BR0362802",
    "display" : "Vildagliptina 50 mg comprimido"
  },
  {
    "code" : "BR0271689-2",
    "display" : "Ácido Ascórbico 200 mg/mL solução oral"
  },
  {
    "code" : "BR0362721",
    "display" : "Bisoprolol 10 mg comprimido"
  },
  {
    "code" : "BR0271689-1",
    "display" : "Ácido Ascórbico 200 mg/mL solução oral"
  },
  {
    "code" : "BR0362720",
    "display" : "Bisoprolol 2,5 mg comprimido"
  },
  {
    "code" : "BR0271687",
    "display" : "Ácido Ascórbico 500 mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0362719",
    "display" : "Bisoprolol 1,25 mg comprimido"
  },
  {
    "code" : "BR0271686",
    "display" : "Ácido Ascórbico 2 g comprimido efervescente"
  },
  {
    "code" : "BR0362718",
    "display" : "Bisoprolol 5 mg comprimido"
  },
  {
    "code" : "BR0271685",
    "display" : "Ácido Ascórbico 1 g comprimido efervescente"
  },
  {
    "code" : "BR0362661-2",
    "display" : "Clindamicina 20 mg/g (2%) creme"
  },
  {
    "code" : "BR0271670",
    "display" : "Ácido Mefenâmico 500 mg comprimido"
  },
  {
    "code" : "BR0362661-1",
    "display" : "Clindamicina 20 mg/g (2%) creme"
  },
  {
    "code" : "BR0271666",
    "display" : "Aceclofenaco 100 mg comprimido"
  },
  {
    "code" : "BR0362266",
    "display" : "Aprepitanto 80 mg cápsula e Aprepitanto 125 mg cápsula"
  },
  {
    "code" : "BR0271661-2",
    "display" : "Ambroxol 7,5 mg/mL solução"
  },
  {
    "code" : "BR0362260",
    "display" : "Trazodona 150 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271661-1",
    "display" : "Ambroxol 7,5 mg/mL solução"
  },
  {
    "code" : "BR0362259",
    "display" : "Trazodona 100 mg comprimido"
  },
  {
    "code" : "BR0271660-2",
    "display" : "Ambroxol 3 mg/mL xarope"
  },
  {
    "code" : "BR0362059",
    "display" : "Rivastigmina 13,3 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0271660-1",
    "display" : "Ambroxol 3 mg/mL xarope"
  },
  {
    "code" : "BR0362058",
    "display" : "Rivastigmina 9,5 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0271659-2",
    "display" : "Ambroxol 6 mg/mL xarope"
  },
  {
    "code" : "BR0362057",
    "display" : "Rivastigmina 4,6 mg/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0271659-1",
    "display" : "Ambroxol 6 mg/mL xarope"
  },
  {
    "code" : "BR0361791",
    "display" : "Diclofenaco Dietilamônio 11,6 mg/g gel"
  },
  {
    "code" : "BR0271657",
    "display" : "Caspofungina 50 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0361382E",
    "display" : "Deferiprona 500 mg comprimido"
  },
  {
    "code" : "BR0271656",
    "display" : "Caspofungina 70 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0361382",
    "display" : "Deferiprona 500 mg comprimido"
  },
  {
    "code" : "BR0271654",
    "display" : "Megestrol 160 mg comprimido"
  },
  {
    "code" : "BR0361174",
    "display" : "Lapatinibe 250 mg comprimido"
  },
  {
    "code" : "BR0271653-2",
    "display" : "Hidroxocobalamina 2 mg/2 mL solução par a injeção; ampola"
  },
  {
    "code" : "BR0360826",
    "display" : "Paliperidona 9 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271653-1",
    "display" : "Hidroxocobalamina 1 mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271652",
    "display" : "Hidroxocobalamina 15 mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0360824",
    "display" : "Paliperidona 3 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271647",
    "display" : "Oximetazolina 0,25 mg/mL solução nasal"
  },
  {
    "code" : "BR0359766",
    "display" : "Hialuronato de Sódio 40 mg/50 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271645",
    "display" : "Oximetazolina 0,5 mg/mL solução nasal"
  },
  {
    "code" : "BR0359286",
    "display" : "Hedera helix 7 mg/mL xarope"
  },
  {
    "code" : "BR0271644",
    "display" : "Oximetolona 50 mg comprimido"
  },
  {
    "code" : "BR0359136",
    "display" : "Dasatinibe 50 mg comprimido"
  },
  {
    "code" : "BR0271621E",
    "display" : "Olanzapina 10 mg comprimido"
  },
  {
    "code" : "BR0359135",
    "display" : "Dasatinibe 20 mg comprimido"
  },
  {
    "code" : "BR0271621",
    "display" : "Olanzapina 10 mg comprimido"
  },
  {
    "code" : "BR0358755",
    "display" : "Misoprostol 200 microgramas comprimido vaginal"
  },
  {
    "code" : "BR0271620E",
    "display" : "Olanzapina 5 mg comprimido"
  },
  {
    "code" : "BR0358754",
    "display" : "Misoprostol 100 microgramas comprimido"
  },
  {
    "code" : "BR0271620",
    "display" : "Olanzapina 5 mg comprimido"
  },
  {
    "code" : "BR0358753",
    "display" : "Misoprostol 25 microgramas comprimido"
  },
  {
    "code" : "BR0271610-1",
    "display" : "Nortriptilina 50 mg comprimido"
  },
  {
    "code" : "BR0358450",
    "display" : "Darifenacina 15 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271610",
    "display" : "Nortriptilina 50 mg cápsula"
  },
  {
    "code" : "BR0358449",
    "display" : "Darifenacina 7,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271609-2",
    "display" : "Nortriptilina 10 mg comprimido"
  },
  {
    "code" : "BR0358123",
    "display" : "Ranibizumabe 2,3 mg/2,3 mL suspensão para injeção; seringa preenchida"
  },
  {
    "code" : "BR0271609-1",
    "display" : "Nortriptilina 10 mg cápsula"
  },
  {
    "code" : "BR0357788",
    "display" : "Mepivacaína 54 mg/1,8 mL solução para injeção; carpule"
  },
  {
    "code" : "BR0271608",
    "display" : "Nortriptilina 2 mg/mL solução oral"
  },
  {
    "code" : "BR0357657",
    "display" : "Etravirina 100 mg comprimido"
  },
  {
    "code" : "BR0271607",
    "display" : "Nortriptilina 75 mg cápsula"
  },
  {
    "code" : "BR0357239",
    "display" : "Álcool Etílico 99% Solução"
  },
  {
    "code" : "BR0271606",
    "display" : "Nortriptilina 25 mg cápsula"
  },
  {
    "code" : "BR0357213",
    "display" : "Metoclopramida 7 mg + Simeticona 40 mg + Pepsina 50 mg cápsula"
  },
  {
    "code" : "BR0271604",
    "display" : "Aceponato de Metilprednisolona 1 mg/g creme"
  },
  {
    "code" : "BR0357119",
    "display" : "Beta-agalsidase 35 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271600",
    "display" : "Succinato Sódico de Metilprednisolona 125 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0357118",
    "display" : "Beta-agalsidase 5 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271599",
    "display" : "Succinato Sódico de Metilprednisolona 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0357071",
    "display" : "Citrato de Cálcio 2.370 mg (Cálcio 500 mg) + Colecalciferol 200 unidades internacionais pó para suspensão oral"
  },
  {
    "code" : "BR0271582",
    "display" : "Tobramicina 3 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0357066",
    "display" : "Vildagliptina 50 mg + Metformina 850 mg comprimido"
  },
  {
    "code" : "BR0271581",
    "display" : "Tobramicina 3 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0357064",
    "display" : "Vildagliptina 50 mg + Metformina 500 mg comprimido"
  },
  {
    "code" : "BR0271578",
    "display" : "Tobramicina 75 mg/1,5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0357063",
    "display" : "Valsartana 320 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR02715701",
    "display" : "Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0271570",
    "display" : "Tobramicina 3 mg/g + Dexametasona 1 mg/g pomada oftálmica"
  },
  {
    "code" : "BR0357062",
    "display" : "Valsartana 160 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0271556",
    "display" : "Midazolam 2 mg/mL solução oral"
  },
  {
    "code" : "BR0357061",
    "display" : "Valsartana 80 mg + Anlodipino 5 mg comprimido"
  },
  {
    "code" : "BR0271445",
    "display" : "Medroxiprogesterona 10 mg comprimido"
  },
  {
    "code" : "BR0357058",
    "display" : "Paroxetina 15 mg comprimido"
  },
  {
    "code" : "BR0271444",
    "display" : "Medroxiprogesterona 2,5 mg comprimido"
  },
  {
    "code" : "BR0356952",
    "display" : "Acetilcisteína 600 mg comprimido efervescente"
  },
  {
    "code" : "BR0271435",
    "display" : "Estrogênios Conjugados 0,625 mg/g creme vaginal"
  },
  {
    "code" : "BR0356705",
    "display" : "Mercaptamina 50 mg comprimido"
  },
  {
    "code" : "BR0271434",
    "display" : "Estrogênios Conjugados 0,625 mg comprimido"
  },
  {
    "code" : "BR0356701",
    "display" : "Desogestrel 75 microgramas comprimido"
  },
  {
    "code" : "BR0271394E",
    "display" : "Sulfato de Morfina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0356602",
    "display" : "Estrogênios Conjugados 0,3 mg comprimido"
  },
  {
    "code" : "BR0271394",
    "display" : "Sulfato de Morfina 10 mg/mL solução oral"
  },
  {
    "code" : "BR0356453",
    "display" : "Tianeptina 12,5 mg comprimido"
  },
  {
    "code" : "BR0356452-1",
    "display" : "Travoprosta 0,04 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271392E",
    "display" : "Morfina 10 mg comprimido"
  },
  {
    "code" : "BR0356452",
    "display" : "Travoprosta 0,04 mg/mL + Timolol 5 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271392",
    "display" : "Morfina 10 mg comprimido"
  },
  {
    "code" : "BR0271391E",
    "display" : "Morfina 30 mg comprimido"
  },
  {
    "code" : "BR0356051",
    "display" : "Ácido Zoledrônico 5 mg/100 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271391",
    "display" : "Morfina 30 mg comprimido"
  },
  {
    "code" : "BR0355794",
    "display" : "Moxifloxacino 5 mg/mL + Dexametasona 1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271373E",
    "display" : "Formoterol 12 microgramas cápsula para inalação"
  },
  {
    "code" : "BR0355786-1",
    "display" : "Acetilcisteína 40 mg/mL xarope"
  },
  {
    "code" : "BR0271360",
    "display" : "Carbonato de Cálcio + Lactogliconato de Cálcio 1.000 mg comprimido"
  },
  {
    "code" : "BR0355786",
    "display" : "Acetilcisteína 40 mg/mL xarope"
  },
  {
    "code" : "BR0271359",
    "display" : "Carbonato de Cálcio + Lactogliconato de Cálcio 500 mg comprimido"
  },
  {
    "code" : "BR0354953",
    "display" : "Somatostatina 3 mg pó para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271358",
    "display" : "Alprazolam 0,25 mg comprimido"
  },
  {
    "code" : "BR0354633",
    "display" : "Olopatadina 2 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271357-1",
    "display" : "Alprazolam 0,5 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0354632",
    "display" : "Olopatadina 1 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0271357",
    "display" : "Alprazolam 0,5 mg comprimido"
  },
  {
    "code" : "BR0354627E",
    "display" : "Hidróxido de Alumínio 230 mg comprimido"
  },
  {
    "code" : "BR0271356-1",
    "display" : "Alprazolam 1 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0354516",
    "display" : "Glipizida 5 mg comprimido"
  },
  {
    "code" : "BR0271356",
    "display" : "Alprazolam 1 mg comprimido"
  },
  {
    "code" : "BR0354498",
    "display" : "Lercanidipino 20 mg comprimido"
  },
  {
    "code" : "BR0271355",
    "display" : "Metronidazol 100 mg/g + Nistatina 20.000 unidades internacionais/g creme vaginal"
  },
  {
    "code" : "BR0354317",
    "display" : "Acarbose 100 mg comprimido"
  },
  {
    "code" : "BR0271354",
    "display" : "Cloridrato de Pilocarpina 40 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0354314",
    "display" : "Cimetidina 400 mg comprimido"
  },
  {
    "code" : "BR0271353E",
    "display" : "Cloridrato de Pilocarpina 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0354242",
    "display" : "Metoxisaleno 10 mg cápsula"
  },
  {
    "code" : "BR0271353-1",
    "display" : "Cloridrato de Pilocarpina 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0353813",
    "display" : "Mirtazapina 15 mg comprimido para suspensão"
  },
  {
    "code" : "BR0271353",
    "display" : "Cloridrato de Pilocarpina 20 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0353398-2",
    "display" : "Alfaporactanto 240 mg/3 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0271352",
    "display" : "Cloridrato de Pilocarpina 10 mg/mL solução oftálmica"
  },
  {
    "code" : "BR0353398-1",
    "display" : "Alfaporactanto 120 mg/1,5 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0271218",
    "display" : "Amoxicilina 25 mg/mL + Ácido Clavulânico 6,25 mg/mL suspensão oral"
  },
  {
    "code" : "BR0353397-2",
    "display" : "Beractanto 200 mg/8 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0271217",
    "display" : "Amoxicilina 500 mg + Ácido Clavulânico 125 mg comprimido"
  },
  {
    "code" : "BR0353397-1",
    "display" : "Beractanto 100 mg/4 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0271197",
    "display" : "Pindolol 10 mg + Clopamida 5 mg comprimido"
  },
  {
    "code" : "BR0353334",
    "display" : "Pegvisomanto 10 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271172",
    "display" : "Enalapril 10 mg + Hidroclorotiazida 25 mg comprimido"
  },
  {
    "code" : "BR0353333",
    "display" : "Amoxicilina 875 mg + Ácido Clavulânico 125 mg comprimido"
  },
  {
    "code" : "BR0271171",
    "display" : "Enalapril 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0353332",
    "display" : "Raltegravir 400 mg comprimido"
  },
  {
    "code" : "BR0271170",
    "display" : "Lisinopril 20 mg + Hidroclorotiazida 12,5 mg comprimido"
  },
  {
    "code" : "BR0352933-3",
    "display" : "Levetiracetam 100 mg/mL solução oral"
  },
  {
    "code" : "BR0271169",
    "display" : "Lisinopril 20 mg comprimido"
  },
  {
    "code" : "BR0352933-2",
    "display" : "Levetiracetam 100 mg/mL solução oral"
  },
  {
    "code" : "BR0271168",
    "display" : "Lisinopril 10 mg comprimido"
  },
  {
    "code" : "BR0352933-1",
    "display" : "Levetiracetam 100 mg/mL solução oral"
  },
  {
    "code" : "BR0271167",
    "display" : "Lisinopril 5 mg comprimido"
  },
  {
    "code" : "BR0352932",
    "display" : "Ácido Salicílico 270 mg/g gel"
  },
  {
    "code" : "BR0271166",
    "display" : "Furosemida 40 mg + Amilorida 10 mg comprimido"
  },
  {
    "code" : "BR0352912",
    "display" : "Divalproato de sódio 500 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271165",
    "display" : "Hidroclorotiazida 25 mg + Amilorida 2,5 mg comprimido"
  },
  {
    "code" : "BR0271162",
    "display" : "Hidroclorotiazida 50 mg + Amilorida 5 mg comprimido"
  },
  {
    "code" : "BR0352911",
    "display" : "Divalproato de sódio 125 mg cápsula"
  },
  {
    "code" : "BR0271157U0137",
    "display" : "Insulina Humana NPH 100 unidades internacionais/mL suspensão para injeção 3 mL; carpule"
  }]
}

```

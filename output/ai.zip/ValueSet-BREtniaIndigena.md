# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BR Etnia Indigena - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BR Etnia Indigena**

## ValueSet: BR Etnia Indigena 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/ValueSet/BREtniaIndigena | *Versão*:1.1.0 |
| Active as of 2026-03-09 | *Nome computável*:BREtniaIndigena |

 **References** 

Este conjunto de valores não é utilizado aqui; pode ser utilizado noutro local (por exemplo, especificações e/ou implementações que utilizem este conteúdo)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BREtniaIndigena",
  "url" : "https://terminologia.saude.gov.br/fhir/ValueSet/BREtniaIndigena",
  "version" : "1.1.0",
  "name" : "BREtniaIndigena",
  "title" : "BR Etnia Indigena",
  "status" : "active",
  "date" : "2026-03-09T15:10:29-03:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://mangara.hsl.org.br/fhir/CodeSystem/etnias",
      "concept" : [{
        "code" : "270",
        "display" : "PAYAYA"
      }]
    },
    {
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BREtniaIndigena",
      "concept" : [{
        "code" : "X405",
        "display" : "SEM INFORMACAO"
      },
      {
        "code" : "X404",
        "display" : "TATZ"
      },
      {
        "code" : "X403",
        "display" : "SAKIRIABAR"
      },
      {
        "code" : "X402",
        "display" : "ARARA"
      },
      {
        "code" : "X401",
        "display" : "YANOMAMI"
      },
      {
        "code" : "X400",
        "display" : "TIRIYÓ"
      },
      {
        "code" : "X399",
        "display" : "YEPAMASSÃ"
      },
      {
        "code" : "X398",
        "display" : "XIRUAI"
      },
      {
        "code" : "X397",
        "display" : "XIRIANA"
      },
      {
        "code" : "X396",
        "display" : "XIPAYA"
      },
      {
        "code" : "X395",
        "display" : "XICRIN"
      },
      {
        "code" : "X394",
        "display" : "XI EIN"
      },
      {
        "code" : "X393",
        "display" : "XEREU"
      },
      {
        "code" : "X392",
        "display" : "WASSUSU"
      },
      {
        "code" : "0200",
        "display" : "TAPEBA"
      },
      {
        "code" : "X391",
        "display" : "WAKALITESÚ"
      },
      {
        "code" : "X390",
        "display" : "WAIKISU"
      },
      {
        "code" : "0199",
        "display" : "TAPAYUNA (BEICO-DE-PAU)"
      },
      {
        "code" : "X389",
        "display" : "WAI WAI"
      },
      {
        "code" : "0198",
        "display" : "SUYA (SUIA/KISEDJE)"
      },
      {
        "code" : "X388",
        "display" : "URUPÁ"
      },
      {
        "code" : "0197",
        "display" : "SURUI DO PARA (AIKEWARA)"
      },
      {
        "code" : "X387",
        "display" : "URUBU KAAPOR"
      },
      {
        "code" : "0196",
        "display" : "SURUI DE RONDONIA (PAITER)"
      },
      {
        "code" : "X386",
        "display" : "URUBU"
      },
      {
        "code" : "0195",
        "display" : "SURIANA"
      },
      {
        "code" : "X385",
        "display" : "TUPINAMBÁ DE BELMONTE"
      },
      {
        "code" : "0194",
        "display" : "SIRIANO (SIRIA-MASA)"
      },
      {
        "code" : "X384",
        "display" : "TUPI"
      },
      {
        "code" : "0193",
        "display" : "SHANENAWA (KATUKINA)"
      },
      {
        "code" : "X383",
        "display" : "TUPAIU"
      },
      {
        "code" : "0192",
        "display" : "SATERE-MAWE (SATERE-MAUE)"
      },
      {
        "code" : "X382",
        "display" : "TUBARÃO"
      },
      {
        "code" : "0191",
        "display" : "SAKURABIAT (MEKENS, SAKIRABIAP, SAKIRABIAR)"
      },
      {
        "code" : "X381",
        "display" : "TSUNHUM-DJAPÁ"
      },
      {
        "code" : "0190",
        "display" : "RIKBAKTSA (CANOEIROS, ERIGPAKTSA)"
      },
      {
        "code" : "X380",
        "display" : "TORÁ DO BAIXO GRANDE"
      },
      {
        "code" : "0189",
        "display" : "POYANAWA (POIANAUA)"
      },
      {
        "code" : "X379",
        "display" : "TIMBIRA"
      },
      {
        "code" : "0188",
        "display" : "POTIGUARA"
      },
      {
        "code" : "X378",
        "display" : "TEFÉ"
      },
      {
        "code" : "0187",
        "display" : "PITAGUARI"
      },
      {
        "code" : "0186",
        "display" : "PIRATUAPUIA (PIRATAPUYA, PIRATAPUYO, PIRA­TAPUYA, WAIKANA)"
      },
      {
        "code" : "X377",
        "display" : "TAWANDÊ"
      },
      {
        "code" : "X376",
        "display" : "TATU"
      },
      {
        "code" : "0185",
        "display" : "PIRAHA (MURA PIRAHA)"
      },
      {
        "code" : "0184",
        "display" : "PAUMELENHO"
      },
      {
        "code" : "X375",
        "display" : "TAKUARA"
      },
      {
        "code" : "0183",
        "display" : "PAUMARI (PALMARI)"
      },
      {
        "code" : "X374",
        "display" : "TABAJARA"
      },
      {
        "code" : "0182",
        "display" : "PATAXO HA-HA-HAE"
      },
      {
        "code" : "X373",
        "display" : "SIUCI"
      },
      {
        "code" : "0181",
        "display" : "PATAXO"
      },
      {
        "code" : "X372",
        "display" : "SILCY-TAPUYA"
      },
      {
        "code" : "0180",
        "display" : "PATAMONA (KAPON)"
      },
      {
        "code" : "X371",
        "display" : "SAWENTESÚ"
      },
      {
        "code" : "0179",
        "display" : "PARINTINTIN"
      },
      {
        "code" : "X370",
        "display" : "SANUMA"
      },
      {
        "code" : "0178",
        "display" : "PARECI (PARESI, HALITI)"
      },
      {
        "code" : "X369",
        "display" : "SABANÊ"
      },
      {
        "code" : "0177",
        "display" : "PARAKANA (PARACANA, APITEREWA, AWAETE)"
      },
      {
        "code" : "X368",
        "display" : "PUROBORÁ"
      },
      {
        "code" : "0176",
        "display" : "PANKARU (PANCARU)"
      },
      {
        "code" : "X367",
        "display" : "PIRATA"
      },
      {
        "code" : "0175",
        "display" : "PANKARARU KARUAZU (KARUAZU)"
      },
      {
        "code" : "0174",
        "display" : "PANKARARU KALANKO (KALANKO)"
      },
      {
        "code" : "X366",
        "display" : "PIPIPAN"
      },
      {
        "code" : "0173",
        "display" : "PANKARARU (PANCARARU)"
      },
      {
        "code" : "X365",
        "display" : "PAYAYÁ"
      },
      {
        "code" : "0172",
        "display" : "PANKARARE (PANCARARE)"
      },
      {
        "code" : "X364",
        "display" : "PAPAGAIO"
      },
      {
        "code" : "X363",
        "display" : "PANKARÁ"
      },
      {
        "code" : "0171",
        "display" : "PANARA (KRENHAKARORE , KRENAKORE, KRENA­KARORE)"
      },
      {
        "code" : "X362",
        "display" : "PACA"
      },
      {
        "code" : "X361",
        "display" : "ORO WARAM XIJEIN"
      },
      {
        "code" : "0170",
        "display" : "PALIKUR (AUKWAYENE, AUKUYENE, PALIKU'ENE)"
      },
      {
        "code" : "X360",
        "display" : "ORO WARAM"
      },
      {
        "code" : "0169",
        "display" : "PAKAA NOVA (WARI, PACAAS NOVOS)"
      },
      {
        "code" : "X359",
        "display" : "ORO WAM"
      },
      {
        "code" : "0168",
        "display" : "PAIAKU (JENIPAPO-KANINDE)"
      },
      {
        "code" : "X358",
        "display" : "ORO NÁO"
      },
      {
        "code" : "0167",
        "display" : "ORO WIN"
      },
      {
        "code" : "0166",
        "display" : "OFAIE (OFAYE-XAVANTE)"
      },
      {
        "code" : "X357",
        "display" : "ORO MON"
      },
      {
        "code" : "X356",
        "display" : "ORO MIYLIN"
      },
      {
        "code" : "0165",
        "display" : "NUKINI (NUQUINI, NUKUINI)"
      },
      {
        "code" : "X355",
        "display" : "ORO JOWIN"
      },
      {
        "code" : "0164",
        "display" : "NAWA (NAUA)"
      },
      {
        "code" : "X354",
        "display" : "ORO EO"
      },
      {
        "code" : "0163",
        "display" : "NARAVUTE (NARUVOTO)"
      },
      {
        "code" : "0162",
        "display" : "NAMBIKWARA DO SUL (WASUSU ,HAHAINTESU, ALANTESU, WAIKISU, ALAKETESU, WASUSU, SA­RARE)"
      },
      {
        "code" : "X353",
        "display" : "ORO AT"
      },
      {
        "code" : "0161",
        "display" : "NAMBIKWARA DO NORTE (NEGAROTE ,MAMAIN­DE, LATUNDE, SABANE E MANDUKA, TAWANDE)"
      },
      {
        "code" : "X352",
        "display" : "ONÇA"
      },
      {
        "code" : "0160",
        "display" : "NAMBIKWARA DO CAMPO (HALOTESU, KITHAULU, WAKALITESU, SAWENTES, MANDUKA)"
      },
      {
        "code" : "X351",
        "display" : "OFAIE XAVANTE"
      },
      {
        "code" : "0159",
        "display" : "NAHUKWA (NAFUQUA)"
      },
      {
        "code" : "X350",
        "display" : "NHENGATU"
      },
      {
        "code" : "0158",
        "display" : "MURA"
      },
      {
        "code" : "0157",
        "display" : "MUNDURUKU (MUNDURUCU)"
      },
      {
        "code" : "X349",
        "display" : "NEGAROTÊ"
      },
      {
        "code" : "0156",
        "display" : "MIRITI TAPUIA (MIRITI-TAPUYA, BUIA-TAPUYA)"
      },
      {
        "code" : "X348",
        "display" : "NAMBIKWARA"
      },
      {
        "code" : "0155",
        "display" : "MIRANHA (MIRANHA, MIRANA)"
      },
      {
        "code" : "X347",
        "display" : "NADEB"
      },
      {
        "code" : "0154",
        "display" : "MENKY (MYKY, MUNKU, MENKI, MYNKY)"
      },
      {
        "code" : "X346",
        "display" : "MYKY"
      },
      {
        "code" : "0153",
        "display" : "MEKEN (MEQUEM, MEKHEM, MICHENS)"
      },
      {
        "code" : "X345",
        "display" : "MUTUM"
      },
      {
        "code" : "0152",
        "display" : "MEHINAKO (MEINAKU, MEINACU)"
      },
      {
        "code" : "0151",
        "display" : "MAYTAPU"
      },
      {
        "code" : "X344",
        "display" : "MON ORO WARAM"
      },
      {
        "code" : "0150",
        "display" : "MAYA (MAYA)"
      },
      {
        "code" : "X343",
        "display" : "MOKURIÑ"
      },
      {
        "code" : "0149",
        "display" : "MAXAKALI (MAXACALI)"
      },
      {
        "code" : "X342",
        "display" : "MIQUELENO"
      },
      {
        "code" : "0148",
        "display" : "MATSE (MAYORUNA)"
      },
      {
        "code" : "X341",
        "display" : "MAYORUNA"
      },
      {
        "code" : "0147",
        "display" : "MATIS"
      },
      {
        "code" : "X340",
        "display" : "MAWÉ"
      },
      {
        "code" : "0146",
        "display" : "MATIPU"
      },
      {
        "code" : "0145",
        "display" : "MARUBO"
      },
      {
        "code" : "X339",
        "display" : "MAWAYANA"
      },
      {
        "code" : "0144",
        "display" : "MARIMAM (MARIMA)"
      },
      {
        "code" : "X338",
        "display" : "MASSAKA"
      },
      {
        "code" : "0143",
        "display" : "MAKUXI (MACUXI, MACHUSI, PEMON)"
      },
      {
        "code" : "X337",
        "display" : "MARIBONDO"
      },
      {
        "code" : "0142",
        "display" : "MAKUNA (MACUNA, YEBA-MASA)"
      },
      {
        "code" : "X336",
        "display" : "MANDUCA"
      },
      {
        "code" : "0141",
        "display" : "MAKU YUHUPDE (YUHUPDE)"
      },
      {
        "code" : "X335",
        "display" : "MANCHINERI"
      },
      {
        "code" : "0140",
        "display" : "MAKU NADEB (NADEB)"
      },
      {
        "code" : "X334",
        "display" : "MANAIRISSU"
      },
      {
        "code" : "0139",
        "display" : "MAKU HUPDA (HUPDA)"
      },
      {
        "code" : "X333",
        "display" : "MANACAPURU"
      },
      {
        "code" : "0138",
        "display" : "MAKU DOW (DOW)"
      },
      {
        "code" : "X332",
        "display" : "MAMURI"
      },
      {
        "code" : "0137",
        "display" : "MACURAP (MAKURAP)"
      },
      {
        "code" : "X331",
        "display" : "MAMAINDÊ"
      },
      {
        "code" : "0136",
        "display" : "MACHINERI (MANCHINERI, MANXINERI)"
      },
      {
        "code" : "X330",
        "display" : "MAKUNAMBÉ"
      },
      {
        "code" : "0135",
        "display" : "KWAZA (COAIA, KOAIA)"
      },
      {
        "code" : "X329",
        "display" : "MAKU"
      },
      {
        "code" : "0134",
        "display" : "KURUAIA (CURUAIA)"
      },
      {
        "code" : "X328",
        "display" : "LATUNDÊ"
      },
      {
        "code" : "0133",
        "display" : "KURIPAKO (CURIPACO, CURRIPACO, CORIPACO, WAKUENAI)"
      },
      {
        "code" : "X327",
        "display" : "KULINA"
      },
      {
        "code" : "0132",
        "display" : "KULINA/MADIHA (CULINA, MADIJA, MADIHA)"
      },
      {
        "code" : "X326",
        "display" : "KRAHÔ KANELA"
      },
      {
        "code" : "0131",
        "display" : "KULINA PANO (CULINA)"
      },
      {
        "code" : "0130",
        "display" : "KUJUBIM (KUYUBI, CUJUBIM)"
      },
      {
        "code" : "X325",
        "display" : "KONTANAWA"
      },
      {
        "code" : "0129",
        "display" : "KUIKURO (KUIKURU, CUICURO)"
      },
      {
        "code" : "X324",
        "display" : "KOIUPANKÁ"
      },
      {
        "code" : "0128",
        "display" : "KUBEO (CUBEO, COBEWA, KUBEWA, PAMIWA, CU­BEU)"
      },
      {
        "code" : "X323",
        "display" : "KOIAIÁ"
      },
      {
        "code" : "0127",
        "display" : "KRIKATI (KRINKATI)"
      },
      {
        "code" : "X322",
        "display" : "KITHÃULU"
      },
      {
        "code" : "0126",
        "display" : "KRENAK (BORUN, CRENAQUE)"
      },
      {
        "code" : "X321",
        "display" : "KIRIRI-BARRA"
      },
      {
        "code" : "0125",
        "display" : "KREJE (KRENYE)"
      },
      {
        "code" : "X320",
        "display" : "KINÃ (WAIMIRI-ATROARI)"
      },
      {
        "code" : "0124",
        "display" : "KRAHO (CRAO, KRAO)"
      },
      {
        "code" : "X319",
        "display" : "KAYABI"
      },
      {
        "code" : "0123",
        "display" : "KORUBO"
      },
      {
        "code" : "X318",
        "display" : "KAXAGO"
      },
      {
        "code" : "0122",
        "display" : "KOKUIREGATEJE"
      },
      {
        "code" : "0121",
        "display" : "KOCAMA (COCAMA, KOKAMA)"
      },
      {
        "code" : "X317",
        "display" : "KATUKINA SHANENAUWA"
      },
      {
        "code" : "0120",
        "display" : "KIRIRI"
      },
      {
        "code" : "X316",
        "display" : "KATUKINA PEDA DJAPA"
      },
      {
        "code" : "0119",
        "display" : "KINIKINAWA (GUAN, KOINUKOEN, KINIKINAO)"
      },
      {
        "code" : "X315",
        "display" : "KATUKINA PANO"
      },
      {
        "code" : "0118",
        "display" : "KAYUISANA (CAIXANA, CAUIXANA, KAIXANA)"
      },
      {
        "code" : "X314",
        "display" : "KATOKIN"
      },
      {
        "code" : "0117",
        "display" : "KAYAPO XICRIM (XIKRIN)"
      },
      {
        "code" : "0116",
        "display" : "KAYAPO TXUKAHAMAE (TXUKAHAMAE)"
      },
      {
        "code" : "X313",
        "display" : "KATITHÃULU"
      },
      {
        "code" : "0115",
        "display" : "KAYAPO KARARAO (KARARAO)"
      },
      {
        "code" : "X312",
        "display" : "KASSUPÁ"
      },
      {
        "code" : "0114",
        "display" : "KAYAPO (CAIAPO)"
      },
      {
        "code" : "X311",
        "display" : "KARUBO"
      },
      {
        "code" : "0113",
        "display" : "KAXUYANA (CAXUIANA)"
      },
      {
        "code" : "X310",
        "display" : "KARARAO"
      },
      {
        "code" : "0112",
        "display" : "KAXIXO"
      },
      {
        "code" : "X309",
        "display" : "KARAFAWYANA"
      },
      {
        "code" : "0111",
        "display" : "KAXINAWA (HUNI-KUIN, CASHINAUA, CAXINAUA)"
      },
      {
        "code" : "X308",
        "display" : "KANELA"
      },
      {
        "code" : "0110",
        "display" : "KAXARARI (CAXARARI)"
      },
      {
        "code" : "X307",
        "display" : "KAMPA"
      },
      {
        "code" : "0109",
        "display" : "KATUKINA DO ACRE"
      },
      {
        "code" : "X306",
        "display" : "KAIOWA"
      },
      {
        "code" : "0108",
        "display" : "KATUKINA (PEDA DJAPA)"
      },
      {
        "code" : "X305",
        "display" : "JIAHOI"
      },
      {
        "code" : "0107",
        "display" : "KATUENA (CATUENA, KATWENA)"
      },
      {
        "code" : "X304",
        "display" : "JENIPAPO-KANINDE"
      },
      {
        "code" : "0106",
        "display" : "KATAWIXI (KATAUIXI, KATAWIN, KATAWISI, CATAUICHI)"
      },
      {
        "code" : "X303",
        "display" : "JENIPAPO"
      },
      {
        "code" : "0105",
        "display" : "KARITIANA (CARITIANA)"
      },
      {
        "code" : "X302",
        "display" : "JAVAE"
      },
      {
        "code" : "0104",
        "display" : "KARIRI-XOCO (CARIRI-CHOCO)"
      },
      {
        "code" : "0103",
        "display" : "KARIRI (CARIRI)"
      },
      {
        "code" : "X301",
        "display" : "INHABARANA"
      },
      {
        "code" : "0102",
        "display" : "KARIPUNA DO AMAPA (CARIPUNA)"
      },
      {
        "code" : "X300",
        "display" : "INAMBU"
      },
      {
        "code" : "0101",
        "display" : "KARIPUNA (CARIPUNA)"
      },
      {
        "code" : "X299",
        "display" : "IKPENG"
      },
      {
        "code" : "0100",
        "display" : "KARAPOTO (CARAPOTO)"
      },
      {
        "code" : "X298",
        "display" : "IAUARETE AÇU"
      },
      {
        "code" : "0099",
        "display" : "KARAPANA (CARAPANA, MUTEAMASA, UKOPINO­PONA)"
      },
      {
        "code" : "X297",
        "display" : "IAUANAUA"
      },
      {
        "code" : "0098",
        "display" : "KARAJA/XAMBIOA (KARAJA DO NORTE)"
      },
      {
        "code" : "X296",
        "display" : "HUPDES"
      },
      {
        "code" : "0097",
        "display" : "KARAJA/JAVAE (JAVAE)"
      },
      {
        "code" : "X295",
        "display" : "HUPDE"
      },
      {
        "code" : "0096",
        "display" : "KARAJA (CARAJA)"
      },
      {
        "code" : "X294",
        "display" : "HIXKARYANA"
      },
      {
        "code" : "0095",
        "display" : "KAPINAWA (CAPINAUA)"
      },
      {
        "code" : "X293",
        "display" : "HENGATÚ"
      },
      {
        "code" : "0094",
        "display" : "KANTARURE (CANTARURE)"
      },
      {
        "code" : "X292",
        "display" : "HALOTESU"
      },
      {
        "code" : "0093",
        "display" : "KANOE (CANOE)"
      },
      {
        "code" : "X291",
        "display" : "HALANTESU"
      },
      {
        "code" : "0092",
        "display" : "KANINDE"
      },
      {
        "code" : "X290",
        "display" : "GUARANI"
      },
      {
        "code" : "0091",
        "display" : "KANELA RANKOKAMEKRA (CANELA)"
      },
      {
        "code" : "X289",
        "display" : "GAVIÃO"
      },
      {
        "code" : "0090",
        "display" : "KANELA APANIEKRA (CANELA)"
      },
      {
        "code" : "0089",
        "display" : "KANAMARI (CANAMARI, KANAMARY, TUKUNA)"
      },
      {
        "code" : "X288",
        "display" : "DAW"
      },
      {
        "code" : "0088",
        "display" : "KANAMANTI (KANAMATI, CANAMANTI)"
      },
      {
        "code" : "X287",
        "display" : "CUJUBIM"
      },
      {
        "code" : "0087",
        "display" : "KAMPE"
      },
      {
        "code" : "X286",
        "display" : "CHARRUA"
      },
      {
        "code" : "0086",
        "display" : "KAMBIWA PIPIPA (PIPIPA)"
      },
      {
        "code" : "X285",
        "display" : "CARA PRETA"
      },
      {
        "code" : "0085",
        "display" : "KAMBIWA (CAMBIUA)"
      },
      {
        "code" : "X284",
        "display" : "CAMASURI"
      },
      {
        "code" : "0084",
        "display" : "KAMBEBA (CAMBEBA, OMAGUA)"
      },
      {
        "code" : "X283",
        "display" : "CAMARARÉ"
      },
      {
        "code" : "0083",
        "display" : "KAMBA (CAMBA)"
      },
      {
        "code" : "0082",
        "display" : "KAMAYURA (CAMAIURA, KAMAIURA)"
      },
      {
        "code" : "X282",
        "display" : "CABIXI"
      },
      {
        "code" : "0081",
        "display" : "KALAPALO (CALAPALO)"
      },
      {
        "code" : "X281",
        "display" : "BORBA"
      },
      {
        "code" : "0080",
        "display" : "KALANCO"
      },
      {
        "code" : "X280",
        "display" : "AWUARÁ"
      },
      {
        "code" : "0079",
        "display" : "KALABASSA (CALABASSA, CALABACAS)"
      },
      {
        "code" : "X279",
        "display" : "ASSURINI"
      },
      {
        "code" : "0078",
        "display" : "KAIXANA (CAIXANA)"
      },
      {
        "code" : "X278",
        "display" : "ARIPUANÁ"
      },
      {
        "code" : "0077",
        "display" : "KAINGANG (CAINGANGUE)"
      },
      {
        "code" : "X276",
        "display" : "ARARA APOLIMA"
      },
      {
        "code" : "0076",
        "display" : "KAIMBE (CAIMBE)"
      },
      {
        "code" : "X272",
        "display" : "ANACÉ"
      },
      {
        "code" : "0075",
        "display" : "KAIABI (CAIABI, KAYABI)"
      },
      {
        "code" : "X271",
        "display" : "AMAWÁKA"
      },
      {
        "code" : "0074",
        "display" : "KADIWEU (CADUVEO, CADIUEU)"
      },
      {
        "code" : "X269",
        "display" : "ALANTESU"
      },
      {
        "code" : "0073",
        "display" : "KAAPOR (URUBU-KAAPOR, KA'APOR, KAAPORTE)"
      },
      {
        "code" : "X267",
        "display" : "AIKANÃ-KWASÁ"
      },
      {
        "code" : "0072",
        "display" : "JURUTI (YURITI)"
      },
      {
        "code" : "X266",
        "display" : "AICABA"
      },
      {
        "code" : "0071",
        "display" : "JURUNA"
      },
      {
        "code" : "0070",
        "display" : "JUMA (YUMA)"
      },
      {
        "code" : "X265",
        "display" : "AHANENAWA"
      },
      {
        "code" : "0069",
        "display" : "JIRIPANCO (JERIPANCO, GERIPANCO)"
      },
      {
        "code" : "0264",
        "display" : "ZURUAHA (SOROWAHA, SURUWAHA)"
      },
      {
        "code" : "0068",
        "display" : "JARAWARA"
      },
      {
        "code" : "0263",
        "display" : "ZORO (PAGEYN)"
      },
      {
        "code" : "0067",
        "display" : "JAMAMADI (YAMAMADI, DJEOROMITXI)"
      },
      {
        "code" : "0262",
        "display" : "ZO'E (POTURU)"
      },
      {
        "code" : "0066",
        "display" : "JABOTI (JABUTI, KIPIU, YABYTI)"
      },
      {
        "code" : "0261",
        "display" : "YUDJA (JURUNA, YURUNA)"
      },
      {
        "code" : "0065",
        "display" : "ISSE"
      },
      {
        "code" : "0260",
        "display" : "YEKUANA (MAIONGON, YE'KUANA, YEKWANA, MAYONGONG)"
      },
      {
        "code" : "0064",
        "display" : "IRANXE (IRANTXE)"
      },
      {
        "code" : "0259",
        "display" : "YAWANAWA (IAUANAUA)"
      },
      {
        "code" : "0063",
        "display" : "INGARIKO (INGARICO, AKAWAIO, KAPON)"
      },
      {
        "code" : "0258",
        "display" : "YAWALAPITI (IAUALAPITI)"
      },
      {
        "code" : "0062",
        "display" : "HIMARIMA (HIMERIMA)"
      },
      {
        "code" : "0257",
        "display" : "YANOMAMI YANOMAM (IANOMAMI, IANOAMA, XI­RIANA)"
      },
      {
        "code" : "0061",
        "display" : "GUATO"
      },
      {
        "code" : "0256",
        "display" : "YANOMAMI SANUMA (IANOMAMI, IANOAMA, XI­RIANA)"
      },
      {
        "code" : "0060",
        "display" : "GUARANI NANDEVA (AVAKATUETE, CHIRIPA, NHANDEWA, AVA GUARANI)"
      },
      {
        "code" : "0255",
        "display" : "YANOMAMI NINAM (IANOMAMI, IANOAMA, XIRIA­NA)"
      },
      {
        "code" : "0059",
        "display" : "GUARANI M'BYA"
      },
      {
        "code" : "0254",
        "display" : "YAMINAWA (JAMINAWA, IAMINAWA)"
      },
      {
        "code" : "0058",
        "display" : "GUARANI KAIOWA (PAI TAVYTERA)"
      },
      {
        "code" : "0253",
        "display" : "YAIPIYANA"
      },
      {
        "code" : "0057",
        "display" : "GUAJAJARA (TENETEHARA)"
      },
      {
        "code" : "0252",
        "display" : "XUKURU KARIRI (XUCURU-KARIRI)"
      },
      {
        "code" : "0056",
        "display" : "GUAJA (AWA, AVA)"
      },
      {
        "code" : "0251",
        "display" : "XUKURU (XUCURU)"
      },
      {
        "code" : "0055",
        "display" : "GAVIAO PUKOBIE (PUKOBIE, PYKOPJE, GAVIAO DO MARANHAO)"
      },
      {
        "code" : "0250",
        "display" : "XOKO (XOCO, CHOCO)"
      },
      {
        "code" : "0054",
        "display" : "GAVIAO PARKATEJE (PARKATEJE)"
      },
      {
        "code" : "0249",
        "display" : "XOKLENG (SHOKLENG, XOCLENG)"
      },
      {
        "code" : "0053",
        "display" : "GAVIAO KRIKATEJE"
      },
      {
        "code" : "0052",
        "display" : "GAVIAO DE RONDONIA (DIGUT)"
      },
      {
        "code" : "0248",
        "display" : "XIPAIA (SHIPAYA, XIPAYA)"
      },
      {
        "code" : "0051",
        "display" : "GALIBI MARWORNO (GALIBI DO UACA, ARUA)"
      },
      {
        "code" : "0247",
        "display" : "XETA"
      },
      {
        "code" : "0050",
        "display" : "GALIBI (GALIBI DO OIAPOQUE, KARINHA)"
      },
      {
        "code" : "0246",
        "display" : "XERENTE (AKWE, AWEN, AKWEN)"
      },
      {
        "code" : "0049",
        "display" : "FULNI-O"
      },
      {
        "code" : "0245",
        "display" : "XAVANTE (A'UWE, AKWE, AWEN, AKWEN)"
      },
      {
        "code" : "0048",
        "display" : "ENAWENE-NAWE (SALUMA)"
      },
      {
        "code" : "0244",
        "display" : "XAKRIABA (XACRIABA)"
      },
      {
        "code" : "0047",
        "display" : "DIAHUI (JAHOI, JAHUI, DIARROI)"
      },
      {
        "code" : "0243",
        "display" : "WITOTO (UITOTO, HUITOTO)"
      },
      {
        "code" : "0046",
        "display" : "DESANA (DESANA, DESANO, DESSANO, WIRA, UMUKOMASA)"
      },
      {
        "code" : "0242",
        "display" : "WAYANA (WAIANA, UAIANA)"
      },
      {
        "code" : "0045",
        "display" : "DENI"
      },
      {
        "code" : "0241",
        "display" : "WAURA (UAURA, WAUJA)"
      },
      {
        "code" : "0044",
        "display" : "COLUMBIARA (CORUMBIARA)"
      },
      {
        "code" : "0240",
        "display" : "WASSU"
      },
      {
        "code" : "0043",
        "display" : "CINTA LARGA (MATETAMAE)"
      },
      {
        "code" : "0042",
        "display" : "CIKIYANA (SIKIANA)"
      },
      {
        "code" : "0239",
        "display" : "WAREKENA (UAREQUENA, WEREKENA)"
      },
      {
        "code" : "0041",
        "display" : "CHIQUITANO (XIQUITANO)"
      },
      {
        "code" : "0238",
        "display" : "WAPIXANA (UAPIXANA, VAPIDIANA, WAPISIANA, WAPISHANA)"
      },
      {
        "code" : "0040",
        "display" : "CHAMACOCO"
      },
      {
        "code" : "0237",
        "display" : "WANANO (UANANO, WANANA)"
      },
      {
        "code" : "0039",
        "display" : "CASSUPA"
      },
      {
        "code" : "0236",
        "display" : "WAIMIRI ATROARI (KINA)"
      },
      {
        "code" : "0038",
        "display" : "CANOE"
      },
      {
        "code" : "0235",
        "display" : "WAIAPI (WAYAMPI, OYAMPI, WAYAPY, )"
      },
      {
        "code" : "0037",
        "display" : "BOTOCUDO (GEREN)"
      },
      {
        "code" : "0234",
        "display" : "WAI WAI MAWAYANA (MAWAYANA)"
      },
      {
        "code" : "0036",
        "display" : "BORORO (BOE)"
      },
      {
        "code" : "0233",
        "display" : "WAI WAI KATUENA (KATUENA)"
      },
      {
        "code" : "0035",
        "display" : "BARE"
      },
      {
        "code" : "0232",
        "display" : "WAI WAI XEREU (XEREU)"
      },
      {
        "code" : "0034",
        "display" : "BARASANA (HANERA)"
      },
      {
        "code" : "0231",
        "display" : "WAI WAI KARAFAWYANA (KARAFAWYANA, KARA­PAWYANA)"
      },
      {
        "code" : "0033",
        "display" : "BARA (WAIPINOMAKA)"
      },
      {
        "code" : "0230",
        "display" : "WAI WAI HIXKARYANA (HIXKARYANA)"
      },
      {
        "code" : "0032",
        "display" : "BANIWA (BANIUA, BANIVA, WALIMANAI, WAKUE­NAI)"
      },
      {
        "code" : "0229",
        "display" : "URU-EU-WAU-WAU (URUEU-UAU-UAU, URUPAIN, URUPA)"
      },
      {
        "code" : "0031",
        "display" : "BANAWA YAFI (BANAWA, BANAWA-JAFI)"
      },
      {
        "code" : "0228",
        "display" : "UMUTINA (OMOTINA, BARBADOS)"
      },
      {
        "code" : "0030",
        "display" : "BAKAIRI (KURA, BACAIRI)"
      },
      {
        "code" : "0227",
        "display" : "TXIKAO (TXICAO, IKPENG)"
      },
      {
        "code" : "0029",
        "display" : "AWETI (AUETI/AUETO)"
      },
      {
        "code" : "0226",
        "display" : "TUYUKA (TUIUCA, DOKAPUARA, UTAPINOMAKA­PHONA)"
      },
      {
        "code" : "0028",
        "display" : "AVA - CANOEIRO"
      },
      {
        "code" : "0225",
        "display" : "TUXA"
      },
      {
        "code" : "0027",
        "display" : "ATIKUM (ATICUM)"
      },
      {
        "code" : "0026",
        "display" : "ASURINI DO XINGU (AWAETE)"
      },
      {
        "code" : "0224",
        "display" : "TURIWARA"
      },
      {
        "code" : "0025",
        "display" : "ASURINI DO TOCANTINS (AKUAWA/AKWAWA)"
      },
      {
        "code" : "0223",
        "display" : "TUPINIQUIM"
      },
      {
        "code" : "0024",
        "display" : "ASHANINKA (KAMPA)"
      },
      {
        "code" : "0222",
        "display" : "TUPINAMBA"
      },
      {
        "code" : "0023",
        "display" : "ARUAK (ARAWAK)"
      },
      {
        "code" : "0221",
        "display" : "TUPARI"
      },
      {
        "code" : "0022",
        "display" : "ARUA"
      },
      {
        "code" : "0220",
        "display" : "TUNAYANA"
      },
      {
        "code" : "0021",
        "display" : "ARIKOSE (ARICOBE)"
      },
      {
        "code" : "0219",
        "display" : "TUMBALALA"
      },
      {
        "code" : "0020",
        "display" : "ARIKEM (ARIQUEN, ARIQUEME, ARIKEME)"
      },
      {
        "code" : "0019",
        "display" : "ARIKAPU (ARICAPU, ARIKAPO, MASUBI, MAXUBI)"
      },
      {
        "code" : "0218",
        "display" : "TUKANO (TUCANO, YE'PA-MASA, DASEA)"
      },
      {
        "code" : "0018",
        "display" : "ARAWETE (ARAUETE)"
      },
      {
        "code" : "0217",
        "display" : "TSOHOM DJAPA (TSUNHUM-DJAPA)"
      },
      {
        "code" : "0017",
        "display" : "ARARA DO PARA (UKARAGMA, UKARAMMA)"
      },
      {
        "code" : "0216",
        "display" : "TRUMAI"
      },
      {
        "code" : "0016",
        "display" : "ARARA DO ARIPUANA (ARARA DO BEIRADAO/ARI­PUANA)"
      },
      {
        "code" : "0215",
        "display" : "TRUKA"
      },
      {
        "code" : "0015",
        "display" : "ARARA DO ACRE (SHAWANAUA, AMAWAKA)"
      },
      {
        "code" : "0214",
        "display" : "TREMEMBE"
      },
      {
        "code" : "0014",
        "display" : "ARARA DE RONDONIA (KARO, URUCU, URUKU)"
      },
      {
        "code" : "0213",
        "display" : "TORA"
      },
      {
        "code" : "0013",
        "display" : "ARAPASO (ARAPACO)"
      },
      {
        "code" : "0212",
        "display" : "TIRIYO TSIKUYANA (TIRIYO, TRIO, TARONA, YAWI, PIANOKOTO)"
      },
      {
        "code" : "0012",
        "display" : "ARANA (ARACUAI DO VALE DO JEQUITINHONHA)"
      },
      {
        "code" : "0211",
        "display" : "TIRIYO KAH'YANA (TIRIYO, TRIO, TARONA, YAWI, PIANOKOTO)"
      },
      {
        "code" : "0011",
        "display" : "APURINA (APORINA, IPURINA, IPURINA, IPURI­NAN)"
      },
      {
        "code" : "0210",
        "display" : "TIRIYO EWARHUYANA (TIRIYO, TRIO, TARONA, YAWI, PIANOKOTO)"
      },
      {
        "code" : "0010",
        "display" : "APINAYE (APINAJE/APINAIE/APINAGE)"
      },
      {
        "code" : "0209",
        "display" : "TINGUI BOTO"
      },
      {
        "code" : "0009",
        "display" : "APIAKA (APIACA)"
      },
      {
        "code" : "0008",
        "display" : "APARAI (APALAI)"
      },
      {
        "code" : "0208",
        "display" : "TICUNA (TIKUNA, TUKUNA, MAGUTA)"
      },
      {
        "code" : "0007",
        "display" : "ANAMBE"
      },
      {
        "code" : "0207",
        "display" : "TERENA"
      },
      {
        "code" : "0006",
        "display" : "AMONDAWA"
      },
      {
        "code" : "0206",
        "display" : "TENHARIM"
      },
      {
        "code" : "0005",
        "display" : "AMANAYE"
      },
      {
        "code" : "0205",
        "display" : "TEMBE"
      },
      {
        "code" : "0004",
        "display" : "AKUNSU (AKUNT'SU)"
      },
      {
        "code" : "0204",
        "display" : "TAUREPANG (TAULIPANG, PEMON, AREKUNA, PA­GEYN)"
      },
      {
        "code" : "0003",
        "display" : "AJURU"
      },
      {
        "code" : "0203",
        "display" : "TARIANO (TARIANA, TALIASERI)"
      },
      {
        "code" : "0002",
        "display" : "AIKANA (AIKANA, MAS SAKA,TUBARAO)"
      },
      {
        "code" : "0202",
        "display" : "TAPUIA (TAPUIA-XAVANTE, TAPUIO)"
      },
      {
        "code" : "0001",
        "display" : "ACONA (WAKONAS, NACONAS, JAKONA, ACORA­NES)"
      },
      {
        "code" : "0201",
        "display" : "TAPIRAPE (TAPI'IRAPE)"
      }]
    }]
  }
}

```

# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BRExameHPV - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BRExameHPV**

## ValueSet: BRExameHPV 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/ValueSet/BRExameHPV | *Versão*:1.1.0 |
| Active as of 2026-09-01 | *Nome computável*:BRExameHPV |

 **References** 

Este conjunto de valores não é utilizado aqui; pode ser utilizado noutro local (por exemplo, especificações e/ou implementações que utilizem este conteúdo)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRExameHPV",
  "url" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRExameHPV",
  "version" : "1.1.0",
  "name" : "BRExameHPV",
  "title" : "BRExameHPV",
  "status" : "active",
  "date" : "2026-09-01T09:42:43-04:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRExameHPVCEPHEID",
      "concept" : [{
        "code" : "OUT",
        "display" : "Outros HPV ( 31, 33, 35, 39, 51, 52, 56, 58, 59, 66 e 68)"
      },
      {
        "code" : "HPV1845",
        "display" : "Human papilloma virus 18+45 mRNA"
      }]
    },
    {
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "17399-7",
        "display" : "Human papilloma virus 16 Ag"
      }]
    },
    {
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRCID10",
      "concept" : [{
        "code" : "M54.9",
        "display" : "Dorsalgia não especificada"
      },
      {
        "code" : "M54.8",
        "display" : "Outra dorsalgia"
      },
      {
        "code" : "M54.6",
        "display" : "Dor na coluna torácica"
      },
      {
        "code" : "M54.5",
        "display" : "Dor lombar baixa"
      },
      {
        "code" : "M54.4",
        "display" : "Lumbago com ciática"
      },
      {
        "code" : "M54.3",
        "display" : "Ciática"
      },
      {
        "code" : "M54.2",
        "display" : "Cervicalgia"
      },
      {
        "code" : "M54.1",
        "display" : "Radiculopatia"
      },
      {
        "code" : "M54.0",
        "display" : "Paniculite atingindo regiões do pescoço e do dorso"
      },
      {
        "code" : "M54",
        "display" : "Dorsalgia"
      },
      {
        "code" : "M53.9",
        "display" : "Dorsopatia não especificada"
      },
      {
        "code" : "M53.8",
        "display" : "Outras dorsopatias especificadas"
      },
      {
        "code" : "M53.3",
        "display" : "Transtornos sacroccígeos não classificados em outra parte"
      },
      {
        "code" : "M53.2",
        "display" : "Instabilidades da coluna vertebral"
      },
      {
        "code" : "M53.1",
        "display" : "Síndrome cervicobraquial"
      },
      {
        "code" : "M53.0",
        "display" : "Síndrome cervicocraniana"
      },
      {
        "code" : "M53",
        "display" : "Outras dorsopatias não classificadas em outra parte"
      },
      {
        "code" : "M51.9",
        "display" : "Transtorno não especificado de disco intervertebral"
      },
      {
        "code" : "M51.8",
        "display" : "Outros transtornos especificados de discos intervertebrais"
      },
      {
        "code" : "M51.4",
        "display" : "Nódulos de Schmorl"
      },
      {
        "code" : "M51.3",
        "display" : "Outra degeneração especificada de disco intervertebral"
      },
      {
        "code" : "M51.2",
        "display" : "Outros deslocamentos discais intervertebrais especificados"
      },
      {
        "code" : "M51.1",
        "display" : "Transtornos de discos lombares e de outros discos intervertebrais com radiculopatia"
      },
      {
        "code" : "M51.0",
        "display" : "Transtornos de discos lombares e de outros discos intervertebrais com mielopatia"
      },
      {
        "code" : "M51",
        "display" : "Outros transtornos de discos intervertebrais"
      },
      {
        "code" : "M50.9",
        "display" : "Transtorno não especificado de disco cervical"
      },
      {
        "code" : "M50.8",
        "display" : "Outros transtornos de discos cervicais"
      },
      {
        "code" : "M50.3",
        "display" : "Outra degeneração de disco cervical"
      },
      {
        "code" : "M50.2",
        "display" : "Outro deslocamento de disco cervical"
      },
      {
        "code" : "M50.1",
        "display" : "Transtorno do disco cervical com radiculopatia"
      },
      {
        "code" : "M50.0",
        "display" : "Transtorno do disco cervical com mielopatia"
      },
      {
        "code" : "M50",
        "display" : "Transtornos dos discos cervicais"
      }]
    }]
  }
}

```

# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BRNomeExameLOINC - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BRNomeExameLOINC**

## ValueSet: BRNomeExameLOINC 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/ValueSet/BRNomeExameLOINC | *Versão*:1.1.0 |
| Active as of 2026-09-01 | *Nome computável*:BRNomeExameLOINC |

 **References** 

Este conjunto de valores não é utilizado aqui; pode ser utilizado noutro local (por exemplo, especificações e/ou implementações que utilizem este conteúdo)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRNomeExameLOINC",
  "url" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRNomeExameLOINC",
  "version" : "1.1.0",
  "name" : "BRNomeExameLOINC",
  "title" : "BRNomeExameLOINC",
  "status" : "active",
  "date" : "2026-09-01T09:42:43-04:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRNomeExameLOINC",
      "concept" : [{
        "code" : "95689-6",
        "display" : "Vírus Mayaro Anticorpos IgM [Presença] na amostra por imunoensaio"
      },
      {
        "code" : "38166-5",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgM [unidades/volume] no soro por imunoensaio"
      },
      {
        "code" : "39573-1",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgM [unidades/volume] em líquido cerebroespinhal por imunoensaio"
      },
      {
        "code" : "33331-0",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgM [Título] no soro"
      },
      {
        "code" : "29567-5",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgM [presença] no soro por imunoensaio"
      },
      {
        "code" : "95707-6",
        "display" : "Vírus Mayaro IgA Ac [Presença] na amostra por imunoensaio"
      },
      {
        "code" : "31703-2",
        "display" : "Vírus do Nilo Ocidental Igm Ac [presença] no fluido espinhal cerebral"
      },
      {
        "code" : "95674-8",
        "display" : "Anticorpos IgG contra vírus Mayaro [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "29778-8",
        "display" : "Vírus do Nilo Ocidental IgM Ac [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "81650-4",
        "display" : "Vírus do Nilo Ocidental Kunjin Strain RNA [presença] em amostra por NaA com detecção de sonda"
      },
      {
        "code" : "74857-4",
        "display" : "RNA do vírus do Nilo Ocidental [presença] no soro ou plasma do doador pela NAA com detecção de sonda"
      },
      {
        "code" : "34461-4",
        "display" : "RNA do vírus do Nilo Ocidental [presença] no líquido espinhal cerebral por NaA com detecção de sonda"
      },
      {
        "code" : "87395-0",
        "display" : "RNA do vírus do Nilo Ocidental [limiar de ciclo #] em amostras por NaA com detecção de sonda"
      },
      {
        "code" : "41212-2",
        "display" : "RNA do vírus do Nilo Ocidental [presença] no soro do doador pela NAA com detecção de sonda"
      },
      {
        "code" : "29569-1",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgM [Presença] no líquido cerebroespinhal por imunoensaio"
      },
      {
        "code" : "103721-7",
        "display" : "RNA do vírus do Nilo Ocidental [presença] no sangue por NAA com detecção sem probe"
      },
      {
        "code" : "34460-6",
        "display" : "RNA do vírus do Nilo Ocidental [presença] no sangue por NaA com detecção de sonda"
      },
      {
        "code" : "97185-3",
        "display" : "RNA do vírus do Nilo Ocidental [presença] na urina por NaA com detecção de sonda"
      },
      {
        "code" : "32370-9",
        "display" : "RNA do vírus do Nilo Ocidental [presença] em tecido por NAA com detecção de sonda"
      },
      {
        "code" : "32361-8",
        "display" : "RNA do vírus do Nilo Ocidental [presença] no soro por NaA com detecção de sonda"
      },
      {
        "code" : "29570-9",
        "display" : "Anticorpo neutralizante do vírus do Nilo Ocidental [Título] no líquido espinhal cerebral por teste de neutralização"
      },
      {
        "code" : "38997-3",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgG [unidades/volume] no soro por imunoensaio"
      },
      {
        "code" : "29537-8",
        "display" : "Vírus do Nilo Ocidental IgG Ac [unidades/volume] em líquido espinhal cerebral"
      },
      {
        "code" : "43342-5",
        "display" : "Vírus do Nilo Ocidental Igm Ac [Título] em líquido espinhal cerebral por imunoensaio"
      },
      {
        "code" : "39572-3",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgG [unidades/volume] em líquido cerebroespinhal por imunoensaio"
      },
      {
        "code" : "33329-4",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgG [Título] no soro"
      },
      {
        "code" : "94289-6",
        "display" : "Vírus do Nilo Ocidental IgG Ac [Título] no soro"
      },
      {
        "code" : "33328-6",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgG [Título] no líquido cerebroespinhal"
      },
      {
        "code" : "41642-0",
        "display" : "Vírus do Nilo Ocidental Igm Ac [presença] em amostra por imunofluorescência"
      },
      {
        "code" : "41236-1",
        "display" : "Vírus do Nilo Ocidental IgG Ac [presença] no fluido espinhal cerebral"
      },
      {
        "code" : "62436-1",
        "display" : "Vírus do Nilo Ocidental Igm Ac [presença] no líquido corporal por imunoensaio"
      },
      {
        "code" : "60029-6",
        "display" : "Vírus do Nilo Ocidental IgG Ac Avidez [presença] no soro por imunofluorescência"
      },
      {
        "code" : "29566-7",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgG [presença] no soro por imunoensaio"
      },
      {
        "code" : "41196-7",
        "display" : "Vírus do Nilo Ocidental IgG Ac [Título] no fluido corporal"
      },
      {
        "code" : "36898-5",
        "display" : "Vírus do Nilo Ocidental NS5 Ac [presença] em amostra por imunoensaio"
      },
      {
        "code" : "41643-8",
        "display" : "Vírus do Nilo Ocidental AG [presença] em amostra por imunofluorescência"
      },
      {
        "code" : "50015-7",
        "display" : "Vírus do Nilo Ocidental AG [presença] em sangue ou medula de doador"
      },
      {
        "code" : "41206-4",
        "display" : "Vírus do Nilo Ocidental Ac [unidades/volume] em líquido espinhal cerebral"
      },
      {
        "code" : "94602-0",
        "display" : "Vírus do Nilo Ocidental IgM AB/Controle positivo no soro por imunoensaio"
      },
      {
        "code" : "33330-2",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgM [Título] em líquido cerebroespinhal"
      },
      {
        "code" : "41195-9",
        "display" : "Vírus do Nilo Ocidental Igm Ac [Título] no fluido corporal"
      },
      {
        "code" : "97917-9",
        "display" : "RNA do vírus Oropouche [Presença] em espécime por AAN com detecção por sonda"
      },
      {
        "code" : "30178-8",
        "display" : "Vírus do Nilo Ocidental IgG Ac [presença] em amostra por imunoensaio"
      },
      {
        "code" : "60030-4",
        "display" : "Vírus do Nilo Ocidental IgG Ac [presença] no soro por imunofluorescência"
      },
      {
        "code" : "95703-5",
        "display" : "Vírus do Nilo Ocidental IGA Ac [presença] em amostra por imunoensaio"
      },
      {
        "code" : "81096-0",
        "display" : "Vírus do Nilo Ocidental Kunjin Strain igm Ac [presença] no soro"
      },
      {
        "code" : "43343-3",
        "display" : "Vírus do Nilo Ocidental Igm Ac [Título] no soro por imunoensaio"
      },
      {
        "code" : "29780-4",
        "display" : "Vírus do Nilo Ocidental Igm Ac [Presença] em amostra"
      },
      {
        "code" : "97931-0",
        "display" : "RNA do vírus Mayaro [Presença] em espécime por AAN com detecção por sonda"
      },
      {
        "code" : "37985-9",
        "display" : "RNA do vírus do Nilo Ocidental [presença] em amostra por sonda"
      },
      {
        "code" : "29538-6",
        "display" : "Vírus do Nilo Ocidental Igm Ac [unidades/volume] em líquido espinhal cerebral"
      },
      {
        "code" : "60028-8",
        "display" : "Vírus do Nilo Ocidental IgG Ac Avidez [Presença] no soro por imunoensaio"
      },
      {
        "code" : "94854-7",
        "display" : "Painel de IgG e IgM do vírus do Nilo Ocidental - qualitativo sérico"
      },
      {
        "code" : "77953-8",
        "display" : "Vírus do Nilo Ocidental Anticorpos IgG [Presença] no líquido cerebroespinhal por imunoensaio"
      },
      {
        "code" : "94853-9",
        "display" : "Painel de IgG e IgM do Vírus do Nilo Ocidental - qualitativa de líquido espinhal cerebral"
      },
      {
        "code" : "96531-9",
        "display" : "Anticorpos IgM contra vírus Oropouche [Presença] em espécime por imunoensaio"
      },
      {
        "code" : "41224-7",
        "display" : "Vírus do Nilo Ocidental Ac [Título] no líquido espinhal cerebral"
      },
      {
        "code" : "96506-1",
        "display" : "Anticorpos IgG contra vírus Oropouche [Presença] em espécime por imunoensaio"
      },
      {
        "code" : "99120-8",
        "display" : "Anticorpos neutralizantes contra vírus Oropouche [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "95650-8",
        "display" : "Anticorpos neutralizantes contra vírus Mayaro [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "36897-7",
        "display" : "Vírus do Nilo Ocidental Ac [presença] em amostra por imunoensaio"
      },
      {
        "code" : "55402-2",
        "display" : "Painel IgG e IgM do vírus do Nilo Ocidental - soro"
      },
      {
        "code" : "39558-2",
        "display" : "Vírus do Nilo Ocidental Ac [presença] no fluido espinhal cerebral"
      },
      {
        "code" : "36901-7",
        "display" : "Vírus do Nilo Ocidental NS5 Ac [Presença] em amostras"
      },
      {
        "code" : "32371-7",
        "display" : "Vírus do Nilo Ocidental AG [presença] em tecido por mancha imunológica"
      },
      {
        "code" : "41211-4",
        "display" : "Vírus do Nilo Ocidental IgG+IgM Ac [Presença] no soro"
      },
      {
        "code" : "31702-4",
        "display" : "Vírus do Nilo Ocidental IgG Ac [presença] em amostra"
      },
      {
        "code" : "55380-0",
        "display" : "Vírus do Nilo Ocidental Ac [Título] em soro por inibição da hemaglutinação"
      },
      {
        "code" : "29781-2",
        "display" : "Vírus do Nilo Ocidental Ac [Título] na amostra"
      },
      {
        "code" : "34892-0",
        "display" : "RNA do vírus do Nilo Ocidental [presença] em amostra por AAN com detecção por sonda"
      },
      {
        "code" : "41194-2",
        "display" : "Vírus do Nilo Ocidental Ac [unidades/volume] em soro por imunoensaio"
      },
      {
        "code" : "36896-9",
        "display" : "Vírus do Nilo Ocidental polivalente E Ac [presença] em amostra por imunoensaio"
      },
      {
        "code" : "29779-6",
        "display" : "Anticorpo neutralizante do vírus do Nilo Ocidental [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "81097-8",
        "display" : "Vírus do Nilo Ocidental Kunjin Strain Ac [presença] no soro"
      },
      {
        "code" : "29568-3",
        "display" : "Anticorpos neutralizantes contra vírus do Nilo Ocidental [Título] no soro por teste de neutralização"
      },
      {
        "code" : "33468-0",
        "display" : "Vírus do Nilo Ocidental Ac [presença] em amostra"
      },
      {
        "code" : "31700-8",
        "display" : "Vírus do Nilo Ocidental Ac [unidades/volume] em amostra"
      },
      {
        "code" : "75404-4",
        "display" : "Vírus do Nilo Ocidental Ac [presença] no soro por inibição da hemaglutinação"
      },
      {
        "code" : "29535-2",
        "display" : "Vírus do Nilo Ocidental IgG Ac [unidades/volume] no soro"
      },
      {
        "code" : "29536-0",
        "display" : "Vírus do Nilo Ocidental IgM Ac [unidades/volume] no soro"
      },
      {
        "code" : "31704-0",
        "display" : "Vírus do Nilo Ocidental Igm Ac [presença] no soro"
      },
      {
        "code" : "31701-6",
        "display" : "Vírus do Nilo Ocidental IgG Ac [presença] no soro"
      },
      {
        "code" : "39555-8",
        "display" : "Vírus do Nilo Ocidental Ac [unidades/volume] no soro"
      },
      {
        "code" : "41225-4",
        "display" : "Vírus do Nilo Ocidental Ac [Título] no soro"
      },
      {
        "code" : "36900-9",
        "display" : "Vírus do Nilo Ocidental polivalente E Ac [presença] em amostra"
      },
      {
        "code" : "86190-6",
        "display" : "RNA do vírus Zika [Presença] no Plasma do Doador por NAA com detecção por sonda"
      },
      {
        "code" : "89368-5",
        "display" : "Painel IgM de proteína não estrutural 1 contra o vírus Zika - Soro ou Plasma por imunoensaio"
      },
      {
        "code" : "89369-3",
        "display" : "Anticorpo IgM Proteína não estrutural 1 contra o vírus Zika [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "89370-1",
        "display" : "Proteína não estrutural 1 IgM Anticorpo contra o vírus Zika [Interpretação] em soro por imunoensaio"
      },
      {
        "code" : "83069-5",
        "display" : "Proteína não estrutural 1 IgG Anticorpo contra o vírus Zika [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "86321-7",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Título] em espécime por teste de neutralização"
      },
      {
        "code" : "80623-2",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Título] em soro por teste de neutralização --2ª amostra"
      },
      {
        "code" : "80622-4",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Título] em soro por teste de neutralização --1ª amostra"
      },
      {
        "code" : "80620-8",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Título] no soro por teste de neutralização"
      },
      {
        "code" : "80625-7",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Título] no líquido cefalorraquidiano por teste de neutralização --2ª amostra"
      },
      {
        "code" : "80624-0",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Título] no líquido cefalorraquidiano por teste de neutralização --1ª amostra"
      },
      {
        "code" : "80621-6",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Título] no líquido cefalorraquidiano por teste de neutralização"
      },
      {
        "code" : "86320-9",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Presença] em espécime por teste de neutralização"
      },
      {
        "code" : "80822-0",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Presença] no soro por teste de neutralização"
      },
      {
        "code" : "80821-2",
        "display" : "Anticorpo neutralizante contra o vírus Zika [Presença] no fluido espinhal cerebral por teste de neutralização"
      },
      {
        "code" : "103963-5",
        "display" : "LinhAntígeno em contra o vírus Zika [Identificador] em espécime pelo método de genética molecular"
      },
      {
        "code" : "87622-7",
        "display" : "Anticorpo contra o vírus da Dengue[Presença] em espécime por imunoensaio"
      },
      {
        "code" : "82731-1",
        "display" : "Anticorpo IgM contra o vírus Zika [Presença] no Soro por Imunofluorescência"
      },
      {
        "code" : "104476-7",
        "display" : "Anticorpo IgG contra o vírus Zika [Título] em soro por imunoensaio – 2ª amostra"
      },
      {
        "code" : "104475-9",
        "display" : "Anticorpo IgG contra o vírus Zika [Título] em soro por imunoensaio – 1ª amostra"
      },
      {
        "code" : "87439-6",
        "display" : "Anticorpo contra o vírus Zika IgA+IgG+IgM [Interpretação] em espécime qualitativo por imunoensaio"
      },
      {
        "code" : "81148-9",
        "display" : "Gene E do envelope contra o vírus Zika [Presença] na urina por NAA com detecção por sonda"
      },
      {
        "code" : "81149-7",
        "display" : "Gene E do envelope contra o vírus Zika [Presença] no líquido amniótico por NAA com detecção por sonda"
      },
      {
        "code" : "80825-3",
        "display" : "Gene E do envelope contra o vírus Zika [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "80826-1",
        "display" : "Gene E do envelope contra o vírus Zika [Presença] no fluido espinhal cerebral por NAA com detecção por sonda"
      },
      {
        "code" : "103722-5",
        "display" : "RNA do vírus da Febre Amarela [Presença] no sangue por NAA com detecção sem sonda"
      },
      {
        "code" : "77959-5",
        "display" : "Gene ns5 contra o vírus da Febre Amarela [Presença] no fluido espinhal cerebral por NAA com detecção sem sonda"
      },
      {
        "code" : "6591-2",
        "display" : "Anticorpo neutralizante contra o vírus da Febre Amarela [Unidades/volume] em soro por teste de neutralização"
      },
      {
        "code" : "95651-6",
        "display" : "Anticorpo neutralizante contra o vírus da Febre Amarela [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "71783-5",
        "display" : "Anticorpo neutralizante contra o vírus da Febre Amarela [Título] no líquido cefalorraquidiano por teste de neutralização"
      },
      {
        "code" : "8056-4",
        "display" : "Anticorpo IgM contra o vírus da Febre Amarela [Unidades/volume] em soro"
      },
      {
        "code" : "41216-3",
        "display" : "Anticorpo IgM vírus da Febre Amarela [Presença] no Soro"
      },
      {
        "code" : "8055-6",
        "display" : "Anticorpo IgG contra o vírus da Febre Amarela [Unidades/volume] no soro"
      },
      {
        "code" : "104463-5",
        "display" : "Anticorpo IgG contra o vírus da Febre Amarela [Título] em soro por imunoensaio - 2ª amostra"
      },
      {
        "code" : "104461-9",
        "display" : "Anticorpo IgG contra o vírus da Febre Amarela [Título] em soro por imunoensaio"
      },
      {
        "code" : "41217-1",
        "display" : "Anticorpo IgG vírus da Febre Amarela [Presença] no Soro"
      },
      {
        "code" : "95708-4",
        "display" : "Anticorpo IgA contra o vírus da Febre Amarela [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "8054-9",
        "display" : "Anticorpo contra o vírus da Febre Amarela [Unidades/volume] em soro"
      },
      {
        "code" : "6589-6",
        "display" : "Anticorpo contra o vírus da Febre Amarela [Título] em soro por imunofluorescência"
      },
      {
        "code" : "41246-0",
        "display" : "Anticorpo contra o vírus da Febre Amarela [Título] em soro - 2ª amostra"
      },
      {
        "code" : "41247-8",
        "display" : "Anticorpo contra o vírus da Febre Amarela [Título] em soro - 1ª amostra"
      },
      {
        "code" : "41249-4",
        "display" : "Anticorpo contra o vírus da Febre Amarela [Presença] no soro"
      },
      {
        "code" : "22618-3",
        "display" : "Anticorpo contra o vírus da Febre Amarela [Título] em soro"
      },
      {
        "code" : "80206-6",
        "display" : "Encefalite japonesa+encefalite transmitida por carrapatos+Nilo Ocidental+Vírus da febre amarela IgM Ac [presença] no soro por imunofluorescência"
      },
      {
        "code" : "80205-8",
        "display" : "Encefalite japonesa+encefalite transmitida por carrapatos+Nilo Ocidental+Vírus da Febre Amarela IgG [presença] no soro ou plasma por imunofluorescência"
      },
      {
        "code" : "85584-1",
        "display" : "RNA do vírus da Dengue [presença] no plasma do doador pela NAA com detecção por sonda"
      },
      {
        "code" : "82383-1",
        "display" : "RNA do vírus da Dengue 2+4 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "99111-7",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue [Título] em espécime por teste de neutralização"
      },
      {
        "code" : "50036-3",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue [Presença] em espécime por teste de neutralização"
      },
      {
        "code" : "82384-9",
        "display" : "RNA do vírus da Dengue 1+3 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "23968-1",
        "display" : "Anticorpo IgM contra o vírus da Dengue [unidades/volume] no soro"
      },
      {
        "code" : "104387-6",
        "display" : "Anticorpo IgM contra o vírus da Dengue [Título] em soro por imunoensaio --2ª amostra"
      },
      {
        "code" : "104386-8",
        "display" : "Anticorpo IgM contra o vírus da Dengue [Título] em soro por imunoensaio --1ª amostra"
      },
      {
        "code" : "6812-2",
        "display" : "Anticorpo IgM contra o vírus da Dengue [Título] no soro"
      },
      {
        "code" : "25392-2",
        "display" : "Anticorpo IgM contra o vírus da Dengue [Presença] no soro por imunoblot"
      },
      {
        "code" : "25338-5",
        "display" : "Anticorpo IgM contra o vírus da Dengue [Presença] no soro"
      },
      {
        "code" : "101304-4",
        "display" : "RNA do vírus da Dengue 1+2+3+4 [Presença] no sangue por NAA com detecção sem sonda"
      },
      {
        "code" : "87546-8",
        "display" : "Painel IgG e IgM contra o vírus da Dengue - Soro Qualitativo"
      },
      {
        "code" : "51785-4",
        "display" : "Anticorpo IgG e IgM contra o vírus da Dengue [Interpretação] em soro"
      },
      {
        "code" : "23958-2",
        "display" : "Anticorpo IgG contra o vírus da Dengue [unidades/volume] no soro"
      },
      {
        "code" : "104384-3",
        "display" : "Anticorpo IgG contra o vírus da Dengue [Título] em soro por imunoensaio -- 2ª amostra"
      },
      {
        "code" : "104383-5",
        "display" : "Anticorpo IgG contra o vírus da Dengue [Título] em soro por imunoensaio --1ª amostra"
      },
      {
        "code" : "6811-4",
        "display" : "Anticorpo IgG contra o vírus da Dengue [Título] no soro"
      },
      {
        "code" : "88203-5",
        "display" : "RNA do vírus da Dengue 1 e 2 e 3 e 4 [Identificador] em soro ou sangue por NAA com detecção por sonda"
      },
      {
        "code" : "29676-4",
        "display" : "Anticorpo IgG contra o vírus da Dengue [Presença] no soro"
      },
      {
        "code" : "100965-3",
        "display" : "Anticorpo IgG contra o vírus da Dengue [interpretação] em soro, plasma ou sangue"
      },
      {
        "code" : "95706-8",
        "display" : "Anticorpo IgA contra o vírus da Dengue [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "6387-5",
        "display" : "DNA do vírus da Dengue [Presença] em espécime por sonda"
      },
      {
        "code" : "6386-7",
        "display" : "DNA do vírus da Dengue [presença] no soro por sonda"
      },
      {
        "code" : "31799-0",
        "display" : "Antígeno  contra o vírus da Dengue [Presença] em Amostra"
      },
      {
        "code" : "6385-9",
        "display" : "Dengue vírus Antígeno  [Presença] em espécime por imunofluorescência"
      },
      {
        "code" : "6384-2",
        "display" : "Dengue vírus Antígeno  [Presença] em Soro por Imunofluorescência"
      },
      {
        "code" : "31798-2",
        "display" : "Antígeno  contra o vírus da Dengue [presença] no soro"
      },
      {
        "code" : "100962-0",
        "display" : "Anticorpo IgG painel contra o vírus da Dengue - Soro, Plasma ou Sangue"
      },
      {
        "code" : "31342-9",
        "display" : "Anticorpo contra o vírus da Dengue [Unidades/volume] em espécime"
      },
      {
        "code" : "7859-2",
        "display" : "Anticorpo contra o vírus da Dengue [unidades/volume] no soro"
      },
      {
        "code" : "40515-9",
        "display" : "Anticorpo contra o vírus da Dengue [Título] no soro por fixação do complemento"
      },
      {
        "code" : "33606-5",
        "display" : "Anticorpo contra o vírus da Dengue [Título] em soro"
      },
      {
        "code" : "31343-7",
        "display" : "Anticorpo contra o vírus da Dengue [Presença] em espécime"
      },
      {
        "code" : "16740-3",
        "display" : "Anticorpo contra o vírus da Dengue [Presença] no soro"
      },
      {
        "code" : "40748-6",
        "display" : "Anticorpo contra o vírus da Dengue [Presença] no soro por inibição da Hemaglutinação"
      },
      {
        "code" : "82519-0",
        "display" : "Painel de vírus da Dengue 1+3 e 2+4 - Soro por NAA com detecção por sonda"
      },
      {
        "code" : "86861-2",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 4 [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "31341-1",
        "display" : "Anticorpo contra o vírus da Dengue 4 [Unidades/volume] em soro"
      },
      {
        "code" : "16739-5",
        "display" : "Anticorpo contra o vírus da Dengue 4 [Título] em soro"
      },
      {
        "code" : "7858-4",
        "display" : "Anticorpo contra o vírus da Dengue 4 [Presença] no soro por imunoensaio"
      },
      {
        "code" : "22253-9",
        "display" : "Anticorpo contra o vírus da Dengue 4 [Presença] no soro"
      },
      {
        "code" : "86862-0",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 4 [Presença] em amostra por teste de neutralização"
      },
      {
        "code" : "86859-6",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 3 [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "86863-8",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 3 [Presença] em amostra por teste de neutralização"
      },
      {
        "code" : "31340-3",
        "display" : "Anticorpo contra o vírus da Dengue 3 [Unidades/volume] em soro"
      },
      {
        "code" : "16738-7",
        "display" : "Anticorpo contra o vírus da Dengue 3 [Título] em soro"
      },
      {
        "code" : "7857-6",
        "display" : "Anticorpo contra o vírus da Dengue 3 [Presença] no soro por imunoensaio"
      },
      {
        "code" : "22252-1",
        "display" : "Anticorpo contra o vírus da Dengue 3 [Presença] no soro"
      },
      {
        "code" : "86858-8",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 2 [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "86864-6",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 2 [Presença] em amostra por teste de neutralização"
      },
      {
        "code" : "86860-4",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 1 [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "86865-3",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue 1 [Presença] em amostra por teste de neutralização"
      },
      {
        "code" : "31339-5",
        "display" : "Anticorpo contra o vírus da Dengue 2 [Unidades/volume] em soro"
      },
      {
        "code" : "16737-9",
        "display" : "Anticorpo contra o vírus da Dengue 2 [Título] em soro"
      },
      {
        "code" : "7856-8",
        "display" : "Anticorpo contra o vírus da Dengue 2 [Presença] no soro por imunoensaio"
      },
      {
        "code" : "22251-3",
        "display" : "Anticorpo contra o vírus da Dengue 2 [Presença] no soro"
      },
      {
        "code" : "55438-6",
        "display" : "Anticorpo neutralizante contra o vírus da Dengue [Título] em soro por teste de neutralização"
      },
      {
        "code" : "100963-8",
        "display" : "Anticorpo IgG nsP1 contra o vírus da Dengue 1+2+3+4 nsP1 [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "100846-5",
        "display" : "Anticorpo IgG nsP1 contra o vírus da Dengue 1+2+3+4 [Presença] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "95688-8",
        "display" : "Anticorpo IgM contra o vírus da Dengue 1+2+3+4 [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "95673-0",
        "display" : "Anticorpo IgG contra o vírus da Dengue 1+2+3+4 [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "87440-4",
        "display" : "Anticorpo IgA+IgG+IgM vírus da Dengue 1+2+3+4 [Interpretação] em espécime qualitativo por imunoensaio"
      },
      {
        "code" : "87441-2",
        "display" : "Painel IgA+IgG+IgM contra o vírus da Dengue 1+2+3+4 e contra o vírus Zika - Amostra por imunoensaio"
      },
      {
        "code" : "87438-8",
        "display" : "Anticorpo IIgA+IgG+IgM  contra o vírus da Dengue 1+2+3+4 e vírus Zika [Interpretação] em espécime por imunoensaio"
      },
      {
        "code" : "81151-3",
        "display" : "5' UTR RNA vírus da Dengue 1+2+3+4 [Presença] no fluido espinhal cerebral por NAA com detecção por sonda"
      },
      {
        "code" : "81150-5",
        "display" : "5' UTR RNA vírus da Dengue 1+2+3+4 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "94426-4",
        "display" : "3' UTR RNA do vírus da Dengue 1+2+3+4 [Presença] no fluido espinhal cerebral por NAA com detecção por sonda"
      },
      {
        "code" : "94427-2",
        "display" : "3' UTR RNA do vírus da Dengue 1+2+3+4 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "31338-7",
        "display" : "Anticorpo contra o vírus da Dengue 1 [Unidades/volume] em soro"
      },
      {
        "code" : "16736-1",
        "display" : "Anticorpo contra o vírus da Dengue 1 [Título] em soro"
      },
      {
        "code" : "7854-3",
        "display" : "Anticorpo contra o vírus da Dengue 1 [Presença] no soro por imunoensaio"
      },
      {
        "code" : "22250-5",
        "display" : "Anticorpo contra o vírus da Dengue 1 [Presença] no soro"
      },
      {
        "code" : "83067-9",
        "display" : "Anticorpo IgM Proteínas estruturais do vírus Chikungunya (E1+E2) [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "83068-7",
        "display" : "Anticorpo IgG Proteínas estruturais do vírus Chikungunya (E1+E2) [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "82297-3",
        "display" : "Anticorpo IgG Proteínas estruturais do vírus Chikungunya (E1+E2) [Presença] no soro por imunoensaio"
      },
      {
        "code" : "85582-5",
        "display" : "RNA do vírus Chikungunya + RNA do vírus Dengue [Presença] no Plasma do Doador por NAA com detecção por sonda"
      },
      {
        "code" : "85583-3",
        "display" : "RNA do vírus Chikungunya [Presença] no Plasma do Doador por NAA com detecção por sonda"
      },
      {
        "code" : "101303-6",
        "display" : "RNA do vírus Chikungunya [Presença] no Sangue por NAA com detecção sem sonda"
      },
      {
        "code" : "81152-1",
        "display" : "RNA da proteína não estrutural 1 contra o vírus Chikungunya (nsP1) [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "81153-9",
        "display" : "RNA da proteína não estrutural 1 contra o vírus Chikungunya (nsP1) [Presença] no líquido cefalorraquidiano por NAA com detecção por sonda"
      },
      {
        "code" : "95649-0",
        "display" : "Anticorpo neutralizante contra o vírus Chikungunya [Título] em amostra por teste de neutralização"
      },
      {
        "code" : "95687-0",
        "display" : "Anticorpo IgM contra o vírus Chikungunya [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "56131-6",
        "display" : "Anticorpo IgM contra o vírus Chikungunya [Presença] em Soro ou Plasma por Imunofluorescência"
      },
      {
        "code" : "57934-2",
        "display" : "Anticorpo IgM contra o vírus Chikungunya [Presença] no Soro ou Plasma"
      },
      {
        "code" : "104364-5",
        "display" : "Anticorpo IgG contra o vírus Chikungunya [Título] em soro por imunoensaio --1ª amostra"
      },
      {
        "code" : "95672-2",
        "display" : "Anticorpo IgG contra o vírus Chikungunya [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "56129-0",
        "display" : "Anticorpo IgG contra o vírus Chikungunya [Presença] em Soro ou Plasma por Imunofluorescência"
      },
      {
        "code" : "93979-3",
        "display" : "Anticorpo IgG contra o vírus Chikungunya [Presença] no Soro ou Plasma"
      },
      {
        "code" : "95705-0",
        "display" : "Anticorpo IgA contra o vírus Chikungunya [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "43064-5",
        "display" : "Anticorpo contra o vírus Chikungunya [Título] em Soro"
      },
      {
        "code" : "74821-0",
        "display" : "Anticorpo contra o vírus Chikungunya [Presença] no Soro por Inibição da Hemaglutinação"
      },
      {
        "code" : "26623-9",
        "display" : "Anticorpo contra o vírus Chikungunya [Presença] no Soro"
      },
      {
        "code" : "85623-7",
        "display" : "RNA do vírus Zika [Presença] na urina por NAA com detecção por sonda"
      },
      {
        "code" : "79190-5",
        "display" : "RNA do vírus Zika [Presença] em espécime por NAA com detecção por sonda"
      },
      {
        "code" : "91079-4",
        "display" : "RNA do vírus Zika [Presença] na placenta por NAA com detecção por sonda"
      },
      {
        "code" : "85622-9",
        "display" : "RNA do vírus Zika [Presença] no Soro ou Plasma por NAA com detecção por sonda"
      },
      {
        "code" : "90462-3",
        "display" : "RNA do vírus Zika [Presença] no sangue do cordão umbilical por NAA com detecção por sonda"
      },
      {
        "code" : "86594-9",
        "display" : "RNA do vírus Zika [Presença] no líquido cefalorraquidiano por NAA com detecção por sonda"
      },
      {
        "code" : "91078-6",
        "display" : "RNA do vírus Zika [Presença] no sangue por NAA com detecção por sonda"
      },
      {
        "code" : "85621-1",
        "display" : "RNA do vírus Zika [Presença] no líquido amniótico por NAA com detecção por sonda"
      },
      {
        "code" : "80619-0",
        "display" : "Anticorpo IgM contra o vírus Zika [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "80618-2",
        "display" : "Anticorpo IgM contra o vírus Zika [Unidades/volume] no fluido espinhal cerebral por imunoensaio"
      },
      {
        "code" : "89591-2",
        "display" : "Anticorpo IgM contra o vírus Zika [título] no soro por imunofluorescência"
      },
      {
        "code" : "91678-3",
        "display" : "Anticorpo IgM contra o vírus Zika [Presença] em Soro, Plasma ou Sangue por Imunoensaio Rápido"
      },
      {
        "code" : "80824-6",
        "display" : "Anticorpo IgM contra o vírus Zika[Presença] em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "80823-8",
        "display" : "Anticorpo IgM contra o vírus Zika [Presença] no fluido espinhal cerebral por imunoensaio"
      },
      {
        "code" : "97870-0",
        "display" : "Anticorpo IgG contra o vírus Zika [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "89590-4",
        "display" : "Anticorpo IgG contra o vírus Zika [Título] em soro por imunofluorescência"
      },
      {
        "code" : "95663-1",
        "display" : "Anticorpo IgG contra o vírus Zika [Presença] em espécime por imunoensaio"
      },
      {
        "code" : "91080-2",
        "display" : "Anticorpo IgG contra o vírus Zika [Presença] em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "94184-9",
        "display" : "RNA do vírus da Febre Amarela [Presença] em espécime por NAA com detecção por sonda"
      },
      {
        "code" : "97869-2",
        "display" : "Painel de anticorpos contra o vírus Zika - Soro ou Plasma"
      },
      {
        "code" : "90459-9",
        "display" : "RNA do vírus da Febre Amarela [Presença] no sangue por NAA com detecção por sonda"
      },
      {
        "code" : "8057-2",
        "display" : "RNA do vírus da Febre Amarela [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "6593-8",
        "display" : "Anticorpo IgM vírus da Febre Amarela [Unidades/volume] no soro por imunoensaio"
      },
      {
        "code" : "95690-4",
        "display" : "Anticorpo IgM contra o vírus da Febre Amarela [Presença] em amostra por imunoensaio"
      },
      {
        "code" : "77955-3",
        "display" : "Anticorpo IgM vírus da Febre Amarela [Presença] no soro por imunofluorescência"
      },
      {
        "code" : "71782-7",
        "display" : "Anticorpo IgM vírus da Febre Amarela [Presença] no líquido cefalorraquidiano por imunoensaio"
      },
      {
        "code" : "6592-0",
        "display" : "Anticorpo IgG contra o vírus da Febre Amarela [Unidades/volume] no soro por imunoensaio"
      },
      {
        "code" : "95675-5",
        "display" : "Anticorpo IgG contra o vírus da Febre Amarela [Presença] na amostra por imunoensaio"
      },
      {
        "code" : "77954-6",
        "display" : "Anticorpo IgG contra o vírus da Febre Amarela [Presença] no soro por imunofluorescência"
      },
      {
        "code" : "97868-4",
        "display" : "Painel de anticorpos contra o vírus da Febre Amarela - Soro ou Plasma"
      },
      {
        "code" : "41239-5",
        "display" : "Anticorpo contra o vírus da Febre Amarela [Presença] no líquido cefalorraquidiano"
      },
      {
        "code" : "60418-1",
        "display" : "RNA do vírus da Dengue 4 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "60419-9",
        "display" : "RNA do vírus da Dengue 3 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "60420-7",
        "display" : "RNA do vírus da Dengue 2 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "7855-0",
        "display" : "RNA do vírus da Dengue 1+2+3+4 [Presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "88189-6",
        "display" : "RNA do vírus da Dengue 1+2+3+4 [Presença] no sangue por NAA com detecção por sonda"
      },
      {
        "code" : "77958-7",
        "display" : "RNA do vírus da Dengue 1 e 2 e 3 e 4 [identificador] no líquido cefalorraquidiano por NAA com detecção por sonda"
      },
      {
        "code" : "94837-2",
        "display" : "RNA do vírus da Dengue 1+2+3+4 [Presença] no líquido amniótico por NAA com detecção por sonda"
      },
      {
        "code" : "88188-8",
        "display" : "RNA do vírus da Dengue 1+2+3+4 [Presença] na urina por NAA com detecção por sonda"
      },
      {
        "code" : "33578-6",
        "display" : "Anticorpo contra o vírus da Dengue [Título] no soro por imunofluorescência"
      },
      {
        "code" : "60262-3",
        "display" : "RNA do vírus da Dengue 1 [presença] no soro por NAA com detecção por sonda"
      },
      {
        "code" : "41878-0",
        "display" : "Painel IgG e IgM contra o vírus Dengue - Soro por Imunoensaio"
      },
      {
        "code" : "101206-1",
        "display" : "Antígeno  NS1 do vírus da Dengue [unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "75377-2",
        "display" : "Antígeno  NS1 do vírus da Dengue [Presença] em soro, plasma ou sangue por imunoensaio rápido"
      },
      {
        "code" : "34721-1",
        "display" : "Anticorpo IgM contra o vírus da Dengue [Presença] no fluido espinhal cerebral"
      },
      {
        "code" : "91064-6",
        "display" : "Antígeno  NS1 do vírus da Dengue [Presença] em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "23992-1",
        "display" : "Anticorpo IgM contra o vírus da Dengue [unidades/volume] no soro por imunoensaio"
      },
      {
        "code" : "29663-2",
        "display" : "Anticorpo IgM contra o vírus da Dengue [Presença] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "75223-8",
        "display" : "Anticorpo IgG e IgM contra vírus da Dengue [identificador] em soro, plasma ou sangue por imunoensaio rápido"
      },
      {
        "code" : "23991-3",
        "display" : "Anticorpo IgG contra o vírus da Dengue [unidades/volume] no soro por imunoensaio"
      },
      {
        "code" : "100964-6",
        "display" : "Anticorpo IgG contra o vírus da Dengue [presença] em soro, plasma ou sangue por imunoensaio rápido"
      },
      {
        "code" : "29661-6",
        "display" : "Anticorpo IgG contra o vírus da Dengue [Presença] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "86515-4",
        "display" : "RNA do vírus Chikungunya [Presença] na urina por NAA com detecção por sonda"
      },
      {
        "code" : "81154-7",
        "display" : "Painel de vírus da Dengue e chikungunya e zika pela NAA com detecção por sonda"
      },
      {
        "code" : "55369-3",
        "display" : "Anticorpo contra o vírus da Dengue [título] no soro por inibição da hemaglutinação"
      },
      {
        "code" : "51664-1",
        "display" : "RNA do vírus Chikungunya [Presença] em espécime por NAA com detecção por sonda"
      },
      {
        "code" : "60260-7",
        "display" : "RNA do vírus Chikungunya [Presença] no soro ou plasma por NAA com detecção por sonda"
      },
      {
        "code" : "86514-7",
        "display" : "RNA do vírus Chikungunya [Presença] no líquido amniótico por NAA com detecção por sonda"
      },
      {
        "code" : "97867-6",
        "display" : "Anticorpo IgM contra o vírus Chikungunya [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "56130-8",
        "display" : "Anticorpo IgM contra o vírus Chikungunya [Título] em soro ou plasma por imunofluorescência"
      },
      {
        "code" : "56128-2",
        "display" : "Anticorpo IgG contra o vírus Chikungunya [Título] em soro ou plasma por imunofluorescência"
      },
      {
        "code" : "97866-8",
        "display" : "Anticorpo IgG contra o vírus Chikungunya [Unidades/volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "88629-1",
        "display" : "Anticorpo IgM contra o vírus Chikungunya [Presença] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "88630-9",
        "display" : "Anticorpo IgG contra o vírus Chikungunya [Presença] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "93976-9",
        "display" : "Painel Anticorpo IgM e IgG contra o vírus Chikungunya - Soro ou Plasma"
      },
      {
        "code" : "40505-0",
        "display" : "Anticorpo contra o vírus Chikungunya [Título] em Soro por Inibição de Hemaglutinação"
      },
      {
        "code" : "98493-0",
        "display" : "SARS coronavirus 2 região anticorpos ORF1b (Fases de leitura aberta-1b) [Presença] em saliva (fluído oral)  por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "99597-7",
        "display" : "SARS Coronavirus 2  proteína S [Presença] anticorpos IgG em soro ou plasma por Imunoensaio"
      },
      {
        "code" : "94503-0",
        "display" : "SARS Coronavírus 2 painel -  anticorpos em Soro, Plasma ou Sangue por Imunoensaio rápido"
      },
      {
        "code" : "94310-0",
        "display" : "SARS (como) Coronavírus  [Presença de] gene N em Amostra Inespecífica por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96118-5",
        "display" : "SARS Coronavírus 2 painel de anticorpos -  Amostra de sangue seco por Imunoensaio"
      },
      {
        "code" : "95423-0",
        "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 identificado em  Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95972-6",
        "display" : "SARS Coronavírus 2 estimulado por  interferon gama liberação por células T [Unidades/Volumes] corrigido para fundo em sangue"
      },
      {
        "code" : "95608-6",
        "display" : "SARS Coronavírus 2  [Presença de] RNA em amostra respiraória por Amplificação de ácido nucleico com detecção sem sonda"
      },
      {
        "code" : "95125-1",
        "display" : "SARS Coronavírus 2  [Presença de] IgA+IgM em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "95409-9",
        "display" : "SARS Coronavírus 2, [Presença de] gene N em Nariz por  Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94508-9",
        "display" : "SARS Coronavírus 2, [presença de] anticorpos IgM em soro ou plasma por imunoensaio"
      },
      {
        "code" : "94507-1",
        "display" : "SARS Coronavírus 2, [presença de] anticorpos IgG em soro ou plasma por imunoensaio"
      },
      {
        "code" : "96896-6",
        "display" : "SARS coronavirus 2 clade [tipo] em amostra pelo método de genética molecular"
      },
      {
        "code" : "94639-2",
        "display" : "SARS Coronavírus 2 [Presença de] região anticorpos ORF1 em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96755-4",
        "display" : "SARS Coronavirus 2 interpetação de variante em Amostra narrativa"
      },
      {
        "code" : "94565-9",
        "display" : "SARS Coronavírus 2, [presença de] DNA em rinofaringe por NAA por detecção sem sonda"
      },
      {
        "code" : "95942-9",
        "display" : "Vírus da Influenza A e B e SARS Coronavírus + SARS Coronavírus 2 painel de antígeno - Amostra de trato respiratório superior por Imunoensaio rápido"
      },
      {
        "code" : "94745-7",
        "display" : "SARS Coronavírus 2 [Limiar de ciclo de] RNA em Amostra respiratória por Amplificação do ácido nucleico"
      },
      {
        "code" : "94640-0",
        "display" : "SARS Coronavírus 2 [Presença de] gene S em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94647-5",
        "display" : "SARS Coronavírus relacionado [Presença de] RNA em Amosta Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96763-8",
        "display" : "SARS Coronavírus 2 gene E [Presença] em amostra respiratória por Amplificação de ácido nucléico com detecção por sonda"
      },
      {
        "code" : "96752-1",
        "display" : "SARS Coronavírus 2 gene S mutação detectada [Presença de] em amostra por método genética molecular"
      },
      {
        "code" : "94562-6",
        "display" : "SARS Coronavírus 2, [presença de] anticorpos IgA Ab em soro ou plasma por imunoensaio"
      },
      {
        "code" : "94564-2",
        "display" : "SARS Coronavírus 2, [presença de] anticorpos IgM Ab em soro ou plasma por imunoensaio"
      },
      {
        "code" : "96119-3",
        "display" : "SARS Coronavírus 2 antígenos [Presença de] Amostra de trato respiratório superior por Imunoensaio"
      },
      {
        "code" : "94563-4",
        "display" : "SARS Coronavírus 2, [presença de] anticorpos IgG Ab em soro ou plasma por imunoensaio"
      },
      {
        "code" : "96742-2",
        "display" : "SARS Coronavírus 2 anticorpos IgG [Massa/Volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "94558-4",
        "display" : "SARS Coronavírus 2, [presença de] antígenos Ag em amostra respiratória por imunoensaio rápido"
      },
      {
        "code" : "94559-2",
        "display" : "SARS Coronavírus 2, [presença de] gene da regição ORF1ab em amostra respiratória por amplificação do ácido nucléico com detecção por sonda"
      },
      {
        "code" : "94531-1",
        "display" : "SARS Coronavírus 2 painel RNA - em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96741-4",
        "display" : "SARS Coronavírus 2 variante [Tipo] em espécie por sequenciação"
      },
      {
        "code" : "94547-7",
        "display" : "SARS Coronavírus 2, [presença de] anticorpos IgG e IgM em soro ou plasma por imunoensaio"
      },
      {
        "code" : "96603-6",
        "display" : "SARS Coronavírus 2 proteína S domínio de ligação ao RNA anticorpo neutralizante [Presença] em soro ou plasma por imunonensaio"
      },
      {
        "code" : "96123-5",
        "display" : "SARS Coronavírus 2 gene RdRp [Presença de] em Amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96448-6",
        "display" : "SARS Coronavírus 2 gene N [Presença de] em saliva (fluído oral) por amplicação de ácido nucleico usando sonda primer set N1"
      },
      {
        "code" : "94534-5",
        "display" : "SARS Coronavírus 2, [presença de] gene RdRp em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94532-9",
        "display" : "SARS Coronavírus relacionado + MERS Coronavírus, [presença de] RNA em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94533-7",
        "display" : "SARS Coronavírus 2, [presença de] gene N em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96121-9",
        "display" : "SARS Coronavírus relacionado gene E [Presença de] em Amostra de trato respiratório inferior por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94511-3",
        "display" : "SARS Coronavírus 2, [limiar de ciclo da] região ORF1ab em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96122-7",
        "display" : "SARS Coronavírus relacionado gene E [Presença de] em Amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96120-1",
        "display" : "SARS Coronavírus 2 gene RdRp [Presença de] em Amostra de trato respiratório inferior por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96900-6",
        "display" : "SARS coronavirus 2 gene S [Limiar de ciclo#] em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "98131-6",
        "display" : "SARS coronavirus 2 região anticorpos ORF1b (Fases de leitura aberta-1b) [Presença] em amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "98069-8",
        "display" : "SARS coronavirus 2 anticorpos [Presença] em Saliva (fluído oral) por imoensaio rápido"
      },
      {
        "code" : "94767-1",
        "display" : "SARS Coronavírus 2 [Presença de] gene S em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94766-3",
        "display" : "SARS Coronavírus 2 [Presença de] gene N em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94765-5",
        "display" : "SARS Coronavírus relacionado [Presença de] gene E em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94764-8",
        "display" : "SARS Coronavírus 2 [sequência de bases] genôma inteiro em isolado por sequenciamento"
      },
      {
        "code" : "97098-8",
        "display" : "SARS coronavirus 2 gene de proteína não estruturada-2 [Presença] em amostra de Trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "98080-5",
        "display" : "SARS coronavírus 2 e SARS-relacionado coronavírus painel de RNA - Saliva (fluído oral) por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94762-2",
        "display" : "SARS Coronavírus 2 [Presença de] anticorpos em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "98062-3",
        "display" : "Identificador de estudo de sequenciamento"
      },
      {
        "code" : "97104-4",
        "display" : "SARS coronavirus 2 região anticorpos ORF1 (Fases de leitura aberta-1) [Unidades/Volumes] (carga viral) em amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94760-6",
        "display" : "SARS Coronavírus 2 [Presença de] gene N em Nasofaringe por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94761-4",
        "display" : "SARS Coronavírus 2 [Presença de] anticorpos IgG em teste em Amostra de sangue seco por Imunoensaio"
      },
      {
        "code" : "94746-5",
        "display" : "SARS Coronavírus 2 [Limiar de ciclo de] RNA em Amostra Inespecífica por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96986-5",
        "display" : "SARS coronavirus 2 gene N [Presença de] no nariz por Amplificação do ácido nucleico com detecção sem sonda"
      },
      {
        "code" : "94759-8",
        "display" : "SARS Coronavírus 2 [Presença de] RNA em Nasofaringe por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96957-6",
        "display" : "SARS Coronavirus 2 gene M [Presença de] em amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "97099-6",
        "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 painel de antígenos - Amostra de trato respiratório superior por imunoensaio rápido"
      },
      {
        "code" : "97097-0",
        "display" : "SARS coronavirus 2 [Presença] antígenos em amostra de Trato respiratório superior por imunoensaio rápido"
      },
      {
        "code" : "96958-4",
        "display" : "SARS Coronavirus 2 gene N [Presença] em saliva (fluído oral) por Amplicação de ácido nucleico usando sonda primer CDC set N2"
      },
      {
        "code" : "94763-0",
        "display" : "SARS Coronavírus 2 [Presença de] em Amostra não específica por cultura em organismo específico"
      },
      {
        "code" : "94757-2",
        "display" : "SARS Coronavírus 2 [Presença de] gene N em Amostra respiratória por Amplificação do ácido nucleico usando sonda primer set N2"
      },
      {
        "code" : "94758-0",
        "display" : "SARS Coronavírus relacionado [Presença de] gene E em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94756-4",
        "display" : "SARS Coronavírus 2 [Presença de] gene N em Amostra respiratória por Amplificação do ácido nucleido usando sonda primer set N1"
      },
      {
        "code" : "94768-9",
        "display" : "SARS Coronavírus 2 [Presença de] anticorpos IgA em Soro Plasma ou Sangue por Imunoensaio rápido"
      },
      {
        "code" : "94769-7",
        "display" : "SARS Coronavírus 2 [dosagem de] anticorpos em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "98132-4",
        "display" : "SARS coronavirus 2 região anticorpos ORF1a (Fases de leitura aberta-1b) [Presença] em amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "99314-7",
        "display" : "SARS Coronavirus 2 gene RdRp mutação detectada [Identificador] em amostra pelo método de genética molecular"
      },
      {
        "code" : "98734-7",
        "display" : "SARS Coronavirus 2 proteína S Domínio de Ligação ao RNA anticorpo neutralizante [Unidades/Volume] em soro ou plasma por imunonensaio"
      },
      {
        "code" : "95380-2",
        "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 e SARS Coronavírus relacionado painel de RNA por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "98847-7",
        "display" : "SARS Coronavirus 2 interferon gama estimulado liberação por linfócitos [Unidades/volume] corrigido para sangue de fundo por imunoensaio"
      },
      {
        "code" : "94822-4",
        "display" : "SARS Coronavírus 2 [Presença de] RNA em Saliva (fluido oral) por sequenciamento"
      },
      {
        "code" : "94845-5",
        "display" : "SARS Coronavírus 2 [Presença de] RNA em Saliva (fluido oral) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "98494-8",
        "display" : "SARS coronavirus 2 região anticorpos ORF1a (Fases de leitura aberta-1a) [Presença] em saliva (fluído oral) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95209-3",
        "display" : "SARS Coronavírus + SARS Coronavírus 2 [Presença de] antígeno em Amostra respiratória por Imunoensaio rápido"
      },
      {
        "code" : "98733-9",
        "display" : "Percentual de neutralização por SARS coronavirus 2 proteína spike Domínio de Ligação ao RNA anticorpo neutralizante em soro ou plasma por imunonensaio"
      },
      {
        "code" : "99596-9",
        "display" : "SARS Coronavirus 2 proteína N [Presença] anticorpos IgG em soro ou plasma por Imunoensaio"
      },
      {
        "code" : "95406-5",
        "display" : "SARS Coronavírus 2, [Presença de] RNA no Nariz por Amplificação de ácido nucléico com detecção por sonda"
      },
      {
        "code" : "98732-1",
        "display" : "SARS Coronavirus 2 proteína S Domínio de Ligação ao RNA anticorpo neutralizante [Fator de diluição] em soro ou plasma por imunonensaio"
      },
      {
        "code" : "98846-9",
        "display" : "SARS Coronavirus 2 interferon gama estimulado liberação por células T auxiliares (CD4+) [Unidades/volume] corrigido para sangue de fundo por imunoensaio"
      },
      {
        "code" : "94819-0",
        "display" : "SARS Coronavírus 2 [dosagem de] (carga viral) RNA em Amostra Inespecífica por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "99771-8",
        "display" : "SARS Coronavirus 2 proteína spike e proteína de nucleocapsídeo painel de interferon gama estimulado - Sangue"
      },
      {
        "code" : "99772-6",
        "display" : "SARS Coronavirus 2 interferon gama estimulado [Interpretação] em Sangue Qualitativo"
      },
      {
        "code" : "99773-4",
        "display" : "SARS Coronavirus 2 interferon gama estimulado liberado por células T. Antígeno spike área de contagem [#] corrigido para fundo em Sangue"
      },
      {
        "code" : "99774-2",
        "display" : "SARS Coronavirus 2 interferon gama estimulado liberado por células T. Antígeno nucleocapsídeo área de contagem [#] corrigido para fundo em Sangue"
      },
      {
        "code" : "96899-0",
        "display" : "SARS coronavirus 2 [Limiar de ciclo#] região anticorpos ORF1 (Fases de leitura aberta-1) em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94720-0",
        "display" : "SARS Coronavírus 2 [dosagem de] anticorpos IgA em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "96898-2",
        "display" : "SARS coronavirus 2 gene N [Limiar de ciclo#] em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94661-6",
        "display" : "SARS Coronavírus 2 [Interpretação de] anticorpos em Soro ou Plasma"
      },
      {
        "code" : "96897-4",
        "display" : "SARS coronavirus 2 painel de RNA - lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94660-8",
        "display" : "SARS Coronavírus 2 [Presença de] em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96895-8",
        "display" : "SARS coronavirus 2 linhagem [tipo] em amostra pelo método de genética molecular"
      },
      {
        "code" : "94646-7",
        "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene RdRp em Amostra respiratória por Amplificação do ácido nucleico"
      },
      {
        "code" : "96894-1",
        "display" : "SARS coronavirus 2 painel de sequenciamento e identificação - Amostra pelo método de genética molecular"
      },
      {
        "code" : "94645-9",
        "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene RdRp em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96829-7",
        "display" : "SARS coronavirus 2 RNA [Presença de] em Amostra de doador por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94644-2",
        "display" : "SARS Coronavírus 2 [Limiar de ciclo de] região anticorpos ORF1 em Amostra respiratória por Amplificação do ácido nucleico"
      },
      {
        "code" : "96797-6",
        "display" : "SARS coronavirus 2 RNA [Presença] em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94643-4",
        "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene S em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96766-1",
        "display" : "Sequencia GISAID número de registro"
      },
      {
        "code" : "94642-6",
        "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene S em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96765-3",
        "display" : "SARS Coronavírus 2 gene S [Presença] em saliva (fluído oral) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94641-8",
        "display" : "SARS Coronavírus 2 [Presença de] gene S em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96764-6",
        "display" : "SARS Coronavírus 2 gene E [Limiar de ciclo #] em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96751-3",
        "display" : "SARS Coronavírus 2 gene S mutação detectada [Identificador] em specime por método genética molecular"
      },
      {
        "code" : "94510-5",
        "display" : "SARS Coronavírus 2, [limiar de ciclo de] gene 2 N em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94509-7",
        "display" : "SARS Coronavírus 2, [limiar de ciclo de] gene E em amostra não especificada por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96094-8",
        "display" : "SARS Coronavírus 2 e SARS Coronavírus relacionado painel de RNA - Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "96091-4",
        "display" : "SARS Coronavírus 2 gene RdRp [Presença de] em saliva (fluído oral) por Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95974-2",
        "display" : "SARS Coronavírus 2 estimulado por interferon gama painel - Sangue"
      },
      {
        "code" : "94506-3",
        "display" : "SARS Coronavírus 2, [dosagem de] anticorpos IgM [Unidades/Volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "95973-4",
        "display" : "SARS Coronavírus 2 estimulado por interferon gama liberação por células T (Unidades/Volume] em sangue"
      },
      {
        "code" : "94505-5",
        "display" : "SARS Coronavírus 2, [dosagem de] anticorpos IgG [Unidades/Volume] em soro ou plasma por imunoensaio"
      },
      {
        "code" : "94504-8",
        "display" : "SARS Coronavírus 2 painel - anticorpos, Soro ou Plasma por Imunoensaio rápido"
      },
      {
        "code" : "95971-8",
        "display" : "SARS Coronavírus 2 estimulado por interferon gama [Presença de] em sangue"
      },
      {
        "code" : "95970-0",
        "display" : "SARS Coronavírus 2 rearranjos específicos de genes de células T de receptor beta [Presença de] em sangue por sequenciamento"
      },
      {
        "code" : "94502-2",
        "display" : "SARS Coronavírus relacionado, [presença de] RNA em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94500-6",
        "display" : "SARS Coronavírus 2, [presença de] RNA em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95941-1",
        "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 e Vírus sinciciais respiratórios painel de RNA - Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94316-7",
        "display" : "SARS Coronavírus 2, [presença de] gene N em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95826-4",
        "display" : "SARS Coronavírus 2 painel de RNA - Saliva (fluido oral) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94315-9",
        "display" : "SARS Coronavírus 2, [presença de] gene E em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95825-6",
        "display" : "SARS Coronavírus 2 [Presença de] anticorpos em Amostra de Sangue seco por Imunoensaio"
      },
      {
        "code" : "94314-2",
        "display" : "SARS Coronavírus 2, [presença de] gene RdRp em amostra não especificada por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95824-9",
        "display" : "SARS Coronavírus 2 [Presença de] região anticorpos ORF1 em Saliva (fluido oral) por Amplificação de ácido nucléico com detecção por sonda"
      },
      {
        "code" : "94313-4",
        "display" : "SARS (como) Coronavírus [Limiar de ciclo de] gene N em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95823-1",
        "display" : "SARS Coronavírus relacionado [Presença de] gene E em Saliva (fluido oral) por Amplificação de àcido nucleico com detecção por sonda"
      },
      {
        "code" : "94312-6",
        "display" : "SARS Coronavírus 2, [limiar de ciclo] de gene N em amostra não especificada por amplificação de ácido nucleico usando conjunto de sonda / primer N2"
      },
      {
        "code" : "95609-4",
        "display" : "SARS Coronavírus 2 [Presença de] gene S em amostra respiratória por sequenciação"
      },
      {
        "code" : "94311-8",
        "display" : "SARS Coronavírus 2, [limiar de ciclo] de gene N em amostra não especificada por amplificação de ácido nucleico usando conjunto de sonda / primer N1"
      },
      {
        "code" : "95542-7",
        "display" : "SARS Coronavírus 2 anticorposs IgG+IgM [Presença de] em Soro Plasma ou Sangue por Imunoensaio rápido"
      },
      {
        "code" : "94309-2",
        "display" : "SARS Coronavírus 2, [presença de] RNA em amostra não especificada, por amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95522-9",
        "display" : "SARS Coronavírus 2 [dosagem de] (carga viral ) gene N em Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94308-4",
        "display" : "SARS Coronavírus 2, [presença de] gene N em amostra não especificada, por amplificação de ácido nucleico usando conjunto de sonda / primer N2"
      },
      {
        "code" : "95521-1",
        "display" : "SARS Coronavírus 2 [#/volume] (carga viral) gene N em Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "94307-6",
        "display" : "SARS Coronavírus, [presença de] gene 2 N em amostra não especificada por amplificação de ácido nucleico usando conjunto de sonda / primer N1"
      },
      {
        "code" : "95429-7",
        "display" : "SARS Coronavírus 2 [Concentração de] anticorpos IgG em Soro ou Plasma por imunofluorescência"
      },
      {
        "code" : "94306-8",
        "display" : "SARS Coronavírus 2 Painel de RNA - Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "95428-9",
        "display" : "SARS Coronavírus 2 [Concentração de] anticorpos IgM em Soro ou Plasma por imunofluorescência"
      },
      {
        "code" : "41853-3",
        "display" : "Orthopoxvirus DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
      },
      {
        "code" : "95427-1",
        "display" : "SARS Coronavírus 2 [Concentração de] anticorpos IgA em Soro ou Plasma por imunofluorescência"
      },
      {
        "code" : "100893-7",
        "display" : "Orthopoxvirus IgG e IgM Ab panel - Soro ou Plasma"
      },
      {
        "code" : "95425-5",
        "display" : "SARS Coronavírus 2 [Presença de] gene N em Saliva (fluido oral) por Amplificação de ácido nucleico com detecção por sonda"
      },
      {
        "code" : "100892-9",
        "display" : "Orthopoxvirus IgM Ab [Presença] em soro ou plasma por Imunoensaio"
      },
      {
        "code" : "95424-8",
        "display" : "SARS Coronavírus 2 [Presença de] RNA em Amostra respiratória por sequenciamento"
      },
      {
        "code" : "100891-1",
        "display" : "Orthopoxvirus IgG Ab [Presença] em Soro ou Plasma por Imunoensaio"
      },
      {
        "code" : "100889-5",
        "display" : "Vírus Monkeypox da Bacia do Congo DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
      },
      {
        "code" : "95422-2",
        "display" : "Vírus da Influenza A e B RNA e SARS Coronavírus 2 painel de gene N - Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
      },
      {
        "code" : "100888-7",
        "display" : "Vírus Monkeypox da Africa Ocidental DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
      },
      {
        "code" : "95416-4",
        "display" : "SARS Coronavírus 2, [Presença de] anticorpos IgM teste em Amostra de Sangue seco por Imunoensaio"
      },
      {
        "code" : "100887-9",
        "display" : "Vírus da pseudovaríola DNA [Presença] em Amostra por Amplficação de Ácido Nucleio com detecção por sonda"
      },
      {
        "code" : "95411-5",
        "display" : "SARS Coronavírus 2, [Presença de] neutralização de anticorpos em Soro por teste de neutralização de pseudovírus"
      },
      {
        "code" : "100886-1",
        "display" : "Vírus Orf DNA [Presença de] em Amostra por Amplificação de Ácido Nucleio com detecção por sonda"
      },
      {
        "code" : "95410-7",
        "display" : "SARS Coronavírus 2, [Concentração de] neutralização de anticorpos em Soro por teste de neutralização de pseudovírus"
      },
      {
        "code" : "100885-3",
        "display" : "Parapoxvirus DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
      },
      {
        "code" : "100434-0",
        "display" : "Orthopoxvirus não-varíola DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
      },
      {
        "code" : "100383-9",
        "display" : "Vírus Monkeypox DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
      }]
    }]
  }
}

```

# BR.GOV.SAUDE.TERMINOLOGIA.FHIR\BRDispositivo_Medico - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **BRDispositivo_Medico**

## ValueSet: BRDispositivo_Medico 

| | |
| :--- | :--- |
| *URL Canônica*:https://terminologia.saude.gov.br/fhir/ValueSet/BRDispositivo-Medico | *Versão*:1.1.0 |
| Active as of 2026-09-01 | *Nome computável*:BRDispositivo_Medico |

 **References** 

Este conjunto de valores não é utilizado aqui; pode ser utilizado noutro local (por exemplo, especificações e/ou implementações que utilizem este conteúdo)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRDispositivo-Medico",
  "url" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRDispositivo-Medico",
  "version" : "1.1.0",
  "name" : "BRDispositivo_Medico",
  "title" : "BRDispositivo_Medico",
  "status" : "active",
  "date" : "2026-09-01T09:42:43-04:00",
  "publisher" : "Ministério do Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério do Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "https://gov.br/saude"
    },
    {
      "system" : "email",
      "value" : "contato@gointerop.com"
    }]
  },
  {
    "name" : "Italo Macedo",
    "telecom" : [{
      "system" : "email",
      "value" : "italo@gointerop.com",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRTabelaSUS",
      "concept" : [{
        "code" : "0211020010",
        "display" : "CATETERISMO CARDIACO"
      },
      {
        "code" : "0211020060",
        "display" : "TESTE DE ESFORÇO / TESTE ERGOMETRICO"
      },
      {
        "code" : "0211070378",
        "display" : "AVALIAÇÃO E SELEÇÃO PRÉ-CIRÚRGICA PARA IMPLANTE COCLEAR"
      },
      {
        "code" : "0301040141",
        "display" : "INSERÇÃO DE DISPOSITIVO INTRA-UTERINO (DIU)"
      },
      {
        "code" : "0301040176",
        "display" : "INSERÇÃO DO IMPLANTE SUBDÉRMICO LIBERADOR DE ETONOGESTREL"
      },
      {
        "code" : "0301040222",
        "display" : "INSERÇÃO DO SISTEMA INTRAUTERINO LIBERADOR DELEVONORGESTREL 52MG"
      },
      {
        "code" : "0303060158",
        "display" : "TRATAMENTO DE ENDOCARDITE INFECCIOSA EM PROTESE VALVAR"
      },
      {
        "code" : "0303090235",
        "display" : "TRATAMENTO CONSERVADOR DE LESAO DA COLUNA TORACO-LOMBO-SACRA C/ ORTESE"
      },
      {
        "code" : "0403010349",
        "display" : "TREPANACAO CRANIANA PARA PROPEDEUTICA NEUROCIRURGICA / IMPLANTE PARA MONITORIZACAO PIC"
      },
      {
        "code" : "0403080010",
        "display" : "IMPLANTE DE ELETRODO PARA ESTIMULAÇÃO CEREBRAL"
      },
      {
        "code" : "0403080029",
        "display" : "IMPLANTE DE GERADOR DE PULSOS P/ARA ESTIMULAÇÃO CEREBRAL (INCLUI CONECTOR)"
      },
      {
        "code" : "0403080037",
        "display" : "IMPLANTE INTRAVENTRICULAR DE BOMBA DE INFUSÃO DE FARMACOS"
      },
      {
        "code" : "0404010148",
        "display" : "IMPLANTE COCLEAR"
      },
      {
        "code" : "0404010571",
        "display" : "CIRURGIA DE IMPLANTE COCLEAR UNILATERAL"
      },
      {
        "code" : "0404010580",
        "display" : "CIRURGIA DE IMPLANTE COCLEAR BILATERAL"
      },
      {
        "code" : "0404020569",
        "display" : "ARTROPLASTIA DA ARTICULAÇÃO TÊMPORO-MANDIBULAR (RECIDIVANTE OU NÃO)"
      },
      {
        "code" : "0404030068",
        "display" : "OSTEOPLASTIA DO MENTO COM OU SEM IMPLANTE ALOPLÁSTICO"
      },
      {
        "code" : "0404030220",
        "display" : "IMPLANTE OSTEOINTEGRADO EXTRA-ORAL BUCO-MAXILO-FACIAL"
      },
      {
        "code" : "0405050100",
        "display" : "FACECTOMIA S/ IMPLANTE DE LENTE INTRA-OCULAR"
      },
      {
        "code" : "0405050119",
        "display" : "FACOEMULSIFICAÇÃOO C/ IMPLANTE DE LENTE INTRA-OCULAR RÍGIDA"
      },
      {
        "code" : "0405050135",
        "display" : "IMPLANTE DE PROTESE ANTI-GLAUCOMATOSA"
      },
      {
        "code" : "0405050143",
        "display" : "IMPLANTE INTRA-ESTROMAL"
      },
      {
        "code" : "0405050151",
        "display" : "IMPLANTE SECUNDARIO DE LENTE INTRA-OCULAR - LIO"
      },
      {
        "code" : "0405050372",
        "display" : "FACOEMULSIFICAÇÃO C/ IMPLANTE DE LENTE INTRA-OCULAR DOBRÁVEL"
      },
      {
        "code" : "0406010552",
        "display" : "IMPLANTE C/ TROCA DE POSIÇÃO DE VALVAS (CIRURGIA DE ROSS)"
      },
      {
        "code" : "0406010579",
        "display" : "IMPLANTE DE CARDIOVERSOR DESFIBRILADOR (CDI) MULTI-SITIO TRANSVENOSO EPIMIOCÁRDICO POR TORACOTOMIA P"
      },
      {
        "code" : "0406010587",
        "display" : "IMPLANTE DE CARDIOVERSOR DESFIBRILADOR DE CÃMARA DUPLA TRANSVENOSO"
      },
      {
        "code" : "0406010595",
        "display" : "IMPLANTE DE CARDIOVERSOR DESFIBRILADOR MULTI-SÍTIO ENDOCAVITÁRIO C/ REVERSÃO PARA EPIMIOCÁRDICO POR "
      },
      {
        "code" : "0406010609",
        "display" : "IMPLANTE DE CARDIOVERSOR DESFIBRILADOR (CDI) MULTI-SITIO TRANSVENOSO"
      },
      {
        "code" : "0406010617",
        "display" : "IMPLANTE DE MARCAPASSO CARDÍACO MULTI-SITIO ENDOCAVITÁRIO C/ REVERSÃO P/ EPIMIOCÁRDICO (POR TORACOTO"
      },
      {
        "code" : "0406010625",
        "display" : "IMPLANTE DE MARCAPASSO CARDÍACO MULTI-SITIO EPIMIOCÁRDICO POR TORACOTOMIA P/IMPLANTE DE ELETRODO"
      },
      {
        "code" : "0406010633",
        "display" : "IMPLANTE DE MARCAPASSO CARDÍACO MULTI-SITIO TRANSVENOSO"
      },
      {
        "code" : "0406010641",
        "display" : "IMPLANTE DE MARCAPASSO DE CÂMARA DUPLA EPIMIOCÁRDICO"
      },
      {
        "code" : "0406010650",
        "display" : "IMPLANTE DE MARCAPASSO DE CÂMARA DUPLA TRANSVENOSO"
      },
      {
        "code" : "0406010668",
        "display" : "IMPLANTE DE MARCAPASSO DE CÂMARA ÚNICA EPIMIOCÁRDICO"
      },
      {
        "code" : "0406010676",
        "display" : "IMPLANTE DE MARCAPASSO DE CÂMARA ÚNICA TRANSVENOSO"
      },
      {
        "code" : "0406010684",
        "display" : "IMPLANTE DE MARCAPASSO TEMPORÁRIO TRANSVENOSO"
      },
      {
        "code" : "0406010692",
        "display" : "IMPLANTE DE PRÓTESE VALVAR"
      },
      {
        "code" : "0406011478",
        "display" : "IMPLANTE C/ TROCA DE POSICAO DE VALVAS (CIRURGIA DE ROSS) (CRIANÇA E ADOLESCENTE)"
      },
      {
        "code" : "0406011524",
        "display" : "IMPLANTE TRANSCATETER DE VÁLVULA AÓRTICA (ITVA)"
      },
      {
        "code" : "0406030022",
        "display" : "ANGIOPLASTIA CORONARIANA C/ IMPLANTE DE DOIS STENTS"
      },
      {
        "code" : "0406030030",
        "display" : "ANGIOPLASTIA CORONARIANA C/ IMPLANTE DE STENT"
      },
      {
        "code" : "0406030057",
        "display" : "ANGIOPLASTIA COM IMPLANTE DE DUPLO STENT EM AORTA/ARTÉRIA PULMONAR E RAMOS"
      },
      {
        "code" : "0406030073",
        "display" : "ANGIOPLASTIA EM ENXERTO CORONARIANO (C/ IMPLANTE DE STENT)"
      },
      {
        "code" : "0406040028",
        "display" : "ANGIOPLASTIA INTRALUMINAL DE AORTA, VEIA CAVA / VASOS ILÍACOS (C/ STENT)"
      },
      {
        "code" : "0406040060",
        "display" : "ANGIOPLASTIA INTRALUMINAL DE VASOS DAS EXTREMIDADES (C/ STENT NÃO RECOBERTO)"
      },
      {
        "code" : "0406040095",
        "display" : "ANGIOPLASTIA INTRALUMINAL DE VASOS DO PESCOÇO OU TRONCOS SUPRA-AÓRTICOS (C/ STENT NÃO RECOBERTO)"
      },
      {
        "code" : "0406040109",
        "display" : "ANGIOPLASTIA INTRALUMINAL DE VASOS VISCERAIS C/ STENT NÃO RECOBERTO"
      },
      {
        "code" : "0406040117",
        "display" : "ANGIOPLASTIA INTRALUMINAL DE VASOS VISCERAIS C/ STENT RECOBERTO"
      },
      {
        "code" : "0406040133",
        "display" : "ANGIOPLASTIA INTRALUMINAL DOS VASOS DO PESCOÇO / TRONCOS SUPRA-AÓRTICOS (C/ STENT RECOBERTO)"
      },
      {
        "code" : "0406040265",
        "display" : "IMPLANTAÇÃO DE SHUNT INTRA-HEPÁTICO PORTO-SISTÊMICO (TIPS) C/ STENT NÃO RECOBERTO"
      },
      {
        "code" : "0406040281",
        "display" : "RECONSTRUÇÃO DA BIFURCAÇÃO AORTO-ILÍACA C/ ANGIOPLASTIA E STENTS"
      },
      {
        "code" : "0407030085",
        "display" : "COLOCAÇÃO DE PRÓTESE BILIAR"
      },
      {
        "code" : "0408010037",
        "display" : "ARTROPLASTIA ESCAPULO-UMERAL (NÃO CONVENCIONAL)"
      },
      {
        "code" : "0408020040",
        "display" : "ARTROPLASTIA DE ARTICULAÇÃO DA MÃO"
      },
      {
        "code" : "0408020059",
        "display" : "ARTROPLASTIA DE CABEÇA DO RÁDIO"
      },
      {
        "code" : "0408020075",
        "display" : "ARTROPLASTIA TOTAL DE COTOVELO"
      },
      {
        "code" : "0408040084",
        "display" : "ARTROPLASTIA TOTAL PRIMÁRIA DO QUADRIL CIMENTADA"
      },
      {
        "code" : "0408040092",
        "display" : "ARTROPLASTIA TOTAL PRIMARIA DO QUADRIL NÃO CIMENTADA / HÍBRIDA"
      },
      {
        "code" : "0408040130",
        "display" : "EPIFISIODESE FEMORAL PROXIMAL IN SITU"
      },
      {
        "code" : "0408050047",
        "display" : "ARTROPLASTIA DE JOELHO (NAO CONVENCIONAL)"
      },
      {
        "code" : "0408050055",
        "display" : "ARTROPLASTIA TOTAL DE JOELHO - REVISÃO / RECONSTRUÇÃO"
      },
      {
        "code" : "0408050071",
        "display" : "ARTROPLASTIA UNICOMPARTIMENTAL PRIMARIA DO JOELHO"
      },
      {
        "code" : "0409010162",
        "display" : "IMPLANTE DE CATETER URETERAL POR TÉCNICA CISTOSCOPICA"
      },
      {
        "code" : "0410010090",
        "display" : "PLASTICA MAMARIA RECONSTRUTIVA - POS MASTECTOMIA C/ IMPLANTE DE PROTESE"
      },
      {
        "code" : "0412010038",
        "display" : "COLOCAÇÃO DE PROTESE LARINGO-TRAQUEAL, TRAQUEAL, TRAQUEO-BRÔNQUICA, BRÔNQUICA POR VIA ENDOSCÓPICA (I"
      },
      {
        "code" : "0412010127",
        "display" : "TRAQUEOSTOMIA COM COLOCAÇÃO DE ORTESE TRAQUEAL OU TRAQUEOBRONQUICA"
      },
      {
        "code" : "0414020421",
        "display" : "IMPLANTE DENTÁRIO OSTEOINTEGRADO"
      },
      {
        "code" : "0418010048",
        "display" : "IMPLANTE DE CATETER DE LONGA PERMANÊNCIA P/ HEMODIÁLISE"
      },
      {
        "code" : "0418010064",
        "display" : "IMPLANTE DE CATETER DUPLO LUMEN P/HEMODIALISE"
      },
      {
        "code" : "0418010072",
        "display" : "IMPLANTE DE CATETER TENCKHOFF OU SIMILAR DE LONGA PERMANÊNCIA NA IRA (INCLUI CATETER)"
      },
      {
        "code" : "0418010080",
        "display" : "IMPLANTE DE CATETER TIPO TENCKHOFF OU SIMILAR P/ DPA/DPAC"
      },
      {
        "code" : "0701020342",
        "display" : "PRÓTESE CANADENSE EXOESQUELETICA.(DESARTICULAÇÃO DO QUADRIL)"
      },
      {
        "code" : "0701020490",
        "display" : "PROTESE FUNCIONAL EXOESQUELÉTICA TRANSRADIAL PARA PUNHO DE TROCA RÁPIDA COM GANCHO DE DUPLA FORÇA"
      },
      {
        "code" : "0701040068",
        "display" : "PRÓTESE OCULAR"
      },
      {
        "code" : "0701070099",
        "display" : "PROTESE PARCIAL MANDIBULAR REMOVIVEL"
      },
      {
        "code" : "0701070102",
        "display" : "PROTESE PARCIAL MAXILAR REMOVIVEL"
      },
      {
        "code" : "0701070137",
        "display" : "PROTESE TOTAL MAXILAR"
      },
      {
        "code" : "0702010030",
        "display" : "CATETER ATRIAL / PERITONEAL"
      },
      {
        "code" : "0702010049",
        "display" : "CATETER GUIA CALIBRE 6F A 8F"
      },
      {
        "code" : "0702010065",
        "display" : "CATETER VENTRICULAR ISOLADO"
      },
      {
        "code" : "0702030074",
        "display" : "CENTRALIZADOR PARA COMPONENTE FEMORAL CIMENTADO MODULAR"
      },
      {
        "code" : "0702030163",
        "display" : "COMPONENTE FEMORAL CIMENTADO MODULAR PRIMARIO"
      },
      {
        "code" : "0702030171",
        "display" : "COMPONENTE FEMORAL CIMENTADO MONOBLOCO TIPO CHARNLEY"
      },
      {
        "code" : "0702030210",
        "display" : "COMPONENTE FEMORAL NAO CIMENTADO MODULAR PRIMARIO"
      },
      {
        "code" : "0702030228",
        "display" : "COMPONENTE FEMORAL PRIMARIO CIMENTADO / FIXACAO BIOLOGICA"
      },
      {
        "code" : "0702030465",
        "display" : "HASTE DE ENDER"
      },
      {
        "code" : "0702030627",
        "display" : "PARAFUSO CANULADO 3,5 MM"
      },
      {
        "code" : "0702030635",
        "display" : "PARAFUSO CANULADO 4,5 MM"
      },
      {
        "code" : "0702030643",
        "display" : "PARAFUSO CANULADO 7,0 MM"
      },
      {
        "code" : "0702030660",
        "display" : "PARAFUSO CORTICAL 1,5 MM"
      },
      {
        "code" : "0702030678",
        "display" : "PARAFUSO CORTICAL 2,0 MM"
      },
      {
        "code" : "0702030686",
        "display" : "PARAFUSO CORTICAL 2,7 MM"
      },
      {
        "code" : "0702030694",
        "display" : "PARAFUSO CORTICAL 3,5 MM"
      },
      {
        "code" : "0702030708",
        "display" : "PARAFUSO CORTICAL 4,5 MM"
      },
      {
        "code" : "0702030724",
        "display" : "PARAFUSO ESPONJOSO 4,0 MM"
      },
      {
        "code" : "0702030740",
        "display" : "PARAFUSO MALEOLAR"
      },
      {
        "code" : "0702030791",
        "display" : "PINO DE KNOWLES"
      },
      {
        "code" : "0702030805",
        "display" : "PINO DE SHANTZ"
      },
      {
        "code" : "0702030848",
        "display" : "PLACA 1/3 TUBULAR 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030856",
        "display" : "PLACA ANGULADA 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030872",
        "display" : "PLACA COBRA 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030880",
        "display" : "PLACA CONDILEA 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030899",
        "display" : "PLACA DE COMPRESSAO DINAMICA 3,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030902",
        "display" : "PLACA DE COMPRESSAO DINAMICA 4,5 MM ESTREITA (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030910",
        "display" : "PLACA DE COMPRESSAO DINAMICA 4,5 MM LARGA (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030929",
        "display" : "PLACA DE RECONSTRUÇÃO 3,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030937",
        "display" : "PLACA DE RECONSTRUÇÃO DE 4,5 MM (INCLUÍ PARAFUSOS)"
      },
      {
        "code" : "0702030945",
        "display" : "PLACA DE SUPORTE DE PLATEAU TIBIAL 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030961",
        "display" : "PLACA EM L 3,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030970",
        "display" : "PLACA EM L 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702030988",
        "display" : "PLACA EM T 2,7MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702031003",
        "display" : "PLACA EM T 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702031020",
        "display" : "PLACA EM TREVO 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702031038",
        "display" : "PLACA OCCIPITO-CERVICAL"
      },
      {
        "code" : "0702031062",
        "display" : "PLACA PONTE 4,5 MM (INCLUI PARAFUSO)"
      },
      {
        "code" : "0702031070",
        "display" : "PLACA SEMITUBULAR 2,7 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702031089",
        "display" : "PLACA SEMITUBULAR 3,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702031097",
        "display" : "PLACA SEMITUBULAR 4,5 MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702031100",
        "display" : "PLACAS TÓRACO-LOMBO-SACRAL ASSOCIADA A PARAFUSOS INTRA-SOMÁTICOS DE TITÂNIO"
      },
      {
        "code" : "0702031127",
        "display" : "PROTESE DE CABECA DE RADIO"
      },
      {
        "code" : "0702031135",
        "display" : "PROTESE INTERFALANGEANA"
      },
      {
        "code" : "0702031143",
        "display" : "PROTESE METACARPO-FALANGEANA"
      },
      {
        "code" : "0702031151",
        "display" : "PROTESE NAO CONVENCIONAL ARTICULADA DISTAL DE MEMBRO INFERIOR"
      },
      {
        "code" : "0702031160",
        "display" : "PROTESE NAO CONVENCIONAL ARTICULADA DISTAL DE MEMBRO SUPERIOR"
      },
      {
        "code" : "0702031178",
        "display" : "PROTESE NAO CONVENCIONAL ARTICULADA PROXIMAL DE MEMBRO INFERIOR"
      },
      {
        "code" : "0702031186",
        "display" : "PROTESE NAO CONVENCIONAL ARTICULADA PROXIMAL DE MEMBRO SUPERIOR"
      },
      {
        "code" : "0702031208",
        "display" : "PROTESE NAO CONVENCIONAL DIAFISARIA"
      },
      {
        "code" : "0702031216",
        "display" : "PROTESE NAO CONVENCIONAL EXTENSIVEL"
      },
      {
        "code" : "0702031224",
        "display" : "PROTESE PARCIAL DE QUADRIL CIMENTADA MONOBLOCO (TIPO THOMPSON)"
      },
      {
        "code" : "0702031232",
        "display" : "PROTESE TENDINOSA DE SILICONE"
      },
      {
        "code" : "0702031259",
        "display" : "RESTRITOR DE CIMENTO FEMORAL/UMERAL"
      },
      {
        "code" : "0702031305",
        "display" : "PLACA 1/3 TUBULAR 2,7MM (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702031321",
        "display" : "PARAFUSO BLOQUEADO"
      },
      {
        "code" : "0702031364",
        "display" : "MINI PLACA EM T OU L (INCLUI PARAFUSO)"
      },
      {
        "code" : "0702031399",
        "display" : "PLACA BLOQUEADA DE RÁDIO DISTAL (INCLUI PARAFUSO)"
      },
      {
        "code" : "0702040142",
        "display" : "CATETER MULTIPOLAR TERAPÊUTICO (QUADRI, DECA, DUODECAPOLAR, ETC)"
      },
      {
        "code" : "0702040410",
        "display" : "MARCAPASSO CARDIACO MULTIPROGRAMAVEL DE CAMARA DUPLA"
      },
      {
        "code" : "0702040428",
        "display" : "MARCAPASSO CARDIACO MULTIPROGRAMAVEL DE CAMARA UNICA"
      },
      {
        "code" : "0702040517",
        "display" : "STENT PARA ARTÉRIA PERIFÉRICA"
      },
      {
        "code" : "0702040541",
        "display" : "PROTESE VALVULAR BIOLÓGICA"
      },
      {
        "code" : "0702040568",
        "display" : "PROTESE VALVULAR MECÂNICA DE BAIXO PERFIL (DISCO)"
      },
      {
        "code" : "0702040614",
        "display" : "STENT FARMACOLÓGICO PARA ARTERIA CORONARIA"
      },
      {
        "code" : "0702050377",
        "display" : "PARAFUSO ASSOCIÁVEL A PLACA TÓRACO-LOMBO-SACRA TIPO PEDICULAR MONO-AXIAL."
      },
      {
        "code" : "0702050407",
        "display" : "PARAFUSO DE TITÂNIO ASSOCIÁVEL A PLACA CERVICAL"
      },
      {
        "code" : "0702050458",
        "display" : "PLACA CERVICAL ASSOCIADA A PARAFUSOS INTRA-SOMATICOS DE TITANIO"
      },
      {
        "code" : "0702050466",
        "display" : "PLACA CERVICAL ASSOCIADA A PARAFUSOS DE TITANIO P/ FIXACAO EM ESTRUTURAS POSTERIORES"
      },
      {
        "code" : "0702050474",
        "display" : "PLACA DE RECONSTRUCAO EM TITANIO P/ FRATURA DE MANDIBULA (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702050482",
        "display" : "PLACA DE TITÂNIO SISTEMA MINI/MICROFRAGMENTOS (INCLUI PARAFUSOS)"
      },
      {
        "code" : "0702050504",
        "display" : "PROTESE P/ ESOFAGO"
      },
      {
        "code" : "0702050830",
        "display" : "STENT ESOFÁGICO"
      },
      {
        "code" : "0702060011",
        "display" : "CATETER DUPLO J"
      },
      {
        "code" : "0702060020",
        "display" : "PROTESE PENIANA MALEAVEL (PAR DE CORPOS CAVERNOSOS)"
      },
      {
        "code" : "0702060038",
        "display" : "PROTESE TESTICULAR EM GEL DE SILICONE"
      },
      {
        "code" : "0702080020",
        "display" : "PROTESE GLUTEA DE SILICONE (PAR)"
      },
      {
        "code" : "0702080039",
        "display" : "PROTESE MAMARIA DE SILICONE"
      },
      {
        "code" : "0702090018",
        "display" : "PROTESE DE ACO-TEFLON"
      },
      {
        "code" : "0702090034",
        "display" : "PRÓTESE P/ IMPLANTE COCLEAR MULTICANAL"
      },
      {
        "code" : "0702090050",
        "display" : "IMPLANTE DE TITÂNIO DA PRÓTESE AUDITIVA ANCORADA NO OSSO"
      },
      {
        "code" : "0702090093",
        "display" : "PRÓTESE PARA IMPLANTE COCLEAR MULTICANAL"
      }]
    }]
  }
}

```
